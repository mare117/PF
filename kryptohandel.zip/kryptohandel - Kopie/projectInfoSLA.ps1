. "./projectInfo.ps1"

$projectInfo.scenarioName += " SLA"
$projectInfo.qcTestSets = @(
    ,@{
        id=330814
        name="Kryptohandel"
        testInstanceIds=@(
            5162374
        )
    }
)  