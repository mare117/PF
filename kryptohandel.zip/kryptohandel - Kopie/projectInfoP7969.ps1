. "./projectInfo.ps1"

$projectInfo.scenarioName = "P7969 Kryptohandel FK Trading Test"
$projectInfo.reason = "P7969 Kryptohandel Trading with new FK Portfolios, PEAK load"

$projectInfo.qcTestSets = @(
    ,@{
        id=332740
        name="P7969 Performancetest"
        testInstanceIds=@(
            5191713
        )
    }
)  