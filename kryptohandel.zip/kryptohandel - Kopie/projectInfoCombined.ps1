. "./projectInfoPEAK.ps1"

$projectInfo.scenarioName += " COMBINED"
$projectInfo.typicalEndTime = "18:00"
$projectInfo.typicalStartTime = "14:00"