. "./projectInfo.ps1"

$projectInfo.scenarioName += " PEAK"
$projectInfo.qcTestSets = @(
    ,@{
        id=330814
        name="Kryptohandel"
        testInstanceIds=@(
            5162373
        )
    }
)  