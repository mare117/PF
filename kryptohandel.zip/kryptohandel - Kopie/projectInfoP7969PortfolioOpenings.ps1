. "./projectInfo.ps1"

$projectInfo.scenarioName = "P7969 Kryptohandel FK Portfolio Openings"
$projectInfo.reason = "Portfolio Openings of FK Portfolios as a preparation for Load Test"


$projectInfo.qcTestSets = @(
    ,@{
        id=332740
        name="P7969 Performancetest"
        testInstanceIds=@(
            5191713
        )
    }
)  