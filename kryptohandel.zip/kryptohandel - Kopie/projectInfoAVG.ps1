. "./projectInfo.ps1"

$projectInfo.scenarioName += " AVG"
$projectInfo.qcTestSets = @(
    @{
        id=326029
        name="Kryptohandel"
        testInstanceIds=@(
            5071627
        )
    }
    ,@{
        id=327709
        name="P7969 Performancetest"
        testInstanceIds=@(
            5112040
        )
    }
)  