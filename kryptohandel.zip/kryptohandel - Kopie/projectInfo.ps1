$projectInfo = @{
    mvnSettings = @(
        @{ mvnSettingName="step-selenium"; projectName="Kryptohandel" }
    )
    projectName="Kryptohandel"  
    releaseNumber="RE26D"
    #parentConfluencePageId=966464183 # personal space
    parentConfluencePageId=1711941160
    scenarioName="Kryptohandel Main Scenario"

    
    testStrategyConfluencePageId=776868886
    testStrategyTitle="Kryptohandel Regression Teststrategie"
    
    calendarCategories="Anlegen GUI"
    #calendarCategories="Self Service"
    distributionList=@{
        To=@(
          "Delivery Team Cabana, PF84 <dtcabana@postfinance.ch>" # Mailbox
          "DT Integration BaNCS, PF84 <BaNCS-ISY-Integration@postfinance.ch>" # Mailbox
          "DT PEDAS Core (STPEDA), PF84 <dtpedas@postfinance.ch>" # Mailbox
          "DTOB-EF, PF83 <dtob-ef@postfinance.ch>" # Mailbox
          "DTOB-FIPO, PF83 <dtob-fipo@postfinance.ch>" # Mailbox
          "DTOB-OKAUT, PF83 <dtob-okaut@postfinance.ch>" # Mailbox
          "ISACDP, PF84 <isacdp@postfinance.ch>" # Mailbox
          "Pikett OCC, PF84 <pikettocc@postfinance.ch>" # Mailbox
          "Release Management PF, PF81 <re.management@postfinance.ch>" # Mailbox
          "Coedo Garcia Javier, PF65 extern <javier.coedogarcia@postfinance.ch>" # User
          "Kiessling Arne, PF85 extern <arne.kiessling@postfinance.ch>" # User
          "Kuenzli Jonas, PF65 <jonas.kuenzli@postfinance.ch>" # User
          "Lips David, PF62 <david.lips@postfinance.ch>" # User
          "Mahrer Edona, PF85 <edona.mahrer@postfinance.ch>" # User
          "Ritschard Christoph, PF83 <christoph.ritschard@postfinance.ch>" # User
          "Rust Maic, PF65 <maic.rust@postfinance.ch>" # User
          "Sharma Yatin, PF84 extern <yatin.sharma@postfinance.ch>" # User
          "Steiner Janik, PF62 <janik.steiner.1@postfinance.ch>" # User
          "Stuber Marc, PF85 extern <marc.stuber@postfinance.ch>" # User
        )
        CC=@(
          "Last&PerformanceTest, PF85 <last-performance@postfinance.ch>" # Mailbox
          "Baumhoff Stephan, PF85 <stephan.baumhoff@postfinance.ch>" # User
          "Berger Muriel, PF85 <muriel.berger@postfinance.ch>" # User
          "Helfenstein Nevin, PF85 <nevin.helfenstein@postfinance.ch>" # User
          "Kirchmeier Roman, PF85 extern <roman.kirchmeier@postfinance.ch>" # User
          "Om Hari, PF85 <hari.om@postfinance.ch>" # User
          "Pham Viet My, PF85 <vietmy.pham@postfinance.ch>" # User
          "Reber Martin, PF85 extern <martin.reber.7@postfinance.ch>" # User
          "Selvarasu Kiruthika, PF85 extern <kiruthika.selvarasu@postfinance.ch>" # User
          "Sivamangalath Variyam Archana, PF85 extern <archana.sivamangalathvariyam@postfinance.ch>" # User
        )
        Engineers=@(
          "Reber Martin, PF85 extern <martin.reber.7@postfinance.ch>" # User
          "Misev Cyril, PF85 extern <cyril.misev@postfinance.ch>" # User
        )
    }
    typicalStartTime="09:00"
    typicalEndTime="12:00"

    qcTestSets=@()  
    jiraTask="NFRT-19509"
    splunkDashboards=@(
        @{
            Url="https://pfportal.pnet.ch/splunkclu/en-US/app/splunk_for_load/kryptohandel_monitoring?form.gt.earliest=[[startTime]]&form.gt.latest=[[endTime]]&form.update_interval=1m&form.pt.earliest=[[analysisStartTime]]&form.pt.latest=[[analysisEndTime]]&form.perc=[[perc]]"
            Name="Kryptohandel Monitoring (Splunk)"
        }
    )
    rampUpMinutes=0
    rampDownMinutes=0
    gitName="kryptohandel"
    testEnvironment="T1"
    reportCache="report_cache"
    clickPathsCache="clickpahts_cache"
    downloadFolder="$env:USERPROFILE\Downloads"
    hltcE2E=@(
        ,@{
            store="GS2408"
            id="GS2405-37147"
            name="LPT Manage Investment transactions"
        }
    )
    clickPathPages=@(
        ,@{
            name="Kryptohandel Klickpaths"
            confluencePageId=913937266
            planName="Kryptohandel Scenario"
        }
    )
    nfrReportLabels=@{
        90="90%-tile [ms]"
        99="99%-tile [ms]"
        avg="Average [ms]"
    }
    longNfrReportLabels=@{
        90="90%-tile response time ({0} ms)"
        99="99%-tile response time ({0} ms)"
        avg="average response time ({0} ms)"
        errorRate="error rate ({0:n2}%)"
        tpm="transactions per minute"
    }
    applicationsInScope=@(
        "BANCS"
        "OKAUT"
        "BGSP"
        "FIPO"
        "PEDAS"
        "ISAC.DP"
        "CPLKU.CBP"
        "OTS"
    )
    engineerConfluenceIds=@(
        #"misevc"
        #"helfensteinn"
        "rebm"
        #"phamthiv"
    )
    transactionsAnalysis=@(
        @{
            title="Durchsatzanalyse"
            description=""
            type="step-measurements-table"
            nameFilters=@(,"*")
            nfrs=@{
                90=@{
                    "KRYPTO_SellAsset_*_Sell_*"=2000
                    "KRYPTO_BuyAsset_*_Buy_*"=2000
                    "KRYPTO_SavingsPlanCreate_*_SavingsPlanCreate_*"=2000
                    "KRYPTO_*_GetAmount_*"=2000
                }
            }
        }
    )
    serverMonitoring=@(
        ,@{
            type="graphana-screenshot"
            graphanaUrl="https://pfportal.pnet.ch/grafana/d/fe570w8c8d4hsf/step-overview?orgId=1&from=[[from]]&to=[[to]]&timezone=browser&var-cluster=t1-k8s-nucleus-a&var-namespace=appl-testlup-step-selenium-t1&var-agentSet=step-agent-krypto&var-rate_interval=1m"
            title="CPU and Memory Utilization (STEP Selenium Infrastructure)"
            screenshotWindowSize="1920,1280"
            width=1200
            description="The following Grafana dashboard shows CPU and memory utilization on the STEP Selenium infrastructure during this test."
        }
    )
    detailAnalysis=@(
        @{
            type="step-graph"
            transactionName="KRYPTO_BuyAsset_*_Buy_*"
            nfr=@{
                90=2000
            }
            width=1200
            title="Frontend Buy Transactions"
            description="This section gives details about frontend behaviour and transaction times when the user buys a kryptocurrency"
            listSlowest=$false
        },
        @{
            type="step-graph"
            transactionName="KRYPTO_SellAsset_*_Sell_*"
            nfr=@{
                90=2000
            }
            width=1200
            title="Frontend Sell Transactions"
            description="This section gives details about frontend behaviour and transaction times when the user sells a kryptocurrency"
        },
        @{
            type="step-graph"
            transactionName="KRYPTO_SavingsPlanCreate_*_SavingsPlanCreate_*"
            nfr=@{
                90=2000
            }
            width=1200
            title="Frontend Savingsplan Create"
            description="This section gives details about frontend behaviour and transaction times when the user creates a savingsplan for a kryptocurrency"
        },
        @{
            type="step-graph"
            transactionName="KRYPTO_Questionnaire_*_Overview_ClickSend"
            nfr=@{
                90=2000
            }
            width=1200
            title="Frontend Portfolio Creation Performance"
            description="This section gives details about frontend behaviour and transaction times when the user clicks the final ""send"" Button to create a new Crypto portfolio"
        },
        @{
            type="step-graph"
            transactionName="KRYPTO_*_GetAmount_*"
            nfr=@{
                90=2000
            }
            width=1200
            title="Frontend Get Amount Performance"
            description="This section gives details about frontend behaviour and transaction times between the user entering the purchase amount in dollar and receiving the indicative debit and Kryptocurrency amount."
        },
        @{
            type="step-graph"
            transactionName="KRYPTO_SellAsset_*_ClickActionOnAsset"
            nfr=@{
                90=2000
            }
            width=1200
            title="Frontend Click Actions on Asset"
            description="This section gives details about frontend behaviour and transaction times when attempting to click on an asset action for selling the asset. This measuring point has proven useful to determine whether there is some general unavailability of the service."
        },
        @{
            type="step-graph"
            transactionName="KRYPTO_*_Check_Week"
            nfr=@{
                90=2000
            }
            width=1200
            title="Frontend check week chart"
            description="This section gives details about frontend behaviour and transaction times between the user clicking on the view Details button on a kryptocurrency and the API call being received which contains the weekly chart data."
        },
        @{
            type="splunk-graph"
            title="Transactions by Asset"
            description="Splunk Graph showing transactions by asset"
            splunkGraphs=@(, "Transactions by Asset")
            width=1200
        },
        @{
            type="splunk-graph"
            title="Transactions by Type"
            description="Splunk Graph showing transactions by Type"
            splunkGraphs=@("Transactions by Type", "Crypto OKAUT Request")
            width=1200
        },
        @{
            type="splunk-graph"
            title="Total Transaction numbers"
            description="Splunk Graph showing Total transaction numbers both recorded by BGSP and by Frontend action"
            splunkGraphs=@("Total CreateSecurityOrder Messages BGSP", "Total Frontend Transactions")
            width=1200
        }
        @{
            type="splunk-graph"
            title="Check Position Exists Wait Duration Distribution"
            description="Distribution of wait times between last click on buy button and check whether the position exists in a given portfolio, split by statuses (success/failure) of the check."
            splunkGraphs=@("Check Position Exists Wait Duration Distribution")
            width=1200
        }
    )
}