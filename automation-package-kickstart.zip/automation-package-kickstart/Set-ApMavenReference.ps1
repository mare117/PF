Param(
    $projectName = "Common",
    $mvnSettingName = "step-selenium"
)

if ("$projectName" -eq "") 
{
    Write-Host @"

    Usage:
        - Install and configure prerequisites as per README.md
        - Change directory to a blank Git repository 
        - In Powershell, execute:

            .\Set-ApMavenReference -projectName ProjectName [-planToExecute PlanName] [-mvnSettingName MvnSettingName]

          where

            ProjectName     Name of project in the STEP instance, for example Common
            MvnSettingName  Id of Maven profile to take the auth token and step url from. Default: nfrt
            
"@
    exit
}


$ProgressPreference = 'SilentlyContinue'
$ErrorActionPreference = 'Stop'

$PSDefaultParameterValues['*:Encoding'] = 'utf8'

. "$PSScriptRoot\confluence-scripts\common\Set-Controller.ps1"


$controllerUrl = (Select-Xml  -Path "$env:USERPROFILE\.m2\settings.xml" -XPath "//settings:profile[settings:id='$mvnSettingName']//settings:step.url" -Namespace @{settings="http://maven.apache.org/settings/1.0.0"}).Node.InnerText

$apName = "step-selenium-generic"

Set-Controller @{
    controllerUrl=$controllerUrl
    token=(Select-Xml  -Path "$env:USERPROFILE\.m2\settings.xml" -XPath "//settings:profile[settings:id='$mvnSettingName']//settings:step.auth-token" -Namespace @{settings="http://maven.apache.org/settings/1.0.0"}).Node.InnerText
    projectName = $projectName
}

$aps = Invoke-RestMethod -UseBasicParsing "$controllerUrl/rest/table/automationPackages?includeGlobalEntities=false" -Headers @{Accept="application/json; charset=utf-8"; "Content-Type"="application/json"} -Method Post -Body (
    @{
        skip=0
        limit=100
    } | ConvertTo-Json);
$ap = $aps.data | Where-Object { $_.attributes.name -eq $apName } 


$boundary = "d0VfOqmB2uK6y9vh"
$response = Invoke-RestMethod -UseBasicParsing "$controllerUrl/rest/automation-packages/$($ap.id)" -Method Put -Headers @{Accept="application/json; charset=utf-8"; "Content-Type"="multipart/form-data; boundary=----$boundary"} -Body @"
------$boundary
Content-Disposition: form-data; name="apMavenSnippet"

<dependency>
    <groupId>ch.postfinance.nfrt.step</groupId>
    <artifactId>step-selenium-generic</artifactId>
    <version>245.0.0</version>
</dependency>
------$boundary
Content-Disposition: form-data; name="apLibraryMavenSnippet"

<dependency>
    <groupId>ch.postfinance.nfrt.step</groupId>
    <artifactId>step-selenium-commons</artifactId>
    <version>243.0.0</version>
    <classifier>jar-with-dependencies</classifier>
</dependency>
------$boundary
Content-Disposition: form-data; name="plansAttributes"

{}
------$boundary
Content-Disposition: form-data; name="functionsAttributes"

{}
------$boundary
Content-Disposition: form-data; name="tokenSelectionCriteria"

{}
------$boundary--

"@

if ($response.status -eq "UPDATED") {
    Write-Host "Automation Package was updated"
    
}

foreach($warnings in $response.warnings) {
    Write-Warning $warning
}