Param(
    $resourcePageId = 990650284,
    $masterExcelName = "Memory_Calculation.xlsx",
    $mvnSettingName = "step-selenium",
    $deploymentsRoot = "C:\dev\nfrt\step\deployments\"
)


Function Set-Config {
    param(
        $configRoot,
        $fileName,
        $replacements
    )

    
    $configFile = [System.IO.Path]::Combine($configRoot, $fileName)
    
    if (Test-Path -PathType Leaf $configFile) {
        $config = Get-Content $configFile
        
        foreach ($replacement in $replacements.GetEnumerator()) {
            $config = $config -replace $replacement.Key, $replacement.Value
        }
        <# $keys is $replacements item #>
        Set-Content -Path $configFile -Value $config
        
        Write-Host "[Deployments]   ... write $configFile"
    }    
}

$ProgressPreference = 'SilentlyContinue'

$token = (Select-Xml  -Path "$env:USERPROFILE\.m2\settings.xml" -XPath "//settings:profile[settings:id='$mvnSettingName']//settings:confluence.auth-token" -Namespace @{settings="http://maven.apache.org/settings/1.0.0"}).Node.InnerText

$headers = @{ 
    "Content-Type"="application/json"
    "Accept"="application/json"
    "Authorization"="Bearer $token"
}



Write-Host "[Confluence] Get current page... https://confluence.pnet.ch/pages/viewpage.action?pageId=$($resourcePageId)"
$confluencePage = Invoke-RestMethod -Method Get -Uri "https://confluence.pnet.ch/rest/api/content/$($resourcePageId)?expand=body.storage,version,ancestors" -Headers $headers -UseBasicParsing
#$confluencePage.body.storage.value | Out-File confluence.html
#exit
$confluencePage.version = @{
    number = $confluencePage.version.number + 1
    message = "Updated via API"
}
$confluencePage.ancestors = @(, @{
    id=($confluencePage.ancestors | Select-Object -Last 1).id
})


Write-Host "[Confluence] Get master Excel..."
$currentAttachments = Invoke-RestMethod -Method Get -Uri "https://confluence.pnet.ch/rest/api/content/$($resourcePageId)/child/attachment?limit=1000" -Headers $headers -UseBasicParsing

$masterExcelInfo = $currentAttachments.results | Where-Object { $_.title -eq $masterExcelName }
$downloadPath = $masterExcelInfo._links.download


$masterExcelPath = [System.IO.Path]::Combine([System.IO.Path]::GetTempPath(), $masterExcelName)

$null = Invoke-RestMethod -Uri "https://confluence.pnet.ch$($downloadPath)" -Method Get -OutFile $masterExcelPath -Headers $headers

Write-Host "[Context] Load Excel"

$excel = New-Object -comobject Excel.Application
$workbook = $excel.Workbooks.Open($masterExcelPath)
try {
 

    $workbook.Worksheets("Pods").Activate();

    $cells = $workbook.ActiveSheet.Cells;

    $row = 10
    $agentRows = ""
    while($cells.Item($row, 1).Text -ne "")
    {
        $cluster = $cells.Item($row, 1).Text;
        $namespace = $cells.Item($row, 2).Text;
        $podname = $cells.Item($row, 3).Text;
        $sutattribute = $cells.Item($row, 5).Text;
        $totalMemory = $cells.Item($row, 6).Text;
        $cpuPerAgent = $cells.Item($row, 9).Text
        $threadsPerPod = $cells.Item($row, 12).Text;
        $numberOfPods = $cells.Item($row, 15).Text;
        

        $configRoot = [System.IO.Path]::Combine($deploymentsRoot, "overlays", "$cluster-$namespace", $podname);

        if ("$threadsPerPod" -eq "0") {
            # base pod (deployment)
            Write-Host "[Deployments] Set values for deployment $cluster $podname"
            Set-Config $configRoot "deployment.yaml" @{
                "memory: ""[0-9]*G"""="memory: ""$($totalMemory)G"""
            }
        } else {
            # agent
            Write-Host "[Deployments] Set values for agent $cluster $podname"
            Set-Config $configRoot "configMap.yaml" @{
                "capacity: [0-9]*"="capacity: $($threadsPerPod)"
                "sut: [^\s]*"="sut: $($sutattribute)"
            }
            Set-Config $configRoot "statefulset.yaml" @{
                "replicas: [0-9]*"="replicas: $($numberOfPods)"
                "memory: ""[0-9]*G"""="memory: ""$($totalMemory)G"""
            }
            
        }

        
        $configRoot = $configRoot.Replace($deploymentsRoot, "https://gitlab.pnet.ch/nfrt/step/deployments/-/blob/master/").Replace("\", "/")

        $configFile = $cells.Item($row, 13).Text
        $configLink = if ($configFile -ne "") {"<a href=""$configRoot/$configFile"">$configFile</a>"}  else {""}

        $podFile = $cells.Item($row, 16).Text
        $podLink = if ($podFile -ne "") {"<a href=""$configRoot/$podFile"">$podFile</a>"}  else {""}

        $memoryUS = $cells.Item($row, 7).Text;
        $memoryPerThread = $cells.Item($row, 8).Text
        $reservePods = $cells.Item($row, 11).Text
        $totalNumberOfThreads = $cells.Item($row, 14).Text
        $requiredMemory = $cells.Item($row, 17).Text
        $requiredCPU = $cells.Item($row, 18).Text

        $agentRows += @"
            <tr>
                <td>$cluster</td>
                <td>$namespace</td>
                <td>$podname</td>
                <td>$sutattribute</td>
                <td style="text-align: right">$totalMemory</td>
                <td style="text-align: right">$memoryUS</td>
                <td style="text-align: right">$memoryPerThread</td>
                <td style="text-align: right">$cpuPerAgent</td>
                <td style="text-align: right">$reservePods</td>
                <td style="text-align: right">$threadsPerPod</td>
                <td>$configLink</td>
                <td style="text-align: right">$totalNumberOfThreads</td>
                <td style="text-align: right">$numberOfPods</td>
                <td>$podLink</td>
                <td style="text-align: right">$requiredMemory</td>
                <td style="text-align: right">$requiredCPU</td>
            </tr>
"@
        $row = $row + 1
    }


    $workbook.Worksheets("Thread Groups").Activate();

    $cells = $workbook.ActiveSheet.Cells;
    $threadGroupRows = ""
    $row = 11
    while($cells.Item($row, 1).Text -ne "")
    {
        $cluster = $cells.Item($row, 1).Text;
        $namespace = $cells.Item($row, 2).Text;
        $owner = $cells.Item($row, 3).Text;
        $projectName = $cells.Item($row, 4).Text;
        $planName = $cells.Item($row, 5).Text;
        $threadGroup = $cells.Item($row, 6).Text;
        $combinedTest = $cells.Item($row, 7).Text;
        $designThreads = $cells.Item($row, 8).Text;
        $actualThreads = $cells.Item($row, 9).Text;
        $loadFactor = $cells.Item($row, 10).Text;
        $sutAttribute = $cells.Item($row, 11).Text;
        $memoryPerThread = $cells.Item($row, 12).Text;
        $mainMemoryConsumption = $cells.Item($row, 13).Text;
        $podName = $cells.Item($row, 14).Text;
        $podsRequired = $cells.Item($row, 21).Text;
        $totalMemoryRequired = $cells.Item($row, 22).Text;
        $testStart = $cells.Item($row, 23).Text;
        $testDuration = $cells.Item($row, 24).Text;
        $dashboardLink = ""
        if ($testStart -ne "") {
            $testFrom = ([DateTimeOffset]::Parse($testStart)).ToUnixTimeSeconds()*1000
            $testTo = ([DateTimeOffset]::Parse($testStart) + [TimeSpan]::Parse($testDuration)).ToUnixTimeSeconds()*1000
            $dashboardLink = "<a href=""https://pfportal.pnet.ch/grafana/d/fe570w8c8d4hsf/step-overview?orgId=1&amp;var-cluster=$cluster&amp;var-namespace=$namespace&amp;var-agentSet=$podName&amp;from=$testFrom&amp;to=$testTo"">Dashboard</a>"
        }
        
        
        $threadGroupRows += @"
        <tr>
            <td>$cluster</td>
            <td>$namespace</td>
            <td>
                <ac:link>
                    <ri:user ri:username="$owner" />
                </ac:link>
            </td>
            <td>$projectName</td>
            <td>$planName</td>
            <td>$threadGroup</td>
            <td>$combinedTest</td>
            <td style="text-align: right">$designThreads</td>
            <td style="text-align: right">$actualThreads</td>
            <td style="text-align: right">$loadFactor</td>
            <td>$sutAttribute</td>
            <td style="text-align: right">$memoryPerThread</td>
            <td style="text-align: right">$mainMemoryConsumption</td>
            <td>$podName</td>
            <td style="text-align: right">$podsRequired</td>
            <td style="text-align: right">$totalMemoryRequired</td>
            <td>$testStart</td>
            <td>$testDuration</td>
            <td>
                $dashboardLink
            </td>
        </tr>
"@

        $row = $row + 1
    }

    $workbook.Worksheets("Namespaces").Activate();

    $cells = $workbook.ActiveSheet.Cells;
    $namespaceRows = ""
    $row = 10
    while($cells.Item($row, 1).Text -ne "")
    {
        $cluster = $cells.Item($row, 1).Text;
        $namespace = $cells.Item($row, 2).Text;
        $totalPodsRequired = $cells.Item($row, 3).Text;
        $currentLimitPods = $cells.Item($row, 4).Text;
        $totalCPURequired = $cells.Item($row, 5).Text;
        $currentCPULimit = $cells.Item($row, 6).Text;
        $totalMemoryRequired = $cells.Item($row, 7).Text;
        $currentLimitMemory = $cells.Item($row, 8).Text;
        
        $namespaceRows += @"
        <tr>
            <td>$cluster</td>
            <td>$namespace</td>
            <td style="text-align: right">$totalPodsRequired</td>
            <td style="text-align: right">$currentLimitPods</td>
            <td style="text-align: right">$totalCPURequired</td>
            <td style="text-align: right">$currentCPULimit</td>
            <td style="text-align: right">$totalMemoryRequired</td>
            <td style="text-align: right">$currentLimitMemory</td>
            <td><a
                    href="https://gitlab.pnet.ch/nfrt/namespaces/-/blob/main/projects/$cluster/$namespace.yaml?ref_type=heads#L30">$namespace.yaml</a>
            </td>
            <td><a
                    href="https://pfportal.pnet.ch/argocd-itd/applications/$cluster-$namespace">Dashboard</a>
            </td>
        </tr>
"@

        $row = $row + 1
    }
                            
                            
                            
    $confluencePage.body.storage.value = @"
    <ac:layout>
        <ac:layout-section ac:type="single">
            <ac:layout-cell><ac:structured-macro ac:name="warning" ac:schema-version="1">
                <ac:rich-text-body>
                    <p>This page is updated with the Powershell <a href="https://gitlab.pnet.ch/nfrt/step/plans/automation-package-kickstart/-/blob/main/Update-InfrasctructureCalculation.ps1?ref_type=heads">Update-InfrasctructureCalculation.ps1</a>
                        using the contents of the attached 
                        <ac:link>
                            <ri:attachment ri:filename="Memory_Calculation.xlsx" />
                        </ac:link>
                        file. Please edit the contents only by editing the Excel file and then executing the
                        update script. This is described in section 
                        <ac:link ac:anchor="updating_resource_info">
                            <ac:plain-text-link-body><![CDATA[ "Updating the resource information" ]]></ac:plain-text-link-body>
                        </ac:link>
                    </p>
                </ac:rich-text-body>
            </ac:structured-macro>
        </ac:layout-cell></ac:layout-section>
        <ac:layout-section ac:type="two_equal">
            <ac:layout-cell>
                <h1>Introduction</h1>
                <p>Managing the Cluster resource requirements for the Step installations is important to ensure smooth
                    operation of the tests. Memory Requirements for the Selenium tests in particular can change from release
                    to release, and the setup of the thread groups will have impact on the behaviour should the test
                    experience timeouts due to a SUT anomaly, with a corresponding breach of the cacluclated pacing time.
                    The intent of this page should be to give thorough insight in how resources should be planned.</p>
                <p><br /></p>
                <ac:structured-macro ac:name="anchor" ac:schema-version="1">
                    <ac:parameter ac:name="">updating_resource_info</ac:parameter>
                </ac:structured-macro>
                <h1>Updating the resource information</h1>
                <p>In order to ensure data integrity of the data contained in this page, as well as to ensure the namespace
                    configuration actually corresponds to the data shown here, a Powershell script was introduced which
                    keeps all the information in sync.</p><ac:structured-macro ac:name="expand" ac:schema-version="1">
                    <ac:parameter ac:name="title">Initial Setup</ac:parameter><ac:rich-text-body>
                        <p>Checkout the GIT respositories:</p>
                        <ul>
                            <li>&quot;Automation Package Kickstart&quot;
                                here <a href="https://gitlab.pnet.ch/nfrt/step/plans/automation-package-kickstart">nfrt /
                                    Step / Plans / Automation Package Kickstart GitLab</a> and </li>
                            <li>nfrt deployments here <a href="https://gitlab.pnet.ch/nfrt/step/deployments">nfrt / Step / Deployments GitLab</a></li>
                        </ul>
                        <p>As usual, preferably use the standard structure of the checkout location, i.e. it is best to use
                            the following locations for the checkout:</p>
                        <ul>
                            <li>
                                &quot;C:\dev\nfrt\step\plans\automation-package-kickstart&quot; and</li>
                            <li>&quot;C:\dev\nfrt\step\deployments
                                respectively</li>
                        </ul>
                        <p>Setup the settings for acessing the Confluence API</p>
                        <ul>
                            <li>copy
                                C:\dev\nfrt\plans\automation-package-kickstart\settings.example.xml to C:\Users\[your
                                username]\.m2\settings.xml</li>
                            <li>In Confluence, press on your Profile menu
                                (with your profile picture), then navigate Profile/Profil  Settings/Einstellungen
                                Personal Access Token/Persönliche Zugriffstoken and create a Personal Access
                                token. <ac:structured-macro ac:name="warning" ac:schema-version="1"><ac:rich-text-body>
                                        <p>This token will be personal to you. Actions undertaken by the script will appear
                                            in the logs under your name. It is your responsibility that it remains personal
                                            to you. Don't share it with other people</p>
                                    </ac:rich-text-body></ac:structured-macro></li>
                            <li>Enter the token under confluence.auth-token
                                in C:\Users\[your username]\.m2\settings.xml</li>
                        </ul>
                        <p>If not done yet, install the Atlassian companion app, which allows you to edit files on
                            confluence without the need to re-upload the files manually.</p>
                    </ac:rich-text-body>
                </ac:structured-macro>
                <ac:structured-macro ac:name="expand" ac:schema-version="1">
                    <ac:parameter ac:name="title">Update Excel and run update script</ac:parameter>
                    <ac:rich-text-body>
                        <ul>
                            <li>
                                Edit the attached Excel file using the Atlassian Companion.
                                <strong>Check on the &quot;Namespace&quot; Sheet that none of the total
                                        memory requirements exceed the current limit.</strong>. 
                                        For more information on how to interpret the excel and how to adjust the resources, see
                                        <a href="https://confluence.pnet.ch/spaces/NT/pages/1111514472/Step+-+Adjust+Resource+Excel">Step - Adjust Resource Excel</a>
                            </li>
                            <li>After saving in Excel, click on &quot;Upload&quot; in the Atlassian popup to confirm and 
                                upload the changes.</li>
                            <li>Run C:\dev\nfrt\step\plans\automation-package-kickstart\Update-InfrastructureCalculation.ps1</li>
                            <li>Reload this page and check that your changes got reflected accurately</li>
                            <li>With Visual Studio Code, or any other editor which can display changes to be checked in 
                                with git, compare the current Working Tree
                                with master, to check that the changes you wanted to do reflect in the work tree.</li>
                            <li>Commit and push the changes, and refresh
                                the deployments on ArgoCD. If you made changes to any configmap.yaml of an agent set, make
                                sure to delete the statefulset via argocd or the terminal, to make sure that all agents are
                                re-configured automatically (the deleted statefulset will re-load automatically again.</li>
                        </ul>
                    </ac:rich-text-body>
                </ac:structured-macro>
            </ac:layout-cell>
            <ac:layout-cell>
                <p><ac:structured-macro ac:name="toc" ac:schema-version="1"/></p>
            </ac:layout-cell>
        </ac:layout-section>
        <ac:layout-section ac:type="single">
            <ac:layout-cell>
                <h1>Resource planning Excel</h1>
            </ac:layout-cell>
        </ac:layout-section>
        <ac:layout-section ac:type="two_equal">
            <ac:layout-cell>
                <h2>Namespace Requirements</h2>
                <p>The namespace requirment tab in the excel shows the Current Limit configured in the namespaces yml</p>
                <p><br /></p>
                <table class="wrapped">
                    <thead>
                        <tr>
                            <th>Cluster</th>
                            <th>Namespace</th>
                            <th>Total # of Pods Required</th>
                            <th>Current limit</th>
                            <th>Total CPU Required</th>
                            <th>Current limit</th>
                            <th>Total Memory Required [GB]</th>
                            <th>Current Limit [GB]</th>
                            <th>GitLab Namespace yaml</th>
                            <th>ArgoCD</th>
                        </tr>
                    </thead>
                    <tbody>
                        $namespaceRows
                    </tbody>
                </table>
            </ac:layout-cell><ac:layout-cell>
                <h2>Excel Legend</h2>
                <table class="wrapped">
                    <thead>
                        <tr>
                            <th>Column</th>
                            <th>Source</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Design Threads</td>
                            <td>Test plan</td>
                            <td>Sum of thread counts of each thread group as indicated in the plan</td>
                        </tr>
                        <tr>
                            <td>Allowed Peak Threads</td>
                            <td><a
                                    href="https://pfportal.pnet.ch/grafana/d/fe570w8c8d4hsf/step-overview?orgId=1&amp;from=now-3h&amp;to=now&amp;timezone=browser&amp;var-cluster=t1-k8s-nucleus-a&amp;var-namespace=appl-testlup-step-selenium-t1&amp;var-agentSet=$__all&amp;var-rate_interval=1m">Step
                                    Overview - Playground - Dashboards - Grafana</a></td>
                            <td>Maximum amount of threads which are in use during the test run (lower than design threads,
                                when pacing is higher than actual avg. Running time of thread iteration)</td>
                        </tr>
                        <tr>
                            <td>Pod name</td>
                            <td>Best choice from &quot;Pods&quot; Sheet</td>
                            <td>Kubernetes deployment name</td>
                        </tr>
                        <tr>
                            <td>Pods required</td>
                            <td>Calculation based on Pods configuration</td>
                            <td>Indicative number of pods required for the given thread group/STEP plan</td>
                        </tr>
                        <tr>
                            <td>Total Memory required</td>
                            <td>Calculation based on Pods configuration</td>
                            <td>Required memory including U/S memory buffer based on Pod specification</td>
                        </tr>
                        <tr>
                            <td>SUT selection attribute</td>
                            <td>Associated value in &quot;Pods&quot; Sheet</td>
                            <td>Attribute required to be indicated in STEP plan for selection of correct agent type, if
                                multiple available on cluster (i.e. route_to_sut=fipo)</td>
                        </tr>
                        <tr>
                            <td>Memory/Thread</td>
                            <td><a href="https://pfportal.pnet.ch/grafana/d/fe570w8c8d4hsf/step-overview?orgId=1&amp;from=now-3h&amp;to=now&amp;timezone=browser&amp;var-cluster=t1-k8s-nucleus-a&amp;var-namespace=appl-testlup-step-selenium-t1&amp;var-agentSet=$__all&amp;var-rate_interval=1m">Graphana
                                    Dashboard</a></td>
                            <td>Estimate of Memory used per thread. Empirical value. Take Maximum usage during test run,
                                substract base usage before test run, then divide by threads/pod</td>
                        </tr>
                        <tr>
                            <td>Memory U/S</td>
                            <td><a href="https://pfportal.pnet.ch/grafana/d/fe570w8c8d4hsf/step-overview?orgId=1&amp;from=now-3h&amp;to=now&amp;timezone=browser&amp;var-cluster=t1-k8s-nucleus-a&amp;var-namespace=appl-testlup-step-selenium-t1&amp;var-agentSet=$__all&amp;var-rate_interval=1m">Graphana
                                    Dashboard</a></td>
                            <td>Estimate of Unusable Memory. Empirical value. Progressively load a single agent until agent
                                crashes, then substract memory used by threads with memory/thread estimate from memory per
                                Pod</td>
                        </tr>
                        <tr>
                            <td>Reserve or Base infrastructure pods</td>
                            <td>Number of pods indicated in yml</td>
                            <td>Number of pods for pods which don't carry thread loads and are used as additional pods,
                                typically for MongoDB, STEP controller, Nginx</td>
                        </tr>
                        <tr>
                            <td>Required number of pods</td>
                            <td>Calculation</td>
                            <td>Caluclation based on base infrastructure pods + thread group usage on &quot;Thread
                                Groups&quot; sheet, used for statefulset configuration yml of deployment</td>
                        </tr>
                        <tr>
                            <td>Total Memory Required</td>
                            <td>Calculation</td>
                            <td>Total Memory requirement to be indicated in SMLinux Namespace yml</td>
                        </tr>
                    </tbody>
                </table>
                <p><br /></p>
            </ac:layout-cell>
        </ac:layout-section>
        <ac:layout-section ac:type="single">
            <ac:layout-cell>
                <h2>Pod configurations</h2>
                <table class="wrapped">
                    <thead>
                        <tr>
                            <th>Cluster</th>
                            <th>Namespace</th>
                            <th>Pod Name</th>
                            <th>SUT Attribute</th>
                            <th>Total Memory [GB]</th>
                            <th>Memory U/S [GB]</th>
                            <th>Memory / Thread [GB]</th>
                            <th>CPU Usage per Agent</th>
                            <th>Reserve or Base infrastructure pods</th>
                            <th>Threads / Pod</th>
                            <th>Gitlab</th>
                            <th>Total # of Threads</th>
                            <th>Required Number of Pods</th>
                            <th>Gitlab</th>
                            <th>Required Memory [GB]</th>
                            <th>Required CPU</th>
                        </tr>
                    </thead>
                    <tbody>
                        $agentRows
                    </tbody>
                </table>
                <p><br /></p>
                <h2>Thread Groups</h2>
                <table class="wrapped">
                    <tbody>
                        <tr class="highlight-#c1c7d0">
                            <th colspan="16"></th>
                            <th colspan="3">Start and duration of stable full load
                                exeuction used for calculation</th>
                        </tr>
                        <tr>
                            <th>Cluster</th>
                            <th>Namespace</th>
                            <th>Owner</th>
                            <th>STEP Project Name</th>
                            <th>Plan Name</th>
                            <th>Thread Group / Instance Name</th>
                            <th>Combined Test?</th>
                            <th>Design Threads</th>
                            <th>Actual Token usage</th>
                            <th>Load Factor</th>
                            <th>SUT selection Attribute</th>
                            <th>Memory / Thread required [GB]</th>
                            <th>Main Memory consumption</th>
                            <th>Pod Name</th>
                            <th>Pods Required</th>
                            <th>Total Memory Required [GB]</th>
                            <th>Start</th>
                            <th>Duration</th>
                            <th>Grafana Overview</th>
                        </tr>
                        $threadGroupRows
                    </tbody>
                </table>
                <p>Details can be seen in the following excel: <ac:link>
                        <ri:attachment ri:filename="Memory_Calculation.xlsx" />
                    </ac:link>
                </p>
            </ac:layout-cell>
        </ac:layout-section>
    </ac:layout>
"@


    try {
        Write-Host "[Confluence] Write updates to https://confluence.pnet.ch/pages/viewpage.action?pageId=$($resourcePageId) ..."
        $null = Invoke-RestMethod -Method Put -Uri "https://confluence.pnet.ch/rest/api/content/$($resourcePageId)" -Headers $headers -UseBasicParsing -Body  ($confluencePage | ConvertTo-Json)
    } catch {
        $result = $_.Exception.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($result)
        $reader.BaseStream.Position = 0
        $reader.DiscardBufferedData()
        Write-Host  $reader.ReadToEnd();
    }
} finally {
    $workbook.Close()
    $excel.Quit()
}