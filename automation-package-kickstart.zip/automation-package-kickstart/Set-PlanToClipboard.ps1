Param(
    $planFile
)

if ("$planFile" -eq "") 
{
    Write-Host @"

    Copy plan into clipboard to be used in STEP Plan "Create from yaml" feature

    Usage:
        - In Powershell, execute:

            .\Set-PlanToClipboard.ps1 fileName

          where

            FileName     Path of the file to be copied with the right format
            
"@
    exit
}

$content = Get-Content -Path $planFile

Set-Clipboard (($content -split "`n" | Select-Object -Skip 1 | ForEach-Object { $_.SubString(2) }) -join "`n")