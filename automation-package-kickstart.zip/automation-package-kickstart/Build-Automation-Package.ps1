Param(
    $projectName,
    $gitName,
    $planToExecute = "",
    $mvnSettingName = "nfrt",
    $rebuildAP = $null,
    $yamlHeader="# yaml-language-server: `$schema=/dev/nfrt/step/plans/automation-package-kickstart/ap-schema.json`n",
    [switch] $skipPom = $false,
    [switch] $skipParameters = $false,
    [switch] $skipPlans = $false,
    [switch] $skipKeywords = $false,
    [switch] $skipSchedules = $false,
    [switch] $skipFiles = $false,
    [switch] $skipDescriptor = $false

)

if ("$projectName" -eq "") 
{
    Write-Host @"

    Usage:
        - Install and configure prerequisites as per README.md
        - Change directory to a blank Git repository 
        - In Powershell, execute:

            .\Build-Automation-Package -projectName ProjectName -gitName GitName  [-planToExecute PlanName] [-mvnSettingName MvnSettingName] 
                [-rebuildAP ap-name] [-yamlHeader header] [-skip(Pom|Parameters|Plans|Keywords|Schedules|Files|Descriptor)]

          where

            ProjectName     Name of project in the STEP instance, for example Common
            GitName         Name of git slug within "nfrt/step/plans/...", for example common-selenium
            PlanName        Name of plan which should be executed upon execution of "mvn package"
                            can be changed later in pom.xml. Default: empty
            MvnSettingName  Id of Maven profile to take the auth token and step url from. Default: nfrt
            ap-name         Name of ap to be rebuilt. If this is set, then the entities which belong to the given ap are re-downloaded.
                            If not set, the entities which DO NOT belong to any ap are downloaded from the given project
            header          Header to be added to each yaml file. by default, VSCode reference to schema in PF standard location.
            skip...         Flags to skip the editing/refreshing of files of a given type. For example, -skipPlans leaves the plans folder
                            as is and does not download/overwrite any plans.
"@
    exit
}

try {
    

    $ProgressPreference = 'SilentlyContinue'
    $ErrorActionPreference = 'Stop'

    $PSDefaultParameterValues['*:Encoding'] = 'utf8'

    . "$PSScriptRoot\confluence-scripts\common\Set-Controller.ps1"
    . "$PSScriptRoot\build-automation-package\Get-APBuildContext.ps1"
    . "$PSScriptRoot\build-automation-package\Write-Plans.ps1"
    . "$PSScriptRoot\build-automation-package\Write-Keywords.ps1"
    . "$PSScriptRoot\build-automation-package\Write-Parameters.ps1"
    . "$PSScriptRoot\build-automation-package\Write-Schedules.ps1"

    $context = Get-APBuildContext @PSBoundParameters

    $fragments=""
    if (-not $skipPlans) { $fragments += Write-Plans $context }
    if (-not $skipKeywords) { $fragments += Write-Keywords $context }
    if (-not $skipParameters) { $fragments += Write-Parameters $context }
    if (-not $skipSchedules) { $fragments += Write-Schedules $context }

    $package = "$($context.yamlHeader)name: $($context.artefactName)`nfragments:`n$fragments"

    if (-not $skipDescriptor) {
        Write-Host "Write automation-package.yaml"
        $null = New-Item -Force -Path "src\main\resources\automation-package.yaml" -Value $package
    }


    if (-not $skipPom) { 

    }

    Write-Host "Write .gitignore"
    $null = New-Item -Force -Path ".gitignore" -Value @"
target
report_cache
clickpaths_cache
"@

} catch {
    Write-Error "$($Error[0].Exception.Message)`n$($Error[0].ScriptStackTrace)"
}