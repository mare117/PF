Param(
    $mvnSettingName = "step-selenium",
    $confluencePageId
)

if ("$confluencePageId" -eq "") 
{
    Write-Host @"

    Usage:
        - Install and configure prerequisites as per README.md
        - Change directory to a blank Git repository 
        - In Powershell, execute:

            .\Check-KeywordUsage.ps1 [-mvnSettingName step-selenium] -confluencePageId 1711954792

          where

          -mvnSettingName   Id of Maven profile to take the auth token and step url from. Default: step-selenium
          -confluencePageId id of page to write the table to
            
"@
    exit
}

$ProgressPreference = 'SilentlyContinue'
$ErrorActionPreference = 'Stop'

$PSDefaultParameterValues['*:Encoding'] = 'utf8'

. "$PSScriptRoot\confluence-scripts\common\Set-Controller.ps1"


$controllerUrl = (Select-Xml  -Path "$env:USERPROFILE\.m2\settings.xml" -XPath "//settings:profile[settings:id='$mvnSettingName']//settings:step.url" -Namespace @{settings="http://maven.apache.org/settings/1.0.0"}).Node.InnerText

$token = (Select-Xml  -Path "$env:USERPROFILE\.m2\settings.xml" -XPath "//settings:profile[settings:id='$mvnSettingName']//settings:step.auth-token" -Namespace @{settings="http://maven.apache.org/settings/1.0.0"}).Node.InnerText
$confluenceToken = (Select-Xml  -Path "$env:USERPROFILE\.m2\settings.xml" -XPath "//settings:profile[settings:id='$mvnSettingName']//settings:confluence.auth-token" -Namespace @{settings="http://maven.apache.org/settings/1.0.0"}).Node.InnerText

$confluenceHeaders=@{ 
    "Content-Type"="application/json; charset=utf-8"
    "Accept"="application/json"
    "Authorization"="Bearer $confluenceToken"
}

$keywordUsageCount = @{};

Set-Controller @{
    controllerUrl=$controllerUrl
    token=$token
    projectName = "[All]"
}

$tenants = Invoke-RestMethod -UseBasicParsing -Method Get -Uri "$controllerUrl/rest/tenants"

$headers = @{
    Accept="application/json; charset=utf-8"
    Authorization="Bearer $token"
}

$tenantNames = ($tenants | Where-Object { -not $_.global } | Sort-Object name).name;

$keywords = Invoke-RestMethod -UseBasicParsing -Method Get -Uri "$controllerUrl/rest/functions"   -Headers $headers

$tenantsById = @{}
foreach($tenant in $tenants) {
    if ($null -eq $tenant.projectId) {
        continue;
    }

    $tenantsById[$tenant.projectId] = $tenant.name

    $keywordUsageCount[$tenant.name] = @{}
    foreach ($keywordName in $keywordNames) {
        $keywordUsageCount[$tenant.name][$keywordName] = 0;
    }
}

$keywordNames = New-Object System.Collections.Generic.HashSet[string];
foreach ($keyword in $keywords) {
    
    $projectId = $keyword.attributes.project
    $keywordName = $keyword.attributes.name

    if (-not $tenantsById.ContainsKey($projectId)) {
        Write-Warning "Keyword $($keywordName): No project name for $projectId"
        continue;
    }
    Write-Host "Loading keyword $keywordName"
    $null = $keywordNames.Add($keyword.attributes.name);
}
$keywordNames = $keywordNames | Sort-Object

Write-Host "Loaded $($keywordNames.Count) Keywords"


$plans = Invoke-RestMethod -UseBasicParsing -Method Get -Uri "$controllerUrl/rest/plans/all"  -Headers $headers
Write-Host "Loaded $($plans.Count) Plans"

Function Set-KeywordCount($planName, $projectName, $node, $countTable) {
    if ($node._class -eq "CallKeyword") {
        $selectionAttributes = ($node.function.value | ConvertFrom-Json)
        $keywordName = $selectionAttributes.name.value;
        if ($null -eq $keywordName) {
            $keywordName = $selectionAttributes.name
            if ($null -eq $keywordName) {
                Write-Warning "Plan/Composite Keyword  $planName, Project $($projectName): Null keyword name: $($node.function.value)"
                return;
            }
        }

        $countTable[$keywordName]++;
    }
    foreach ($child in $node.children) {
        Set-KeywordCount $planName $projectName $child $countTable
    }
    foreach ($child in $node.before.steps) {
        Set-KeywordCount $planName $projectName $child $countTable
    }
    foreach ($child in $node.after.steps) {
        Set-KeywordCount $planName $projectName $child $countTable
    }
    if ($null -ne $node.beforeThread) {
        foreach ($child in $node.beforeThread.steps) {
            Set-KeywordCount $planName $projectName $child $countTable
        }
    }
    if ($null -ne $node.afterThread) {
        foreach ($child in $node.afterThread.steps) {
            Set-KeywordCount $planName $projectName $child $countTable
        }
    }
}

foreach ($plan in $plans) {
    
    $projectId = $plan.attributes.project
    $projectName = $tenantsById[$projectId];
    $planName = $plan.attributes.name


    if ($null -eq $projectName) {
        Write-Warning "Plan $($planName) $($plan.id): No project name for $projectId"
        continue;
    }

    if (-not $plan.visible) {
        Write-Warning "Plan $($planName), Project $($projectName): Skipping invisible plan"
        continue;
    }
    if (-not $keywordUsageCount.ContainsKey($projectName)) {
        Write-Warning "Plan $($planName), Project $projectName not known"
        continue;
    }

    
    Write-Host "Reading Plan $planName"
    Set-KeywordCount $planName $projectName $plan.root $keywordUsageCount[$projectName];
}

foreach ($keyword in $keywords) {
    
    if ($keyword.type -eq "step.plugins.functions.types.CompositeFunction") {

        $projectId = $keyword.attributes.project
        $projectName = $tenantsById[$projectId];
        $keywordName = $keyword.attributes.name


        if ($null -eq $keyword.plan.root) {
            Write-Warning "Composite Keyword $($keywordName): No plan"
            continue;
        }

        if ($null -eq $projectName) {
            continue;
        }

        if (-not $keywordUsageCount.ContainsKey($projectName)) {
            Write-Warning "Composite Keyword $($keywordName), Project $projectName not known"
            continue;
        }

        Write-Host "Reading composite Keyword $keywordName"
        Set-KeywordCount $keywordName $projectName $keyword.plan.root $keywordUsageCount[$projectName];
    }
}

$rows = ""
foreach ($keyword in $keywordNames) {

    $rows += @"

    <tr>
        <td>$keyword</td><td>$(($tenantNames | ForEach-Object { $($keywordUsageCount[$_][$keyword]) } | Measure-Object -Sum).Sum)</td>$($tenantNames | ForEach-Object { "<td>$($keywordUsageCount[$_][$keyword])</td>"})
    </tr>
"@
}

$body = @"
<ac:layout-cell>
<ac:structured-macro ac:name="warning" ac:schema-version="1">
    <ac:rich-text-body>
        <p>This page is updated with the Powershell script <a href="https://gitlab.pnet.ch/nfrt/step/plans/automation-package-kickstart/-/blob/main/Check-KeywordUsage.ps1?ref_type=heads">Check-KeywordUsage.ps1</a></p>
        <p>The script was executed as follows: $([System.Net.WebUtility]::HtmlEncode($MyInvocation.Line))</p>
    </ac:rich-text-body>
</ac:structured-macro>


<table>
    <tr>
        <th>Keyword Name</th><th>Total References</th>$($tenantNames | ForEach-Object { "<th>$_</th>"})
    </tr>
    $rows
</table>
</ac:layout-cell>
"@
$current = Invoke-RestMethod -Method Get -Uri "https://confluence.pnet.ch/rest/api/content/$($confluencePageId)?expand=body.storage,version,ancestors" -Headers $confluenceHeaders -UseBasicParsing
$current.body.storage.value = $body;
$current.version = @{
    number = $current.version.number + 1
    message = "Updated via API"
}
$current.ancestors = @(, @{
    id=($current.ancestors | Select-Object -Last 1).id
})

$jsonBody  = $current | ConvertTo-Json -Depth 20 -Compress
$bodyBytes = [System.Text.Encoding]::UTF8.GetBytes($jsonBody)

$null = Invoke-RestMethod -Method Put -Uri "https://confluence.pnet.ch/rest/api/content/$($confluencePageId)" -Headers $confluenceHeaders -UseBasicParsing -Body $bodyBytes
