
$projectInfo = @{
    mvnSettings = @(
        @{ mvnSettingName="step-selenium"; projectName="Kontaktcenter" }
    )    
    #parentConfluencePageId=966464183 # personal space
    parentConfluencePageId=1689690037
    projectName="Kontaktcenter"
    releaseNumber="REU-DEPLOY"
    jiraTask="NFRT-19697"
    scenarioName="KOP/VASC Chatbot + Cobrowsing + ViBe + Voicebot"
    scenario = "PEAK"
    testStrategyConfluencePageId=240694912
    testStrategyTitle="KOP/VASC - Performance Testkonzept"
    calendarCategories="KOP/Metis"
    distributionList=@{
        To=@(
          "Delivery Team CRM Future Distributionslist <DTCRMFutureDL@post.ch>" # Distribution List
          "DT CRM Hello Distributionlist <DTCRMHello@postfinance.ch>" # Distribution List
          "DT Kundenkommunikationsplattform Distributionlist <dtkopDL@post.ch>" # Distribution List
          "DT Next Gen Bot Distributionlist <dtnextgenbotDL@post.ch>" # Distribution List
          "DTCRMPFMAT Distributionslist <DTCRMPFMATDL@post.ch>" # Distribution List
          "OE-PF85-41 - Test Management <OE-PF85-41-00203125@post.ch>" # Distribution List
          "OE-PF85-41 Ext - Test Management <OE-PF85-41_Ext-00203125@post.ch>" # Distribution List
          "DT CRMOP, PF83 <DTCRMOP@postfinance.ch>" # Mailbox
          "DT VASC, PF83 <dtvasc@postfinance.ch>" # Mailbox
          "DTOB-EF, PF83 <dtob-ef@postfinance.ch>" # Mailbox
          "DTOB-FIPO, PF83 <dtob-fipo@postfinance.ch>" # Mailbox
          "DTOB-OKAUT, PF83 <dtob-okaut@postfinance.ch>" # Mailbox
          "Notifica PF, PF85 <notifica_pf@postfinance.ch>" # Mailbox
          "Release Kalender, PF81 <RE-Kalender@postfinance.ch>" # Mailbox
          "Release Management PF, PF81 <re.management@postfinance.ch>" # Mailbox
          "Solution Team Kundeninteraktion, PF51 <stkundeninteraktion@postfinance.ch>" # Mailbox
          "Bianco Gianni, PF83 extern <gianni.bianco@postfinance.ch>" # User
          "Dragic Diana, PF85 <diana.dragic@postfinance.ch>" # User
          "Husi Jean-Daniel, PF85 <jean-daniel.husi@postfinance.ch>" # User
          "Macher Dieter, PF81 <dieter.macher@postfinance.ch>" # User
          "Nozadze Georgi, PF83 extern <georgi.nozadze@postfinance.ch>" # User
          "Oezsoy Tunahan, PF85 <tunahan.oezsoy@postfinance.ch>" # User
          "Patete Pascal, PF51 <pascal.patete@postfinance.ch>" # User
          "Rueegsegger Christian, PF61 <christian.rueegsegger@postfinance.ch>" # User
          "Schmutz Thomas, PF85 extern <thomas.schmutz@postfinance.ch>" # User
          "Schwarzkopf Svetlana, PF88 <svetlana.schwarzkopf@postfinance.ch>" # User
          "Sokic Ana, PF85 extern <ana.sokic.1@postfinance.ch>" # User
          "Daniel Juan <daniel.juan@spitch.ch>" # External
          "kay.huber@unblu.com" # External
          "Pawel Godek <pawel.godek@spitch.ch>" # External
          "sebastian.perske@unblu.com" # External
          "Load and Performance Testing - DT Next Gen Bot <85ed3db7.o365groups.post.ch@ch.teams.ms>" # Teams Channel
        )
        CC=@(
          "Last&PerformanceTest, PF85 <last-performance@postfinance.ch>" # Mailbox
          "Baumhoff Stephan, PF85 <stephan.baumhoff@postfinance.ch>" # User
          "Berger Muriel, PF85 <muriel.berger@postfinance.ch>" # User
          "Helfenstein Nevin, PF85 <nevin.helfenstein@postfinance.ch>" # User
          "Kirchmeier Roman, PF85 extern <roman.kirchmeier@postfinance.ch>" # User
          "Om Hari, PF85 <hari.om@postfinance.ch>" # User
          "Pham Viet My, PF85 <vietmy.pham@postfinance.ch>" # User
        )
        Engineers=@(
          "Helfenstein Nevin, PF85 <nevin.helfenstein@postfinance.ch>" # User
          "Misev Cyril, PF85 extern <cyril.misev@postfinance.ch>" # User
          "Pham Viet My, PF85 <vietmy.pham@postfinance.ch>" # User
        )
    }

    

    typicalStartTime="13:00"
    typicalEndTime="18:00"
    additionalManagementSummaryRow = @"
        <tr>
            <td>NFRs <b>measured</b> <i>(expected)</i></td>
            <td colspan="4">
                Live Chat: <b>@{livechat_tpm_measured} TPM</b> <i>(@{livechat_tpm_expected} TPM)</i><br/>
                Chatbot: <b>@{chatbot_tpm_measured} TPM</b> <i>(@{chatbot_tpm_expected} TPM)</i>, <b>@{chatbot_errorrate_measured}%</b> <i>(@{chatbot_errorrate_expected}%)</i> Failed Conversations, <b>@{Answer_chatbot_latency99_measured}ms</b> <i>(@{Answer_chatbot_latency99_expected}ms)</i> 99%-tile latency<br/>
                Voicebot:  <b>@{voicebot_cc_measured} Concurrent calls</b> <i>(@{voicebot_cc_expected})</i>, <b>@{voicebot_tpm_measured} TPM</b> <i>(@{voicebot_tpm_expected} TPM)</i>, <b>@{voicebot_errorrate_measured}%</b> <i>(@{voicebot_errorrate_expected}%)</i> Failed Conversations, <b>@{voicebot_latency99_measured}ms</b> <i>(@{voicebot_latency99_expected}ms)</i> 99%-tile latency<br/>
            </td>
        </tr>
"@
    qcTestSets=@(
        <#
        @{
            id=326025
            name="Kontaktcenter"
            testInstanceIds=@(
                5071615,
                5071617,
                5071619
            )
        },
        @{
            id=326027
            name="Kundensupport_bereitstellen"
            testInstanceIds=@(
                5071623
            )
        },
        @{
            id=327577
            name="Chatbot Performancetest"
            testInstanceIds=@(
                5100244
            )
        },
        @{
            id=327578
            name="Voicebot Performancetest"
            testInstanceIds=@(
                5100246
            )
        }#>,
        @{
            id=321681
            name="L&P Tests NGB"
            testInstanceIds=@(
                4992062,
                4992059,
                4992064,
                4992060
            )
        }
    )
    splunkDashboards=@(
        @{
            Url="https://pfportal.pnet.ch/splunkclu/en-US/app/splunk_for_load/ngb_monitoring?form.gt.earliest=[[startTime]]&form.gt.latest=[[endTime]]&form.update_interval=5m&form.pt.earliest=[[analysisStartTime]]&form.pt.latest=[[analysisEndTime]]&form.perc=[[perc]]"
            Name="NGB Monitoring (Splunk)"
        },
        @{
            Url="https://pfportal.pnet.ch/splunkclu/en-US/app/splunk_for_load/kop_monitoring?form.gt.earliest=[[startTime]]&form.gt.latest=[[endTime]]&form.update_interval=5m&form.pt.earliest=[[analysisStartTime]]&form.pt.latest=[[analysisEndTime]]&form.perc=[[perc]]"
            Name="KOP / VASC Monitoring (Splunk)"
        },
        @{
            Url="https://pfportal.pnet.ch/splunkclu/de-DE/app/splunk-app-vasc/ngb_overview?form.timerange.earliest=[[startTime]]&form.timerange.latest=[[endTime]]&form.timespan=span%3D1m&form.index=index%3Dvascitd%20kubernetes_cluster%3Dt1*&form.perc=[[perc]]"
            Name="NGB overview (Splunk)"
        }
    )
    rampUpMinutes=15
    rampDownMinutes=5
    gitName="metis"
    testEnvironment="T1"
    reportCache="report_cache"
    clickPathsCache="clickpaths_cache"
    downloadFolder="$env:USERPROFILE\Downloads"
    nfrReportLabels=@{
        avg="Average [ms]"
        90="90%-tile [ms]"
        99="99%-tile [ms]"
        errorRate="Error rate [%]"
        tpm="TPM"
        count="Count"
    }
    longNfrReportLabels=@{
        90="90%-tile response time ({0} ms)"
        99="99%-tile response time ({0} ms)"
        avg="average response time ({0} ms)"
        errorRate="error rate ({0:n2}%)"
        tpm="transactions per minute"
        count="Count"
    }
    hltcE2E=@(
        ,@{
            store="GS2408"
            id="GS1804-11612"
            name="Kundensupport bereitstellen"
        }
    )
    clickPathPages=@(
        ,@{
            name="Videoberatung Clickpaths"
            confluencePageId=953211182
            planName="Videoberatung Main Scenario"
        },@{
            name="KOP/Metis - Livechat - Clickpaths"
            confluencePageId=954127032
            planName="Kontaktcenter Verify Livechat"
        }
    )
    applicationsInScope=@(
        "VASC", "NGB", "KOP", "PF.CH", "EF", "WAF", "CRMPF", "OKAUT", "NOTIFICA"
    )
    engineerConfluenceIds=@(
        ,"misevc"
        #"helfensteinn"
        #"ritterdavi"
    )

    nfrRelevantChatbot=@(
        @{
            type="splunk-graph"
            title="Transaction rate as measured in the NGB backend"
            width=1200
            splunkGraphs=@("NGB Turns and Sessions")
            dashboardName="NGB Monitoring (Splunk)"
        },
        @{
            type="splunk-table"
            width=1200
            splunkTables=@("NGB Chatbot Sessions and Turns PEAK")
            dashboardName="NGB Monitoring (Splunk)"
        },
        @{
            type="splunk-graph"
            title="Response time for chatbot responses as measured in the NGB backend"
            width=1200
            splunkGraphs=@("NGB Turn Response Times")
            dashboardName="NGB Monitoring (Splunk)"
        },
        @{
            type="splunk-table"
            width=1200
            splunkTables=@("NGB Turn Response Time PEAK")
            dashboardName="NGB Monitoring (Splunk)"
        }
        ,@{
            type="splunk-table"
            title="Chatbot overview of chat roundtrips including KOP"
            description="Transaction rate, technical error and response time breakdown by Szenario  (top), Turn (Middle) and Message (Bottom)"
            splunkTables=@("Frontend Chatbot Conversation Statuses", "Frontend Chatbot Turn Completion Wait Time PEAK", "Frontend Chatbot Message Wait Time PEAK")
            dashboardName="KOP / VASC Monitoring (Splunk)"
            tabName="Chatbot"
        }
        ,@{
            type="splunk-graph"
            width=1200
            title="Evaluation of Chatbot responses"
            description="Evolution of Succesful and Failed Evaluations"
            splunkGraphs=@("NGB Answer Check")
            dashboardName="NGB Monitoring (Splunk)"
        }
        ,@{
            type="splunk-table"
            width=1200
            splunkTables=@("NGB Answer Check PEAK")
            dashboardName="NGB Monitoring (Splunk)"
        }
        ,@{
            type="splunk-table"
            splunkTables=@("NGB Answer Check PEAK")
            dashboardName="NGB Monitoring (Splunk)"
        }
        ,@{
            type="splunk-table"
            splunkTables=@("Live Chat Turns")
            dashboardName="KOP / VASC Monitoring (Splunk)"
            tabName="Overview"
            collectOnly=$true
            nfr=@{
                tpm=35
            }
            nfrReporting=@{
                tpm=@{
                    key="livechat_tpm"
                    tableColumn="avg(count)"
                }
            }
        }
        ,@{
            type="splunk-table"
            splunkTables=@("Chatbot Turns")
            dashboardName="KOP / VASC Monitoring (Splunk)"
            tabName="Overview"
            collectOnly=$true
            nfr=@{
                tpm=55
            }
            nfrReporting=@{
                tpm=@{
                    key="chatbot_tpm"
                    tableColumn="avg(count)"
                }
            }
        }
        ,@{
            type="splunk-table"
            splunkTables=@("Chatbot Technical Error Rate")
            dashboardName="KOP / VASC Monitoring (Splunk)"
            tabName="Overview"
            collectOnly=$true
            nfr=@{
                errorRate=1
            }
            nfrReporting=@{
                errorRate=@{
                    key="chatbot_errorrate"
                    tableColumn="Error Rate (%)"
                }
            }
        }
        ,@{
            type="splunk-table"
            splunkTables=@("Chatbot Frontend Response Times")
            dashboardName="KOP / VASC Monitoring (Splunk)"
            tabName="Overview"
            collectOnly=$true
            nfr=@{
                99=10000
            }
            nfrReportingLabelColumn="MessageType"
            nfrReporting=@{
                99=@{
                    key="chatbot_latency99"
                    tableColumn="99%"
                }
            }
        }
    )
    detailanalysisVASC=@(
        
        ,@{
            type="splunk-table"
            title="Common Errors in NGB Backend"
            description="Common Errors found in NGB vasc index vascitd"
            splunkTables=@("VASC Common Errors")
            dashboardName="NGB Monitoring (Splunk)"
            limit=10
        }
        ,@{
            type="splunk-table"
            description="Common LLM Evaluation Errors when calling the Evaluation API (bottom)"
            splunkTables=@("Common Evaluation Errors")
            dashboardName="NGB Monitoring (Splunk)"
            limit=10
        }
        ,@{
            type="splunk-table"
            description="LLM Evaluation Errors when calling the Evaluation API grouped by Excel scenario id and input."
            splunkTables=@("NGB Validation by Scenario and Input PEAK")
            dashboardName="NGB Monitoring (Splunk)"
            limit=10
        }
        ,@{
            type="splunk-graph"
            width=1200
            title="Session Ends by Status"
            description="Evolution of Session End Statuses"
            splunkGraphs=@("Session Ends by Status")
            dashboardName="NGB Monitoring (Splunk)"
        }
        ,@{
            type="splunk-table"
            splunkTables=@("Session Ends by Status PEAK")
            dashboardName="NGB Monitoring (Splunk)"
        }
    )
    nfrRelevantVoicebot=@( 
        ,@{
            type="splunk-graph"
            width=1200
            title="Voicebot Response Times E2E"
            description="Temporal evolution of Voicebot Response Times"
            splunkGraphs=@("Voicebot Response Times")
            dashboardName="KOP / VASC Monitoring (Splunk)"
            tabName="Voicebot"
        },@{
            type="splunk-table"
            description="Overall Voicebot Response Times (seconds)"
            splunkTables=@("Voicebot Response Times E2E PEAK")
            dashboardName="KOP / VASC Monitoring (Splunk)"
            tabName="Voicebot"
        }  
        ,@{
            type="splunk-graph"
            width=1200
            title="Turn and Conversation Counts and Statuses"
            description="Temporal evolution of Turn and Conversation Counts and Statuses"
            splunkGraphs=@("Turn and Conversation Counts and Statuses")
            dashboardName="KOP / VASC Monitoring (Splunk)"
            tabName="Voicebot"
        },
        ,@{
            type="splunk-table"
            title="Summary of Turn and Conversation Counts, Statuses"
            description="Number of Total and Failed turns and Conversations, along with failure rate percentage"
            splunkTables=@("Summary of Turn and Conversation Counts, Statuses")
            dashboardName="KOP / VASC Monitoring (Splunk)"
            tabName="Voicebot"
        }
        ,@{
            type="splunk-table"
            splunkTables=@("Voicebot Turns")
            dashboardName="KOP / VASC Monitoring (Splunk)"
            tabName="Overview"
            collectOnly=$true
            nfr=@{
                tpm=270
            }
            nfrReporting=@{
                tpm=@{
                    key="voicebot_tpm"
                    tableColumn="avg(count)"
                }
            }
        }
        ,@{
            type="splunk-table"
            splunkTables=@("Voicebot Concurrent Calls")
            dashboardName="KOP / VASC Monitoring (Splunk)"
            tabName="Overview"
            collectOnly=$true
            nfr=@{
                tpm=150
            }
            nfrReporting=@{
                tpm=@{
                    key="voicebot_cc"
                    tableColumn="Concurrency"
                }
            }
        }
        ,@{
            type="splunk-table"
            splunkTables=@("Voicebot Response Times")
            dashboardName="KOP / VASC Monitoring (Splunk)"
            tabName="Overview"
            collectOnly=$true
            nfr=@{
                99=7000
            }
            nfrReporting=@{
                99=@{
                    key="voicebot_latency99"
                    tableColumn="99%"
                }
            }
        }
        ,@{
            type="splunk-table"
            splunkTables=@("Voicebot Technical Error Rate")
            dashboardName="KOP / VASC Monitoring (Splunk)"
            tabName="Overview"
            collectOnly=$true
            nfr=@{
                errorRate=1
            }
            nfrReporting=@{
                errorRate=@{
                    key="voicebot_errorrate"
                    tableColumn="Failed Conversations (%)"
                }
            }
        }

    )
    detailAnalysisVoicebot=@(
        ,@{
            type="splunk-table"
            title="Most Frequent Voicebot Turns"
            description="Most Frequent Voicebot Inputs vs Answers based on number of occurrences"
            splunkTables=@("Most Frequent Voicebot Turns")
            dashboardName="KOP / VASC Monitoring (Splunk)"
            tabName="Voicebot"
            limit=10
        },@{
            type="splunk-graph"
            title="Opt-in METIS Calls"
            description="Service calls to OCC where METIS notifies opt-in answers by the caller"
            splunkGraphs=@("Opt-in METIS Call Responses", "PKS calls")
            dashboardName="KOP / VASC Monitoring (Splunk)"
            tabName="Voicebot"
        },@{
            type="splunk-graph"
            title="Time-Averaged usage of ASR Language Licenses"
            description="Service calls to OCC where METIS notifies opt-in answers by the caller"
            splunkGraphs=@("Time-Averaged usage of ASR Language Licenses")
            dashboardName="KOP / VASC Monitoring (Splunk)"
            tabName="Voicebot"
        }
    )
    detailAnalysisKOP=@(
        @{
            type="step-graph"
            title="PF.CH Chat Window Opening"
            transactionName="KOPMETIS_CommonStart_*_WaitTextBox_Anonymous"
            description="This section shows the Performance and number of errors when clicking on the chat opening button on the PF.CH page and waiting for the chat window appearing (with wait on the user input text box)"
            nfr=@{
                90=8000
                99=10000
            }
            width=1200
            listSlowest=$false
        }
        ,@{
            type="step-graph"
            title="FIPO Chat Window Opening"
            transactionName="KOPMETIS_CommonStart_*_WaitTextBox_LoggedIn"
            description="This section shows the Performance and number of errors when clicking on the chat opening button on the ""Neue Nachricht"" button in FIPO and waiting for the chat window appearing (with wait on the user input text box)"
            nfr=@{
                90=8000
                99=10000
            }
            width=1200
            listSlowest=$false
        }
        ,@{
            type="step-graph"
            title="Welcome Message Appearance after Chat window opening"
            transactionName="KOPMETIS_CommonStart_*_WaitGutenTag_*"
            description="This section shows the Performance and number of errors between chatwindow textbox appearing and the Guten Tag message appearing"
            nfr=@{
                90=8000
                99=10000
            }
            width=1200
            listSlowest=$false
        }
        ,@{
            type="step-graph"
            title="Wait for VASC to change Berater chat title"
            transactionName="KOPMETIS_Livechat_05_AwaitVASCConversationTitle"
            description="This section shows the Performance and number of errors when waiting for VASC to change the Berater chat title. This Wait needs to be successful in order to force a manual title change, a prerequisite to finding the conversation in CRMPF"
            nfr=@{
                90=8000
                99=10000
            }
            width=1200
            listSlowest=$false
        }
        ,@{
            type="step-graph"
            title="Open Conversation in CRMPF"
            transactionName="CRMPF_Livechat_SelectCommunication_06_ClickOnCommunication"
            description="This section shows the Performance and number of errors when trying to open a conversation in CRMPF"
            nfr=@{
                90=8000
                99=10000
            }
            width=1200
            listSlowest=$false
        }
        ,@{
            type="splunk-graph"
            title="Videoberatung appearance of Reconnection indications"
            description="This graph shows the summation of the total duration of a reconnection indication showing up in the frontend (Icon with slashed cloud or ""Wiederaufbau"" screen tooltip)"
            width=1200
            splunkGraphs=@("Accumulated durations of Reconnect indications shown")
            dashboardName="KOP / VASC Monitoring (Splunk)"
            tabName="Videoberatung"
        }
    )

    
    transactionsAnalysis=@(
        @{
            title="KOP/Metis"
            description=""
            type="step-measurements-table"
            nameFilters=@(,"KOPMETIS_*")
            nfrs=@{
                90=@{
                    "KOPMETIS_Chatbot_*_CheckMessage_*"=15000
                    "KOPMETIS_CommonStart_*_WaitGutenTag*"=8000
                }
                99=@{
                    "KOPMETIS_Chatbot_*_CheckMessage_*"=15000
                    "KOPMETIS_CommonStart_*_WaitGutenTag*"=8000
                }
            }
        },
        @{
            title="Videoberatung"
            description=""
            type="step-measurements-table"
            nameFilters=@(,"Videoberatung_*")
            nfrs=@{
                90=@{
                    "*"=5000
                }
                99=@{
                    "*"=8000
                }
            }
        }
    )
    serverMonitoring=@(
        @{
            type="graphana-screenshot"
            graphanaUrl="https://eu-central-2.console.aws.amazon.com/cloudwatch/home?region=eu-central-2#home:dashboards/Bedrock?~(timeRange~(~[[from]]~[[to]]))"
            title="AWS Bedrock"
            width=1200
            description="The following is a screenshot of the AWS Bedrock Dashboard"
            screenshotWindowSize="1920,1280"
        },
        @{
            type="graphana-screenshot"
            graphanaUrl="https://pfportal.pnet.ch/grafana/d/fe570w8c8d4hsf/step-overview?orgId=1&from=[[from]]&to=[[to]]&timezone=browser&var-cluster=t1-k8s-nucleus-a&var-namespace=appl-testlup-step-selenium-t1&var-agentSet=step-agent-kopmetis&var-agentSet=step-agent-vibe&var-agentSet=step-agent-visitors&var-agentSet=step-agent-visitors-tabs"
            title="Load Generator Resources"
            width=1200
            description="The following is a screenshot of the graphana dashboard showing the resources of the load generator"
            screenshotWindowSize="1920,1280"
        },
        @{
            type="graphana-screenshot"
            graphanaUrl="https://pfportal.pnet.ch/grafana/d/skgIV4siz/unblu-application-overview?orgId=1&from=[[from]]&to=[[to]]&var-UnbluDatasource=vm-p1&var-namespace=appl-kop-t1"
            title="Unblu Statistics"
            description="The following is a screenshot of the graphana dashboard provided by KOP for monitoring of various statistics"
            screenshotWindowSize="1920,1600"
            width=1200
        },
        @{
            type="graphana-screenshot"
            graphanaUrl="https://pfportal.pnet.ch/grafana/d/czwp8klMz/rendering-service?orgId=1&refresh=30s&var-UnbluDatasource=PF3D020BCD42CE705&var-cluster=All&var-namespace=appl-kop-t1&var-pod=All&from=[[from]]&to=[[to]]"
            title="Unblu Rendering Service"
            width=1200
            description="The following is a screenshot of the graphana dashboard showing the Rendering service resources for Videoberatung"
            screenshotWindowSize="1920,900"
        },
        @{
            type="graphana-screenshot"
            graphanaUrl="https://pfportal.pnet.ch/grafana/d/ee4b7ogsihddsf/container-resource-usage?orgId=1&from=[[from]]&to=[[to]]&var-cluster=t1-k8s-online-a&var-container=All&var-datasource=vm-p1&var-namespace=appl-kop-t1"
            title="Unblu k8s Infrastructure"
            width=1200
            description="The following is a screenshot of the graphana dashboard showing the resource breakdown on the Unblu k8s namespace"
            screenshotWindowSize="1920,3200"
        },
        @{
            type="graphana-screenshot"
            graphanaUrl="https://pfportal.pnet.ch/grafana/d/ee4b7ogsihddsf/container-resource-usage?orgId=1&from=[[from]]&to=[[to]]&timezone=browser&var-datasource=PB2CF859592C5A6CF&var-cluster=t1-eks-vasc-a&var-namespace=appl-vasc"
            title="VASC k8s Infrastructure"
            width=1200
            description="The following is a screenshot of the graphana dashboard showing the resource breakdown on the Unblu k8s namespace"
            screenshotWindowSize="1920,3200"
        }
    )
    detailAnalysisUms=@(
        @{
            type="step-graph"
            title="Frontend click Login after Challenge"
            transactionName="EFLogin*_ClickLoginAfterChallenge"
            description="This section shows the Performance and number of errors when clicking on the login button after entering the SMS challenge code"
            nfr=@{
                90=10000
                99=10000
            }
            width=1200
            listSlowest=$false
        }
        ,@{
            type="splunk-graph"
            title="Page Rendering Times"
            description="Page Rendering times of PF.CH"
            width=1200
            splunkGraphs=@("Page Rendering Times 90%-tile", "90%tile Page Load Time PEAK")
            dashboardName="KOP / VASC Monitoring (Splunk)"
            tabName="KOP General"
        }
        ,@{
            type="splunk-table"
            width=1200
            splunkTables=@("90%tile Page Load Time PEAK")
            dashboardName="KOP / VASC Monitoring (Splunk)"
            tabName="KOP General"
        }
    )
    
    # New configurable report structure
    reportStructure=@(
        ,@{
            title="NFR Relevante Daten - Chatbot"
            type="simple"
            sections=@(
                ,@{
                    type="single"
                    function="Get-ReportDetailAnalysis"
                    analysisConfig="nfrRelevantChatbot"
                }
            )
        },
        @{
            title="NFR Relevante Daten - Voicebot"
            type="simple"
            sections=@(
                ,@{
                    type="single"
                    function="Get-ReportDetailAnalysis"
                    analysisConfig="nfrRelevantVoicebot"
                }
            )
        },
        @{
            title="Detaillierte Antwortzeit- und Durchsatz Analyse"
            type="collapsible"
            sections=@(
                @{
                    type="single"
                    function="Get-ReportDetailAnalysis"
                    analysisConfig="transactionsAnalysis"
                }
                )
            },
        @{
            title="OS / Server Monitoring"
            type="collapsible"
            sections=@(
                @{
                    type="single"
                    function="Get-ReportDetailAnalysis"
                    analysisConfig="serverMonitoring"
                }
            )
        },
        @{
            title="Detail Analysen - KOP"
            type="collapsible"
            sections=@(
                @{
                    type="single"
                    function="Get-ReportDetailAnalysis"
                    analysisConfig="detailAnalysisKOP"
                }
            )
            scope="KOP"
        },
        @{
            title="Detail Analysen - VASC"
            type="collapsible"
            sections=@(
                @{
                    type="single"
                    function="Get-ReportDetailAnalysis"
                    analysisConfig="detailAnalysisVASC"
                }
            )
            scope="VASC"
        },
        @{
            title="Detail Analysen - Voicebot"
            type="collapsible"
            sections=@(
                @{
                    type="single"
                    function="Get-ReportDetailAnalysis"
                    analysisConfig="detailAnalysisVoicebot"
                }
            )
            scope="Voicebot"
        },
        @{
            title="Detail Analysen - Umsysteme"
            type="collapsible"
            sections=@(
                @{
                    type="single"
                    function="Get-ReportDetailAnalysis"
                    analysisConfig="detailAnalysisUms"
                }
            )
            scope="UMS"
        },
        @{
            title="Häufig auftretende Fehler"
            type="collapsible"
            sections=@(
                @{
                    type="single"
                    functions=@(
                        "Get-ReportCommonErrors",
                        "Get-ReportCommonConsoleErrors"
                    )
                }
            )
            scope="Errors"
        },
        @{
            title="Execution Details"
            type="collapsible"
            sections=@(
                @{
                    type="controller-loop"
                    functions=@(
                        ,"Get-ReportExecutionDetailsSection"
                    )
                }
            )
        },
        @{
            title="Platform Status"
            type="collapsible"
            sections=@(
                @{
                    type="single"
                    function="Get-ReportPlatformStatusTable"
                }
            )
        }
    )
}

$projectInfo.updateAdditionalPages=@(
        ,@{
            confluencePageId=$projectInfo.parentConfluencePageId
            rexTemplate="(?<pre1>.*?(Table of Test Runs).*<table.*(<\/th>).*?<\/tr>.*?)" + # pre1 group is to capture the beginning of the proper table (in the "Summary of Test Runs" section"), up to the first row below the table header (we want newest runs to be shown on top)
                        "((?<pre2>.*)" + # pre2 gorup is to capture the rows which do not correspond to the run we want to modify (i.e. if we want to re-write the summary for an older run)
                            "(?<existingrow>(<tr>.*?" +  # existingrow should capture the row which we do want to modify (empty if non existent)
                                "<td><a href="".*?"">@{datetime}<\/a><\/td>" + # use date time to find the existing row, if any
                                "(.*?<\/td>){11,11}" + # in the row, skip 10 cells until reaching the comment cells
                                "<td>(?<comments_lup>.*?)<\/td><td>(?<comments_tm>.*?)<\/td><\/tr>))" + # comments_lup and comments_tm will capture existing comments in the existing row (empty if non existent)
                        "){0,1}" + 
                        "(?<mid1>.*(Test Run Management Summaries).*<ac:rich-text-body>)" +  # capture until start of table of test runs
                        "((?<mid2>.*)" + # pre3 gorup is to capture the extracts of the runs which we do not want to modify (i.e. if we want to re-write the summary for an older run)
                            "(?<existingextract>(<p>.*?@{page_prefix}.*?<\/p>))" + # capture existing extract
                        "){0,1}" + 
                        "(?<post>.*)" # capture everything else
                        
            
                        # note that we do not reference "exitingrow, because we want to replace it, however we do reference comments_lup and comments_tm so as to not overwrite the comments which were already made".
            replacementTemplate="`${pre1}`${pre2}" +
                                    "<tr><td><a href=""@{report_url}"">@{datetime}</a></td>" +
                                    "<td>@{scenario}</td>" + 
                                    "<td>@{status_label}</td>" + 
                                    "<td@{livechat_tpm_style}>@{livechat_tpm_measured}</td>" +
                                    "<td@{chatbot_tpm_style}>@{chatbot_tpm_measured}</td>" +
                                    "<td@{chatbot_errorrate_style}>@{chatbot_errorrate_measured}</td>" +
                                    "<td@{Answer_chatbot_latency99_style}>@{Answer_chatbot_latency99_measured}</td>" +
                                    "<td@{voicebot_cc_style}>@{voicebot_cc_measured}</td>" +
                                    "<td@{voicebot_tpm_style}>@{voicebot_tpm_measured}</td>" +
                                    "<td@{voicebot_errorrate_style}>@{voicebot_errorrate_measured}</td>" +
                                    "<td@{voicebot_latency99_style}>@{voicebot_latency99_measured}</td>" +
                                    "<td>@{defect_list}</td>" +
                                    "<td>@{conclusion}</td>" +
                                    "<td>`${comments_tm}</td>" +
                                "</tr>" +
                                "`${mid1}`${mid2}" +
                                "<p>" +
                                    "<ac:structured-macro ac:name=""excerpt-include"" ac:schema-version=""1"">" +
                                        "<ac:parameter ac:name="""">" +
                                            "<ac:link>" +
                                                "<ri:page ri:space-key=""NT"" ri:content-title=""@{page_title}"" />" +
                                            "</ac:link>" +
                                        "</ac:parameter>" +
                                    "</ac:structured-macro>" +
                                "</p>" +
                                "`${post}"     
        }
    )