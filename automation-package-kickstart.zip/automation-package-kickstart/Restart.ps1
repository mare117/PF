
$controllerpod = $(kubectl get pods | ForEach-Object { ($_ -split " ")[0] }) | Where-Object { $_.StartsWith("step-controller") }
$namespace = (kubectl describe pods/$controllerpod | Where-Object { $_ -match  "^Namespace:.*" }) -replace "Namespace:\s*", ""

$confirmation = Read-Host "This is about to restart the controller and ALL agents in namespace $namespace. Please confirm [y/N]"


if ($confirmation -eq "y") {
   kubectl rollout restart deployment step-controller
   $statefulsets = $(kubectl get statefulsets | ForEach-Object { ($_ -split " ")[0] }) | Where-Object { $_.StartsWith("step-agent") }

   foreach ($set in $statefulsets) {
      kubectl delete statefulset/$set
   }
} else {
   Write-Host "Restart skipped"
}