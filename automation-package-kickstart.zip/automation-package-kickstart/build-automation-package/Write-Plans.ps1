
. "$PSScriptRoot\Get-Filename.ps1"
. "$PSScriptRoot\Write-Plan.ps1"

Function Write-Plans {
    Param(
        $context
    )


    if (Test-Path -Path src\main\resources\plans -PathType Container) {
        Remove-Item -Path src\main\resources\plans -Force -Recurse
    }

    $containsPlans = $false
    foreach ($plan in $context.plans) {
        $planId = $plan.id
        $name = $plan.attributes.name
        $projectId = $plan.attributes.project
        
        if ($context.apId -ne $plan.customFields.automationPackageId) {
            continue;
        }
        if ($projectId -eq $context.tenant.projectId -and $plan.visible) {
            if ($plan._class -eq "step.plans.nl.PlainTextPlan") {
                Write-Host "Downloading plain text plan $name"
                $fileName = Get-Filename($name)
                $null = New-Item -Force -Path "src\main\resources\plans\$fileName.yaml" -Value @"
$($context.yamlHeader)plansPlainText:
- name: "$name"
  rootType: $($plan.type)
  file: "plans/$fileName.plan"
"@
            $null = New-Item -Force -Path "src\main\resources\plans\$fileName.plan" -Value $plan.source
            $containsPlans = $true
        } else {
            
            Write-Host "Downloading plan $name..."
            $response = Invoke-WebRequest -UseBasicParsing -Method Get -Uri "$($context.controllerUrl)/rest/plans/${planId}/yaml"   -Headers @{Accept="text/plain; charset=utf-8"}

            
            $lines = $response.Content.Split([Environment]::NewLine)
            $content = @"
$($context.yamlHeader)plans:
- $($lines[2])
$(Write-Plan $context "  " $lines)
"@;

                $name = Get-Filename($name)
                $null = New-Item -Force -Path "src\main\resources\plans\$name.yaml" -Value $content
                $containsPlans = $true
            }
        }
    }
    
    if ($containsPlans) { return "- ""plans/*.yaml""`n" } else { return "" }
}
