
. "$PSScriptRoot\Get-Filename.ps1"

Function Write-Plan {
    Param(
        $context,
        $indent,
        $lines
    )

    for($i = 3; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -like "*planId:*") {
            $k = $lines[$i].IndexOf("planId: ")
            $planId = $lines[$i].SubString($k + 8).Trim(""" ");
            $planName = $context.planNamesById[$planId];
            
            $content += $indent + $lines[$i].SubString(0, $k) + "selectionAttributes: `n"
            $content += $indent + $lines[$i].SubString(0, $k) + "- name: ""$planName""`n"
        } elseif($lines[$i] -match "^([-\s]*)([a-zA-Z0-9_\-]*):\s""(.*)\\$") {
            $fieldIndent=$Matches[1];
            $blankIndent=$fieldIndent -replace "-"," "
            $fieldName=$Matches[2];
            $multilineString=[regex]::Unescape($Matches[3]);
            while ($i -lt $lines.Count-1 -and $lines[++$i] -match "^$blankIndent  (.*)[\\""]$") {
                $multilineString += [regex]::Unescape($Matches[1])
            }
            $content += $indent + $fieldIndent + $fieldName + ": |`n"
            $content += (($multilineString.Trim("`n`n").Split("`n") | ForEach-Object { $indent + "  " + $blankIndent + $_ + "`n"}) -join "")
            $i--
        } elseif ($lines[$i] -match "\s*file:" -and $lines[$i+1] -match "\s*id: ""(.*)""") {
            $resourceId = $Matches[1];
            $response = Invoke-RestMethod -UseBasicParsing -Method Get -Uri "$($context.controllerUrl)/rest/resources/${resourceId}" -Headers @{Accept="application/json; charset=utf-8"};
            $fileName = Get-Filename $response.resourceName;

            if (-not $context.skipFiles) {     
                $response = Invoke-WebRequest -UseBasicParsing -Method Get -Uri "$($context.controllerUrl)/rest/resources/${resourceId}/content" 

                $null = New-Item -Force -Path "src\main\resources\files\$fileName"
                $null = Set-Content -Force -Path "src\main\resources\files\$fileName" -Value  $response.Content -Encoding Byte
            }
            
            $content += $indent + $lines[$i] + " ""files/$fileName""`n"
            $i++
        } else {
            $content += $indent + $lines[$i] + "`n"
        }
    }
    return $content
}
