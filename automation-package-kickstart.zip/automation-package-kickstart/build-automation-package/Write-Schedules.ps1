Function Write-Schedules {
    Param(
        $context
    )
    
    if (Test-Path -Path src\main\resources\schedules.yaml -PathType Leaf) {
        Remove-Item -Path src\main\resources\schedules.yaml -Force
    }
    
    $schedulesResponse = Invoke-RestMethod -UseBasicParsing -Method Post -Uri "$($context.controllerUrl)/rest/table/tasks" -Headers @{Accept="application/json; charset=utf-8"} -Body (@{
        skip=0
        limit=1000
        sort=@{
            field="attributes.name"
            direction="ASCENDING"
        }
    } | ConvertTo-Json -Depth 100 -Compress) -ContentType "application/json; charset=utf-8"

    $schedules=$schedulesResponse.data | Where-Object { $context.apId -eq $_.customFields.automationPackageId -and $_.attributes.project -contains $context.tenant.projectId }


    if ($schedules.Count -ge 1) {
        Write-Host "Write schedules"
        $schedulesYaml = "$($yamlHeader)schedules:`n"
        foreach ($schedule in $schedules) {
            
            $planId = $schedule.executionsParameters.repositoryObject.repositoryParameters.planid
            $planName = $context.planNamesById[$planId];
            $schedulesYaml += @"
- name: "$($schedule.attributes.name)"
  cron: "$($schedule.cronExpression)"
  planName: "$planName"
  active: $($schedule.active)
  executionParameters:
$(($schedule.executionsParameters.customParameters.PSObject.Properties | ForEach-Object {
@"
    $($_.Name): "$($_.Value)"

"@
            }) -join "")
"@;
        }

        $null = New-Item -Force -Path "src\main\resources\schedules.yaml" -Value $schedulesYaml;
        return "- ""schedules.yaml""`n";
    } else {
        return "";
    }
}
