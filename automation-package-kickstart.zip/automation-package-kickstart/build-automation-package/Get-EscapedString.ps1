
Function Get-EscapedString{
    param($str)
    return "$str".Replace("""","\""").Replace("`n", "\n")
}