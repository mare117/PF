

. "$PSScriptRoot\Get-EscapedString.ps1"
Function Get-EscapedStringOrMultiline{
    param($indent, $str)

    if ($str -like "*`n*") {
        return "|`n" +(($str.Split("`n") | ForEach-Object { "$($indent)$_" }) -join "`n")
    } else {
        return """$(Get-EscapedString($str))"""
    }
}
