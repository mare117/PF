Function Get-Filename {
    param($name)

    return ($name -replace "[\\""\/'><=|:\*]","") -replace " ","_"
}