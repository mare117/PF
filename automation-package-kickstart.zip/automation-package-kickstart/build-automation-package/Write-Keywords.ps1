
. "$PSScriptRoot\Get-Filename.ps1"
. "$PSScriptRoot\Write-Plan.ps1"
. "$PSScriptRoot\Get-EscapedStringOrMultiline.ps1"

Function Write-Keywords {
    Param(
        $context
    )

    if (Test-Path -Path src\main\resources\keywords -PathType Container) {
        Remove-Item -Path src\main\resources\keywords -Force -Recurse
    }
    $keywords = Invoke-RestMethod -UseBasicParsing -Method Get -Uri "$($context.controllerUrl)/rest/functions"   -Headers @{Accept="application/json; charset=utf-8"}
   
    $containsKeywords = $false
    foreach ($keyword in $keywords) {
        $keywordId = $keyword.id
        $name = $keyword.attributes.name
        $projectId = $keyword.attributes.project

        if ($context.apId -ne $keyword.customFields.automationPackageId) {
            continue;
        }
        if ($projectId -contains $context.tenant.projectId) {
            if ($keyword.type -eq "step.plugins.functions.types.CompositeFunction") {
                Write-Host "Downloading composite keyword $name ..."
                $response = Invoke-RestMethod -UseBasicParsing -Method Get -Uri "$($context.controllerUrl)/rest/functions/${keywordId}"   -Headers @{Accept="application/json; charset=utf-8"}
                $planId = $response.plan.id

                $plan = $response.plan;
                $plan.attributes = Add-Member -InputObject $plan.attributes -Name project -Value $projectId -Force -MemberType AliasProperty
                $null = Invoke-RestMethod -UseBasicParsing -Method Post -Uri "$($context.controllerUrl)/rest/plans" -Headers @{Accept="application/json; charset=utf-8"} -Body ($plan| ConvertTo-Json -Depth 100 -Compress) -ContentType "application/json; charset=utf-8"
                
                $response = Invoke-WebRequest -UseBasicParsing -Method Get -Uri "$($context.controllerUrl)/rest/plans/$($planId)/yaml" -Headers @{Accept="text/plain; charset=utf-8"}
                $null = Invoke-RestMethod -UseBasicParsing -Method Delete -Uri "$($context.controllerUrl)/rest/plans/$($planId)"

                $lines = $response.Content.Split([Environment]::NewLine)

                $content = @"
$($context.yamlHeader)keywords:
- Composite:
    name: "$name"
    schema: $(Write-Schema $keyword.schema)
    description: $(Get-EscapedStringOrMultiline "      " $keyword.description)
    plan:
      $($lines[2])
$(Write-Plan $context "      " $lines)
"@;

            $name =  Get-Filename($name)
            $null = New-Item -Force -Path "src\main\resources\keywords\$name.yaml" -Value $content
            $containsKeywords = $true;
            
        } elseif ($keyword.type -eq "step.plugins.java.GeneralScriptFunction" -and $keyword.scriptLanguage.value -eq "groovy") {
            Write-Host "Downloading script keyword $name..."
            $scriptLanguage = $keyword.scriptLanguage.value
            
            $scriptFileId = $keyword.scriptFile.value.Replace("resource:", "");
            $scriptFileResponse = Invoke-WebRequest -UseBasicParsing -Method Get -Uri "$($context.controllerUrl)/rest/resources/$($scriptFileId)/content" -Headers @{Accept="application/json; charset=utf-8"}
            $scriptFileContent = $scriptFileResponse.Content
            $name =  Get-Filename($name)
            $null = New-Item -Force -Path "src\main\resources\keywords\scripts\$name.$scriptLanguage"
            $null = Set-Content -Path "src\main\resources\keywords\scripts\$name.$scriptLanguage"  -Value $scriptFileContent -Encoding Byte
            $null = New-Item -Force -Path "src\main\resources\keywords\$name.yaml"
            $null = Set-Content -Force -Path "src\main\resources\keywords\$name.yaml" -Value  @"
$($context.yamlHeader)keywords:
- GeneralScript:
    name: "$name"
    scriptLanguage: groovy
    scriptFile: "keywords/scripts/$name.$scriptLanguage"
    description: $(Get-EscapedStringOrMultiline "      " $keyword.description)
    schema: $(Write-Schema $keyword.schema)
"@
                $containsKeywords = $true;
            }
        }
    }
    
    if ($containsKeywords) { return "- ""keywords/*.yaml""`n" } else { return "" }
}


Function Write-Schema {
    param($schema)

    $content = @"

      properties:
"@
    if ($schema.properties.PSObject.Properties.length -eq 0) {
        $content += " {}"
    }
    foreach($param in $schema.properties.PSObject.Properties) { 
        $content += @"

        $($param.Name):
"@
        foreach ($prop in $param.Value.PSObject.Properties) {
            if ($prop.Name -eq "Name") {
                continue;
            }
            $content += @"

          $($prop.Name): "$(Get-EscapedString($prop.Value))"
"@            
        }
    }
    $content += @"

      required:
"@
    if ($schema.required.length -eq 0) {
        $content += " []"
    }
    foreach ($prop in $schema.required) {
        $content += @"

      - $($prop)
"@            
    }
    return $content
}