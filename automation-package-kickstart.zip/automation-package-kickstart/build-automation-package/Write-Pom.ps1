Function Write-Pom {
    
    param(
        $context
    )

    Write-Host "Write pom.xml"
    $null = New-Item -Force -Path "pom.xml" -Value @"
<project xmlns="http://maven.apache.org/POM/4.0.0"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>


    <groupId>ch.postfinance.nfrt.step.plans</groupId>
    <artifactId>$($context.artefactName)</artifactId>
    <version>0.0.1-SNAPSHOT</version>
    <properties>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <project.reporting.outputEncoding>UTF-8</project.reporting.outputEncoding>

        <!--<maven.compiler.source>11</maven.compiler.source>
      <maven.compiler.target>11</maven.compiler.target>-->

        <junit.version>4.13.2</junit.version>
        <maven.test.skip>true</maven.test.skip>
        <step.step-project-name>$($context.projectName)</step.step-project-name>
        <step-execute-auto-packages.include-plans>$($context.planToExecute)</step-execute-auto-packages.include-plans>
    </properties>

    <description>$($context.projectName) Automation Package for STEP</description>
    <scm>
        <url>https://gitlab.pnet.ch/nfrt/step/plans/$($context.gitName)</url>
        <connection>scm:git:https://gitlab.pnet.ch/nfrt/step/plans/$($context.gitName).git</connection>
        <developerConnection>scm:git:https://gitlab.pnet.ch/nfrt/step/plans/$($context.gitName).git</developerConnection>
        <tag>HEAD</tag>
    </scm>

    <distributionManagement>
        <snapshotRepository>
            <id>central</id>
            <url>https://repo.pnet.ch:443/artifactory/nfrt-maven-snapshots-local/</url>
        </snapshotRepository>
        <repository>
            <id>central</id>
            <url>https://repo.pnet.ch:443/artifactory/nfrt-maven-releases-local/</url>
        </repository>
    </distributionManagement>

    <profiles>
        <profile>
            <id>step-execution</id>
            <activation>
                <activeByDefault>false</activeByDefault>
            </activation>
            <build>
                <plugins>
                    <plugin>
                        <groupId>ch.exense.step</groupId>
                        <artifactId>step-maven-plugin</artifactId>
                        <version>`${step.version}</version>
                        <executions>
                            <execution>
                                <id>execute-automation-package</id>
                                <phase>verify</phase>
                                <configuration>
                                    <url>`${step.url}</url>
                                    <authToken>`${step.auth-token}</authToken>
                                    <stepProjectName>`${step.step-project-name}</stepProjectName>
                                    <ensureExecutionSuccess>true</ensureExecutionSuccess>
                                    <waitForExecution>true</waitForExecution>
                                    <executionResultTimeoutS>600</executionResultTimeoutS>
                                    <executionParameters>
                                        <threadIterations></threadIterations>
                                        <debug>true</debug>
                                        <seleniumAsBusinessError>false</seleniumAsBusinessError>
                                        <scenario>BASE</scenario>
                                        <makeActionDocumentationScreenshot>false</makeActionDocumentationScreenshot>
                                        <stepDuration></stepDuration>
                                        <waitForAngular5>false</waitForAngular5>
                                        <comment></comment>
                                        <env>T1</env>
                                        <waitForJS>false</waitForJS>
                                        <testDuration>1</testDuration>
                                        <lang>de</lang>
                                        <timeout>30</timeout>
                                    </executionParameters>
                                </configuration>
                                <goals>
                                    <goal>execute-automation-package</goal>
                                </goals>
                            </execution>
                        </executions>
                    </plugin>
                </plugins>
            </build>
        </profile>
    </profiles>
</project>
"@
}