
Function Get-APBuildContext {
    Param(
        $projectName,
        $gitName,
        $planToExecute = "",
        $mvnSettingName = "nfrt",
        $rebuildAP = $null,
        $yamlHeader="# yaml-language-server: `$schema=/dev/nfrt/step/plans/automation-package-kickstart/ap-schema.json`n",
        [switch] $skipPom = $false,
        [switch] $skipParameters = $false,
        [switch] $skipPlans = $false,
        [switch] $skipKeywords = $false,
        [switch] $skipSchedules = $false,
        [switch] $skipFiles = $false,
        [switch] $skipDescriptor = $false
    )

    $controllerUrl = (Select-Xml  -Path "$env:USERPROFILE\.m2\settings.xml" -XPath "//settings:profile[settings:id='$mvnSettingName']//settings:step.url" -Namespace @{settings="http://maven.apache.org/settings/1.0.0"}).Node.InnerText
    Set-Controller @{
        controllerUrl=$controllerUrl
        token=(Select-Xml  -Path "$env:USERPROFILE\.m2\settings.xml" -XPath "//settings:profile[settings:id='$mvnSettingName']//settings:step.auth-token" -Namespace @{settings="http://maven.apache.org/settings/1.0.0"}).Node.InnerText
        projectName = $projectName
    }
    
    $apId = Get-APId $controllerUrl $rebuildAP
    $tenant = Invoke-RestMethod -UseBasicParsing -Method Get -Uri "$controllerUrl/rest/tenants/current"
    $plans = Invoke-RestMethod -UseBasicParsing -Method Get -Uri "$controllerUrl/rest/plans/all"  -Headers @{Accept="application/json; charset=utf-8"}
    $planNamesById = @{};


    foreach ($plan in $plans) {
        $planId = $plan.id
        $name = $plan.attributes.name
        $planNamesById[$planId] = $name;
    }

    return @{
        projectName=$projectName
        planToExecute=$planToExecute
        gitName=$gitName
        artefactName=$gitName
        tenant=$tenant
        plans=$plans
        planNamesById=$planNamesById
        yamlHeader=$yamlHeader 
        controllerUrl=$controllerUrl
        skipFiles=$skipFiles
        apId=$apId
    }

}

Function Get-APId {
    param (
        $controllerUrl,
        $apName
    )
    
    $apId = $null;
    if ($null -ne $apName) {

        $aps = Invoke-RestMethod -UseBasicParsing "$controllerUrl/rest/table/automationPackages?includeGlobalEntities=false" -Headers @{Accept="application/json; charset=utf-8"; "Content-Type"="application/json"} -Method Post -Body (
            @{
                skip=0
                limit=100
            } | ConvertTo-Json);
        $ap = $aps.data | Where-Object { $_.attributes.name -eq $rebuildAP } 
        $apId = $ap.id

        Write-Host "Rebuild automation Package $rebuildAP, with id $apId"
    }   
    return $apId
}