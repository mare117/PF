. "$PSScriptRoot\Get-EscapedStringOrMultiline.ps1"

Function Write-Parameters {
    Param(
        $context
    )
    if (Test-Path -Path src\main\resources\parameters.yaml -PathType Leaf) {
        Remove-Item -Path src\main\resources\parameters.yaml -Force
    }

    $parameters = Invoke-RestMethod -UseBasicParsing -Method Get -Uri "$($context.controllerUrl)/rest/parameters/all?limit=10000" -Headers @{Accept="application/json; charset=utf-8"}
    $parameters = $parameters | Where-Object { $context.apId -eq $_.customFields.automationPackageId -and $_.attributes.project -contains $context.tenant.projectId -and -not $_.parameter.protectedValue }

    if ($parameters.Count -ge 1) {


        Write-Host "Write parameters"
        $parametersYaml = "$($context.yamlHeader)parameters:`n"
        foreach ($parameter in $parameters) {
            $parametersYaml += "- key: $($parameter.key)`n"
            if ($parameter.value.value) {
                $parametersYaml += "  value: " + (Get-EscapedStringOrMultiline "    " $parameter.value.value)  + "`n"
                
            }
            if ($parameter.activationExpression.script) {
                $parametersYaml += "  activationScript: " + (Get-EscapedStringOrMultiline "    " $parameter.activationExpression.script) + "`n"
            }
        }

        $null = New-Item -Force -Path "src\main\resources\parameters.yaml" -Value $parametersYaml
        return "- ""parameters.yaml""`n";
    } else {
        return "";
    }
}
