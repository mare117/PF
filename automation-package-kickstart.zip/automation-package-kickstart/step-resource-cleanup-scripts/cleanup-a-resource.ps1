Param(
    $projectName,
    $mvnSettingName = "nfrt"
)

if ("$projectName" -eq "") 
{
    Write-Host @"

    Usage:
        - Install and configure prerequisites as per root README.md
        - In Powershell, execute:

            .\cleanup-a-resource -projectName ProjectName [-mvnSettingName MvnSettingName]

          where

            ProjectName     Name of project in the STEP instance, for example Common
            MvnSettingName  Id of Maven profile to take the auth token and step url from. Default: nfrt
            
"@
    exit
}

$ProgressPreference = 'SilentlyContinue'
$token = (Select-Xml  -Path "$env:USERPROFILE\.m2\settings.xml" -XPath "//settings:profile[settings:id='$mvnSettingName']//settings:step.auth-token" -Namespace @{settings="http://maven.apache.org/settings/1.0.0"}).Node.InnerText
$controllerUrl = (Select-Xml  -Path "$env:USERPROFILE\.m2\settings.xml" -XPath "//settings:profile[settings:id='$mvnSettingName']//settings:step.url" -Namespace @{settings="http://maven.apache.org/settings/1.0.0"}).Node.InnerText


Write-Host "Switching to project $projectName"
$null = Invoke-RestMethod -UseBasicParsing -Method Post -Uri "$controllerUrl/rest/tenants/current" -Body $projectName -Header @{ 
    "Content-Type"="application/json"
    "Authorization"="Bearer $token"
}

$tenant = Invoke-RestMethod -UseBasicParsing -Method Get -Uri "$controllerUrl/rest/tenants/current"


$body = @'
{"skip":0,"limit":100,"sort":{"field":"attributes.name","direction":"ASCENDING"},"filters":[{"oql":"not(resourceType=attachment)"}]}
'@

$resources = Invoke-RestMethod -UseBasicParsing -Method Post -Body $body -Uri "$controllerUrl/rest/table/resources" -Header @{ 
    "Content-Type"="application/json"
}

foreach ($resource in $resources.data) {
    $resourceId = $resource.id
    $resourceName = $resource.attributes.name
    Write-Host "Found resource $resourceName (id=$resourceId)"
}

$resourceNameToDelete = Read-Host "Please enter the resource name to be deleted"
$resourceIdToDelete = ""

foreach ($resource in $resources.data) { 
    $resourceName = $resource.attributes.name
    if ($resourceNameToDelete -eq $resourceName) {
        $resourceIdToDelete = $resource.id
    }
}

Write-Host "Resource with id=$resourceIdToDelete will be deleted"

$response = Invoke-WebRequest  -Method Delete -Uri "$controllerUrl/rest/resources/$resourceIdToDelete" -Header @{ 
    "Content-Type"="application/json"
}
if($response.StatusCode -lt 300) {
    Write-Host $response
}