# Connect to STEP Controller API via Aplat Tunnel

This readme describes how the STEP Controller API can be accessed through Powershell scripts, to generate Reports or Clickpath Documentation.

### Clone this repository

Clone the contents of this repository, by convention under
```
cd C:\dev\nfrt\step\plans
git clone https://gitlab.pnet.ch/nfrt/step/plans/automation-package-kickstart
```

### Install and configure AplatESTunnel

The [AplatESTunnel](https://confluence.pnet.ch/display/SMMW/AplatESTunnel) allows the strong authorization towards pfportal-test.pnet.ch, which is required to connect to the STEP controllers.

Download the latest version of `aplat-es-tunnel-package-*-packageWindows.zip` from the [repository](https://repo.pnet.ch/ui/native/aplat-maven-releases-local/ch/postfinance/aplat/aplat-es-tunnel-package/).

Extract the contents of the package, ideally in `C:\dev\AplatTunnel` for consistency with the the convention of having all development related data in `C:\dev`.

Create the file `C:\Users\[your user name]\.AplatESTunnel\AplatESTunnel.properties` using the [example content](./AplatESTunnel.example.properties). 

Launch the tunnel by executing the `bin\startTunnel.bat` batch file.

With the example configuration, the Aplat tunnel will 
 * Request YubiKey authorization (keep in mind that the YubiKey needs to be inserted before launch, otherwise it will fail)
 * Map `https://pfportal-test.pnet.ch/step-selenium, https://pfportal-test.pnet.ch/step-selenium-intranet` to `http://127.0.0.1/step-selenium, http://127.0.0.1/step-selenium-intranet` respectively. 
 * **Take note of the 127.0.0.1 URL as it will be used later to configure Maven**

If you need access to another step instance, add or modify it as a comma-separated list to the `aplat.tunnel.contexts`.

> [!CAUTION]
> Only use the http unencrypted connection to 127.0.0.1 on your own laptop, do not configure on a server which could be acessible through another computer


### Generate a STEP API Key

The STEP API Connections are configured through a Maven configuration file, later used in the "Automation Package Kickstart" section to compile and run automation packages. Configure Maven by modifying the `settings.xml` file in `C:\Users\[your user name]\.m2\settings.xml`, using the example content in [the provided example file](./settings.example.xml), and setting the STEP API key and the mapped STEP controller url (starting with http://127.0.0.1/...) as configured in the Aplat ES Tunnel.

The STEP Maven plugin as well as all Powershell scripts accessing the STEP controller require an API key for authentication. To Issue such a key, use the following steps:

 * Navigate to User Settings -> Generate new Key: 

 ![Navigate to User Settings -> Generate new Key](figures/navigate-generate-key.png)

 * Enter a Label for your reference and press "Generate new Key"
 
 ![Enter a Label for your reference and press "Generate new Key"](figures/generate-key.png)

 * Copy the key
 
 ![Copy the key](figures/copy-key.png)

 * Indicate the key in the provided location in `C:\Users\[your user name]\.m2\settings.xml`

# Generate Clickpath documentation

The STEP controller API can be used to automatically generate ClickPath Documentation

For this, in your plan, set the following parameters:

Set the attchment quota to a high value when the *makeActionDocumentationScreenshot* parameter is set to true:

![Attachment quota for xpaths](figures/attachment-quota.png)

Remember to set it up so that the setting is skipped if the flag *makeActionDocumentationScreenshot* is not set, to avoid cluttering the MongoDB database.

Additionally, there is a xpath you can set once in the beginning of any scope (plan/session) to identify elements which can potentially contain CID data as follows:

![Protected XPath Settings](figures/protect-data-xpath-setting.png)

In commonly used clickpaths, add the string "@common" to indicate to the clickpath generation script that the plan is shared among plans, also use the "Description" field in any plan node liberally to make the documentation more readable.

![Common plans](figures/common-plans.png)

Execute the plan with the parameter "Make Documentation Screenshots" set to true:

![Execution params](figures/generate-clickpath-execution-params.png)

Copy the Project name and execution id, and execute the script "Download-Clickpaths.ps1" in an empty directory like so:

![Download Clickpaths](figures/projectname-executionId.png)

In a Powershell Prompt:
```
\dev\nfrt\step\plans\automation-package-kickstart\confluence-scripts\Download-Clickpaths.ps1 -projectName "Kryptohandel" -executionId "66be0d55eae3a73d1b45b7d4"
```

This will create a directory "clickpaths" with a Clickpaths.md and jpg files with annotated Screenshots. First check that all CID data has been grayed out appropriately.

Then, Create a new page, go to the attachments select all jpgs and drag and drop them onto the upload area.

After all images have been uploaded, Click add Content, select "Markup", paste the content in Clickpaths.md into it. Click insert, and the automatically generated page should show.

# Automation Package Kickstart

This readme describes how existing STEP projects can be converted to a setup with automation package and execution from your IDE. `Build-Automation-Package.ps1` can be used to generate the necessary folder structure and files from scratch. It downloads all plan yaml files from the controller for a given project, and configures the automation package for compilation and execution.

## Prerequisites

Before executing `Build-Automation-Package.ps1` the following steps need to be undertaken to install prerequisites:

### Install all prerequisites according to the section "Aplat Tunnel"

This is a prerequisite to connect to the STEP controller API.

### Install Scoop, Maven, Python, and IDE

First `scoop` needs to be installed. This is a package manager which allows the installation of additional software. 

According to the [manual](https://gitlab.pnet.ch/windows-client/scoop-scripts/-/tree/main#installation), this can be achieved by executing the following command in a powershell prompt:

```
iex (iwr 'https://gitlab.pnet.ch/windows-client/scoop-scripts/raw/main/scoopInstaller.ps1').Content
```

Then, the following apps are recommended to be installed:

### Install Maven

Maven is a command line tool for compilation and packaging of JAVA packages. This is required to build the automation package.
```
scoop install main/maven
```

### Developer IDE (IntelliJ or VSCode)

You can install **IntelliJ** according to the [Software Bereitstellung Instructions](https://confluence.pnet.ch/pages/viewpage.action?spaceKey=DT7&title=PostFinance+Software-Bereitstellung#PostFinanceSoftwareBereitstellung-2.Softwareliste)

Alternatively, VSCode can be used, which is a lightweight editor with many plugins:
```
scoop install extras/vscode
```

### Python for Composite Keyword exports (optional)

The STEP API does not currently provide yaml exports for composite keywords. If your project contains composite keywords,  `Build-Automation-Package.ps1` instead downloads a json export of the keyword, and "prettyfies" (makes it readable) with python. For this to work, python needs to be installed for the prettification process:

```
scoop install python
```

## Connect the Aplat ES Tunnel

* Make sure to insert your YubiKey
* Launch the tunnel by executing the `bin\startTunnel.bat` batch file in your Aplat ES Tunnel installation root
* Authorize the tunnel by entering the PIN in the dialog and touching your YubiKey

## Initial import of Automation package files

`Build-Automation-Package.ps1` 
* connects through the tunnel to the STEP controller you indicated in the Maven settings.xml file
* downloads the Automation package yaml files into `src\main\resources\plans` and applies some necessary conversions (subplan calls are changed from calls by id to calls by plan name, i.e.)
* downloads composite keyword json representations into `src\main\resources\composites` for documentation purposes. These will not be active in the automation package, as this is not yet supported by the automation package API. Once this becomes available, composite keywords will also be included in the automation packages.
* generates `src\main\resources\automation-package.yaml` which contains the references to all plans in the automation package, see [Automation Package descriptor](https://step.exense.ch/knowledgebase/devops/automation-package-yaml/) in the STEP knowledge base.
* generates `pom.xml` which contains the information for Maven to connect to the right STEP controller, and allows packaging, deployment and execution, see [Maven plugin](https://step.exense.ch/knowledgebase/devops/ap-maven-plugin/) in the STEP knowledge base.

For proper usage, use a powershell prompt
* Change directory to the local clone root of a git repository in the [STEP plans subproject](https://gitlab.pnet.ch/nfrt/step/plans).
```
cd C:\dev\nfrt\step\plans\[your-git-project]
```
* execute 
```
..\automation-package-kickstart\Build-Automation-Package -projectName "[ProjectName]" -planToExecute "[PlanName]" -gitName "[your-git-project]"
```
where
* [ProjectName] is the name of the STEP project
* [PlanName] is the name of a plan which should be executed upon execution of "mvn package". Can be changed later in pom.xml

## Package and execute automation package

Now the just created automation package can be packaged and executed using Maven using:

```
mvn package
```

The associated output should something similar like

```[INFO] Step project name: Common
[INFO] Current tenant: Common (5ecf7070c62fe648ec01b857). Is global: false
[INFO] All detected project artifacts: [com.postfinance.testing.plans:common-selenium-ap:0.0.1-SNAPSHOT]
[INFO] Resolved artifact: com.postfinance.testing.plans:common-selenium-ap:0.0.1-SNAPSHOT
[INFO] Execution(s) started in Step:
[INFO] - 'Keywords_Smoke' (http://127.0.0.1/step-selenium#/root/executions/667c11bfe94c580531a7add4)
[INFO] Waiting for execution(s) to complete...
[INFO] Execution 'Keywords_Smoke' (http://127.0.0.1/step-selenium#/root/executions/667c11bfe94c580531a7add4) succeeded. Result status was PASSED
```

and you can check the execution at the provided url by opening in a Browser. In this case, the "planToExecute" setting in `pom.xml` was `Keywords_Smoke`.

For more information, please refer to the [STEP knowledge base](https://step.exense.ch/knowledgebase/devops/).

Automated Report Generation
---------------------------

The documentation for automated report generation, defect tracking and test announcment generation is given in the corresponding [subdirectory](confluence-scripts/report).