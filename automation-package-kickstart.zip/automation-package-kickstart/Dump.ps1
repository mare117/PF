
$controllerpod = $(kubectl get pods | ForEach-Object { ($_ -split " ")[0] }) | Where-Object { $_.StartsWith("step-controller") }
$namespace = (kubectl describe pods/$controllerpod | Where-Object { $_ -match  "^Namespace:.*" }) -replace "Namespace:\s*", ""

$confirmation = Read-Host "This is about to create a dump of the controller container in $controllerpod in namespace $namespace. Please confirm [Y/n]"

if ($confirmation -eq "Y" -or $confirmation -eq "") {
   $iterations = 5
   $dumpName = "\\pfnaspn\NeoLoadProjekte$\step upgrade\dump_$($namespace)_$($controllerpod)_$(Get-Date -Format "yyyyMMdd_HHmm").txt"

   kubectl exec $controllerpod -c step-controller -it  -- /bin/bash -c "echo '' > /tmp/dump.txt; for k in `seq $iterations`; do jstack 9 >> /tmp/dump.txt; sleep 1; done"
   kubectl cp  -c step-controller "${controllerpod}:/tmp/dump.txt" $dumpName
} else {
   Write-Host "Dump skipped"
}