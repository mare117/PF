Function Get-EmptyQCArtefact {
    Param (
        $type="defect"
    )
    return @{
        Fields = @()
        Type=$type
        "children-count"=0
    }
}