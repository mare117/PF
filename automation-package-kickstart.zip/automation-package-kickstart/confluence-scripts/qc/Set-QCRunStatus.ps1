Function Set-QCRunStatus  {

    param(
        $context
    )

    if ($null -eq $context.qcSession) {
        Write-Warning "QC Session not set, log in with `$qc = ..\automation-package-kickstart\confluence-scripts\qc\Get-QCSession.ps1 once and then launch Write-Report with -qcSession `$qc"
        return
    }

    $openDefects = $context.state.current.defects | Where-Object { 
        $_.newInExecution -le $context.attachmentSuffix -and (-not $_.validated -or $defect.validatedInExecution -ge $context.attachmentSuffix)
    }

    foreach($openDefect in $openDefects) {

        if ($null -eq $openDefect.qcId -or $null -eq $openDefect.targetRelease) {
            $jiraIssue = Invoke-RestMethod -Uri "https://issues.pnet.ch/rest/api/2/issue/$($openDefect.key)" -Headers $context.jiraHeaders
            
            if ($null -ne $jiraIssue.fields.customfield_10806) {
                $openDefect | Add-Member -NotePropertyName qcId -NotePropertyValue ($jiraIssue.fields.customfield_10806 -replace "QCPF:", "") -Force
            }

            if ($null -ne $jiraIssue.fields.customfield_11401 -and $null -ne $jiraIssue.fields.customfield_11401.value) {
                $openDefect | Add-Member -NotePropertyName targetRelease -NotePropertyValue $jiraIssue.fields.customfield_11401.value -Force
            } else {
                Write-Host "Setting Target Release $($context.projectInfo.releaseNumber) of Defect $($openDefect.key)"
                $null =  Invoke-RestMethod -Uri "https://issues.pnet.ch/rest/api/2/issue/$($openDefect.key)" -Headers $context.jiraHeaders -Method Put -Body (
                @{
                    fields=@{
                        customfield_11401=@{
                            value=$context.projectInfo.releaseNumber
                        }
                    }
                } | ConvertTo-Json)
                $openDefect | Add-Member -NotePropertyName targetRelease -NotePropertyValue $context.releaseNumber
            }
        }
    }
    $openDefectQCIds = $openDefects.qcId | Where-Object { $null -ne $_ }

    $qcSession = $context.qcSession
    foreach($qcSet in $context.projectInfo.qcTestSets) {
        foreach($testInstanceId in $qcSet.testInstanceIds) {

            
           
            $defectLinks = Invoke-RestMethod -Method Get -Uri "$($qcSession.baseUrl)/rest/domains/PF/projects/QCPF/defect-links?query={second-endpoint-type[test-instance];second-endpoint-id[$testInstanceId]}" -Headers $qcSession.headers -UseBasicParsing -WebSession $qcSession.webSession
            $currentDefectIds = $defectLinks.entities | ForEach-Object { Get-QCFieldValue $_ "first-endpoint-id" }
            
            $defectsToRemove = $currentDefectIds | Where-Object { -not ($openDefectQCIds -contains $_) }
            $defectsToAdd = $openDefectQCIds | Where-Object { -not ($currentDefectIds -contains $_) }

            foreach($defectLink in $defectLinks.entities) {
                $defectId = Get-QCFieldValue $defectLink "first-endpoint-id";
                if ($defectsToRemove -contains $defectId) {
                    $id = Get-QCFieldValue $defectLink "id";
                    Write-Host "Test instance $($testInstanceId): Removing defect $defectId, link id $id"
                    $null = Invoke-RestMethod -Method Delete -Uri "$($qcSession.baseUrl)/rest/domains/PF/projects/QCPF/defect-links/$id" -Headers $qcSession.headers -UseBasicParsing -WebSession $qcSession.webSession
                }
            }
            foreach($defectId in $defectsToAdd) {
                Write-Host "Test instance $($testInstanceId): Adding defect $defectId"
                $null = Invoke-RestMethod -Method Post -Uri "$($qcSession.baseUrl)/rest/domains/PF/projects/QCPF/defect-links" -Headers $qcSession.headers -UseBasicParsing -WebSession $qcSession.webSession -Body @"
                    <Entity Type="defect-link">    
                        <Fields>
                            <Field Name="second-endpoint-type"><Value>test-instance</Value></Field>
                            <Field Name="second-endpoint-id"><Value>$testInstanceId</Value></Field>
                            <Field Name="first-endpoint-id"><Value>$defectid</Value></Field>
                        </Fields>
                    </Entity>
"@
            }

            $runs = Invoke-RestMethod -Method Get -Uri "$($qcSession.baseUrl)/rest/domains/PF/projects/QCPF/runs?query={testcycl-id[$testInstanceId]}" -Headers $qcSession.headers -UseBasicParsing -WebSession $qcSession.webSession

            $run = $runs.entities | Where-Object { (Get-QCFieldValue $_ "name") -eq $context.qcRunName }

            if ($null -eq $run) {
                $run = Start-QCRun $context $testInstanceId
            } else {
                "TestInstance $($testInstanceId): Test already started"
            }

            $currentStatus = (Get-QCFieldValue $run "status");
            $newStatus = if ($context.passed) {'Passed'} else {'Failed'};
            if ($currentStatus -ne $newStatus) {
                Write-Host "Updating status for QC Test $testInstanceId"
                $runId = Get-QCFieldValue $run "id"
                $run = Invoke-RestMethod -Method Put -Uri "$($qcSession.baseUrl)/rest/domains/PF/projects/QCPF/runs/$runId" -Headers $qcSession.headers -UseBasicParsing -WebSession $qcSession.webSession -Body  @"
                    <Entity Type="run">
                        <Fields>
                            <Field Name="status"><Value>$(if ($context.passed) {'Passed'} else {'Failed'})</Value></Field>
                        </Fields>
                    </Entity>
"@
            } else {
                "TestInstance $($testInstanceId): Test already completed"
            }

        }
    }
}


Function Start-QCRuns  {

    param(
        $context
    )

    if ($null -eq $context.qcSession) {
        Write-Warning "QC Session not set, log in with `$qc = ..\automation-package-kickstart\confluence-scripts\qc\Get-QCSession.ps1 once and then launch Write-Report with -qcSession `$qc"
        return
    }

    $qcSession = $context.qcSession
    foreach($qcSet in $context.projectInfo.qcTestSets) {
        foreach($testInstanceId in $qcSet.testInstanceIds) {


            $runs = Invoke-RestMethod -Method Get -Uri "$($qcSession.baseUrl)/rest/domains/PF/projects/QCPF/runs?query={testcycl-id[$testInstanceId]}" -Headers $qcSession.headers -UseBasicParsing -WebSession $qcSession.webSession

            $run = $runs.entities | Where-Object { (Get-QCFieldValue $_ "name") -eq $context.qcRunName }

            if ($null -eq $run) {
                $run = Start-QCRun $context $testInstanceId
            } else {
                "TestInstance $($testInstanceId): Test already started"
            }
        }
    }
}


Function Start-QCRun {

    param($context, $testInstanceId) 
    
    $qcSession = $context.qcSession

    Write-Host "Starting QC Test $testInstanceId"

    $testInstance = Invoke-RestMethod -Method Get -Uri "$($qcSession.baseUrl)/rest/domains/PF/projects/QCPF/test-instances/$($testInstanceId)" -Headers $qcSession.headers -UseBasicParsing -WebSession $qcSession.webSession
    $testId = Get-QCFieldValue $testInstance "test-id"

    return Invoke-RestMethod -Method Post -Uri "$($qcSession.baseUrl)/rest/domains/PF/projects/QCPF/runs" -Headers $qcSession.headers -UseBasicParsing -WebSession $qcSession.webSession -Body @"
        <Entity Type="run">    
            <Fields>
                <Field Name="name"><Value>$($context.qcRunName)</Value></Field>
                <Field Name="test-id"><Value>$testId</Value></Field>
                <Field Name="testcycl-id"><Value>$testInstanceId</Value></Field>
                <Field Name="subtype-id"><Value>hp.qc.run.MANUAL</Value></Field>
                <Field Name="owner"><Value>$($env:USERNAME)</Value></Field>   
                <Field Name="status"><Value>Not Completed</Value></Field>   
            </Fields>
        </Entity>
"@                
}
    
Function Get-QCFieldValue {
    param($entity, $fieldName) 

    return ($entity.Fields | Where-Object {$_.Name -eq $fieldName}).values.value
}