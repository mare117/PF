

. "$PSScriptRoot\Add-QCArtefactProperty.ps1"
. "$PSScriptRoot\Get-EmptyQCArtefact.ps1"


Function Get-NewQCDefectArtefact {
    
    $defectProperties=@{
        hltc = "GS2107-30644"
        project = "MetisVA"
        release = "RE24D"
        pi = "0000"
        title = "Voicebot Ausfälle und höhere Antwortzeiten"
        luid = "QCPF00093067"
        detectedBy = $env:USERNAME
        qcSeverity = "1_Major"
        qcPriority = "1_High"
        jiraPriority = "Critical"
        testEnvironment = "T-SYS"
        qcProject = "QCPF"
        status = "Assigned"
        owner="vonniederhbe"
        jiraComment=""
        description="NFRT Label: ""L&P - Client Facing"""
        devComments=""
    }

    $artefact = Get-EmptyQCArtefact "defect"
    Add-QCArtefactProperty $artefact "dev-comments" $defectProperties.devComments
    Add-QCArtefactProperty $artefact "name" "L&P $($defectProperties.project) $($defectProperties.hltc) $($defectProperties.title)"
    Add-QCArtefactProperty $artefact "user-28" $defectProperties.luid
    Add-QCArtefactProperty $artefact "severity" $defectProperties.qcSeverity
    Add-QCArtefactProperty $artefact "owner" $defectProperties.owner
    Add-QCArtefactProperty $artefact "detected-by" $defectProperties.detectedBy
    Add-QCArtefactProperty $artefact "priority" $defectProperties.qcPriority
    Add-QCArtefactProperty $artefact "user-30" $defectProperties.project
    Add-QCArtefactProperty $artefact "user-27" $defectProperties.qcProject
    Add-QCArtefactProperty $artefact "detected-in-rcyc" "$($defectProperties.release)_System_Stufe" -ReferenceValue
    Add-QCArtefactProperty $artefact "user-01" (if ($defectProperties.pi -eq "0000") {"Regression"} else { "Projekt" })
    Add-QCArtefactProperty $artefact "user-02" $defectProperties.pi
    Add-QCArtefactProperty $artefact "status" $defectProperties.status
    Add-QCArtefactProperty $artefact "user-08" $defectProperties.testEnvironment
    Add-QCArtefactProperty $artefact "user-07" $defectProperties.project
    Add-QCArtefactProperty $artefact "target-rel"  $defectProperties.release -ReferenceValue
    Add-QCArtefactProperty $artefact "user-34" $defectProperties.jiraPriority
    Add-QCArtefactProperty $artefact "detected-in-rel" $defectProperties.release -ReferenceValue
    Add-QCArtefactProperty $artefact "description" $defectProperties.description
    <#
    Add-QCArtefactProperty $artefact "has-others-linkage" "N"
    Add-QCArtefactProperty $artefact "attachment" "Y"
    
    
    Add-QCArtefactProperty $artefact "user-14" "HCRM-2416"
    Add-QCArtefactProperty $artefact "creation-time" "2024-07-31"
    Add-QCArtefactProperty $artefact "id" "93067"
    Add-QCArtefactProperty $artefact "reproducible" "Y"
    Add-QCArtefactProperty $artefact "has-linkage" "N"
    Add-QCArtefactProperty $artefact "ver-stamp" "12"
    Add-QCArtefactProperty $artefact "user-25" $defectProperties.jiraComment
    Add-QCArtefactProperty $artefact "last-modified" "2024-08-15 09:05:20"
    
    Add-QCArtefactProperty $artefact "request-id"
    Add-QCArtefactProperty $artefact "detection-version" ""
    Add-QCArtefactProperty $artefact "step-reference"
    Add-QCArtefactProperty $artefact "subject"
    Add-QCArtefactProperty $artefact "project" ""
    Add-QCArtefactProperty $artefact "cycle-id"
    Add-QCArtefactProperty $artefact "user-33" ""
    Add-QCArtefactProperty $artefact "user-31" ""
    Add-QCArtefactProperty $artefact "request-note" ""
    Add-QCArtefactProperty $artefact "run-reference"
    Add-QCArtefactProperty $artefact "user-32"
    Add-QCArtefactProperty $artefact "to-mail" ""
    Add-QCArtefactProperty $artefact "task-status" ""
    Add-QCArtefactProperty $artefact "user-29" ""
    Add-QCArtefactProperty $artefact "test-reference"
    Add-QCArtefactProperty $artefact "extended-reference" ""
    Add-QCArtefactProperty $artefact "closing-version" ""
    Add-QCArtefactProperty $artefact "closing-date"
    Add-QCArtefactProperty $artefact "target-rcyc" ""
    Add-QCArtefactProperty $artefact "user-17" ""
    Add-QCArtefactProperty $artefact "request-type" ""
    Add-QCArtefactProperty $artefact "user-11" ""
    Add-QCArtefactProperty $artefact "actual-fix-time"
    Add-QCArtefactProperty $artefact "user-10" ""
    Add-QCArtefactProperty $artefact "user-13" ""
    Add-QCArtefactProperty $artefact "request-server" ""
    Add-QCArtefactProperty $artefact "estimated-fix-time"
    Add-QCArtefactProperty $artefact "cycle-reference" ""
    Add-QCArtefactProperty $artefact "user-09" ""
    Add-QCArtefactProperty $artefact "user-06" ""
    Add-QCArtefactProperty $artefact "environment" ""
    Add-QCArtefactProperty $artefact "planned-closing-ver" ""
    Add-QCArtefactProperty $artefact "has-change" ""
    Add-QCArtefactProperty $artefact "user-05" ""
    Add-QCArtefactProperty $artefact "user-03" ""
    #>
    return $artefact
}