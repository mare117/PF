Function Add-QCArtefactProperty {
    Param(
        $artefact,
        $Name,
        $value=$null,
        [switch] $ReferenceValue
    )

    if ($null -eq $Value) { 
        $artefact.Fields.Add(
            @{
                Name=$Name
                values=@()
            }
        )   
    } else {
        if ($ReferenceValue) {
            $artefact.Fields.Add(
                @{
                    Name=$Name
                    values=@(,@{ReferenceValue=$value})
                }
            )
        } else {
            $artefact.Fields.Add(
                @{
                    Name=$Name
                    values=@(,@{value=$value})
                }
            )   
        }
    }
}