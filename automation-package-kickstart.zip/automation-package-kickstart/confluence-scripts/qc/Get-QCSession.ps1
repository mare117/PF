$headers = @{ 
    "cache-control"="no-cache"
    "Content-Type"="application/json"
    "Accept"="application/json"
}

$credential = Get-Credential

$baseUrl="https://qualitycenter.pnet.ch/qcbin"

$null = Invoke-RestMethod -Method Post -Uri "$baseUrl/authentication-point/authenticate" -Headers $headers -UseBasicParsing -Credential $credential -SessionVariable session 
$null = Invoke-RestMethod -Method Post -Uri "$baseUrl/rest/site-session" -Headers $headers -UseBasicParsing -WebSession $session 
Write-Host $session $baseUrl
$cookies = $session.Cookies.GetCookies($baseUrl)
$xsrfToken = ($cookies | Where-Object { $_.name -eq "XSRF-TOKEN" }).value

$headers = @{ 
    "Content-Type"="application/xml"
    "Accept"="application/json"
    "X-XSRF-TOKEN"=$xsrfToken
}

return @{
    webSession=$session
    headers=$headers
    baseUrl=$baseUrl
}