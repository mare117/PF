
Function Set-UserJournalEntries {    
    Param(
        $journal,
        $prompt
    )

    if ($prompt -ne "" -and $prompt -ne "stop") {
        
        $nowTime = (Get-Date).ToString("HH:mm")
        $time = Read-Host "Indicate the time the event occured [$nowTime]"
        if ($time -eq "") { $time = $nowTime }

        $remark = Read-Host "Indicate a remark (may be empty)"

        $journal.timeline += @(@{
            time=(New-TimeSpan -Start ([datetime] "01/01/1970 01:00Z") -End (Get-Date $time)).TotalSeconds * 1000
            description=[System.Net.WebUtility]::HtmlEncode($prompt)
            remark=[System.Net.WebUtility]::HtmlEncode($remark)
        })
    }

}