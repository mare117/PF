Function Set-Controller {    
    Param(
        $controller
    )

    Write-Host "[STEP] Switching to controller $($controller.controllerUrl)"

    if ($controller.controllerUrl.startsWith("https://")) {
        $null = Import-Certificate "$($env:USERPROFILE)\.AplatESTunnel\truststoreForClient.pem" -CertStoreLocation "Cert:\CurrentUser\Root"
    }

    $null = Invoke-RestMethod -UseBasicParsing -Method Post -Uri "$($controller.controllerUrl)/rest/tenants/current" -Body $controller.projectName -Header @{ 
        "Content-Type"="application/json"
        "Authorization"="Bearer $($controller.token)"
    }
}