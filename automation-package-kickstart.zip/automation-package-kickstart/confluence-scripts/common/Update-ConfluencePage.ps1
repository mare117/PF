Function Update-ConfluencePage {    
    Param(
        $context,
        $body = $null,
        $id,
        $filesToUpload = $null,
        $current = $null
    )
    $headers = $context.confluenceHeaders

    if ($null -eq $current) {
        Write-Host "[Confluence] Get current page... https://confluence.pnet.ch/pages/viewpage.action?pageId=$($id)"
        $current = Invoke-RestMethod -Method Get -Uri "https://confluence.pnet.ch/rest/api/content/$($id)?expand=body.storage,version,ancestors" -Headers $headers -UseBasicParsing
    }
    
    try {
        if ($null -ne $body) {
            $current.body.storage.value = $body;
            $current.version = @{
                number = $current.version.number + 1
                message = "Updated via API"
            }
            $current.ancestors = @(, @{
                id=($current.ancestors | Select-Object -Last 1).id
            })
            
            Write-Host "[Confluence] Update page https://confluence.pnet.ch/pages/viewpage.action?pageId=$id"

            # Convert the JSON body to UTF-8 bytes ourselves. If we hand a string to -Body,
            # Windows PowerShell 5.1 ignores our charset=utf-8 header and serializes using
            # the system's ANSI codepage (CP1252 on most Windows boxes), which corrupts
            # German umlauts and other non-ASCII characters before they reach Confluence.
            $jsonBody  = $current | ConvertTo-Json -Depth 20 -Compress
            $bodyBytes = [System.Text.Encoding]::UTF8.GetBytes($jsonBody)

            $null = Invoke-RestMethod -Method Put -Uri "https://confluence.pnet.ch/rest/api/content/$($id)" -Headers $headers -UseBasicParsing -Body $bodyBytes
        }

    
        if ($null -ne $filesToUpload) {

            Write-Host "[Confluence] Get current page attachments..."
            $currentAttachments = Invoke-RestMethod -Method Get -Uri "https://confluence.pnet.ch/rest/api/content/$($current.id)/child/attachment?limit=1000" -Headers $headers -UseBasicParsing
            
            Add-Type -AssemblyName System.Net.Http
            $uploadedFiles = @()
            foreach($file in $filesToUpload) {
                if (-not $uploadedFiles.Contains($file.name)){
                    Write-Host "[Confluence] Upload attachment $($file.name)"

                    $client = [System.Net.Http.HttpClient]::new()
                    $client.DefaultRequestHeaders.Authorization = $headers.Authorization
                    $client.DefaultRequestHeaders.Add("X-Atlassian-Token", "nocheck");

                    $content = [System.Net.Http.MultipartFormDataContent]::new()
                    $bytes = [System.IO.File]::ReadAllBytes((Resolve-Path $file.path))
                    $byteContent = [System.Net.Http.ByteArrayContent]::new($bytes)
                    $byteContent.Headers.ContentType = [System.Net.Http.Headers.MediaTypeHeaderValue]::Parse("application/octet-stream")

                    $content.Add($byteContent, "file", $file.name)

                    $attachmentId = ($currentAttachments.results | Where-Object { $_.title -eq $file.name }).id
                    if ($null -ne $attachmentId) {
                        $response = $client.PostAsync("https://confluence.pnet.ch/rest/api/content/$($id)/child/attachment/$attachmentId/data", $content).Result
                    } else {
                        $response = $client.PostAsync("https://confluence.pnet.ch/rest/api/content/$($id)/child/attachment", $content).Result
                    }
                    $null = $response.Content.ReadAsStringAsync().Result

                    $uploadedFiles += @($file.name)
                }
            }
        }
    } catch {
        Write-Host $_.Exception
        $body | Out-File body.html -Encoding UTF8
        Start-Process body.html
        if ($null -ne $_.Exception.Response) {
            $result = $_.Exception.Response.GetResponseStream()
            $reader = New-Object System.IO.StreamReader($result)
            $reader.BaseStream.Position = 0
            $reader.DiscardBufferedData()
            Write-Host  $reader.ReadToEnd();
        }
    }
}