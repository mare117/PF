. "$PSScriptRoot\Set-Controller.ps1"

Function Get-ControllerForProject {    
    Param(
        $context,
        $projectName
    )
    $controller = if ("" -eq "$projectName") {$context.controllers[0]} else { ($context.controllers | Where-Object { $_.projectName -eq $projectName }) | Select-Object -First 1 }
    Set-Controller $controller
    return $controller
}



