
Function Get-SplunkDashboardUrls {    
    Param(
        $projectInfo,
        $analysisStartTime,
        $analysisEndTime,
        $startTime,
        $endTime,
        $inProgress
    )



    $splunkDashboards = $()
    foreach ($dashboard in $projectInfo.splunkDashboards) {
        $splunkUrl = $dashboard.Url.Replace('[[startTime]]', (Get-SplunkUrlTime $startTime)).Replace('[[analysisStartTime]]', (Get-SplunkUrlTime $analysisStartTime))
        if ($inProgress) {
            $splunkUrl = $splunkUrl.Replace('[[endTime]]', "now").Replace('[[analysisEndTime]]', "now").Replace("[[perc]]", "perc")
        } else {
            $splunkUrl = $splunkUrl.Replace('[[endTime]]', (Get-SplunkUrlTime $endTime)).Replace('[[analysisEndTime]]', (Get-SplunkUrlTime $analysisEndTime)).Replace("[[perc]]", "exactperc")
        }

        $splunkDashboards += @(@{
            Name = $dashboard.Name
            Url  = $splunkUrl
        })
    }
    return $splunkDashboards
}

Function Get-SplunkUrlTime($time) {
    return $time.ToString("yyyy-MM-dd") + "T" + $time.ToString("HH:mm:ss.000").Replace(":", "%3A")
}
