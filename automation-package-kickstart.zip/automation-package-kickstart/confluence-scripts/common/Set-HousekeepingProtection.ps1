
Function Set-HousekeepingProtection {    
    Param(
        $context
    )
    foreach($controller in $context.controllers) {
        Set-Controller $controller
        foreach($execution in $controller.executions) {
            Write-Host "[STEP] Set Housekeeping protection for execution $($execution.id) ($($execution.description))"
            $null = Invoke-RestMethod -UseBasicParsing -Method Post -Uri "$($controller.controllerUrl)/rest/housekeeping/execution/$($execution.id)/protection" -Body "true"  -Headers @{ 
                "Content-Type"="application/json"
                "Authorization"="Bearer $($controller.token)"
            }
        } 
    }
}