Function Get-UtfEncodedConfluencePage {
    param(
        $id,
        $headers
    )
    $resp = Invoke-WebRequest -Method Get -Uri "https://confluence.pnet.ch/rest/api/content/$($id)?expand=body.storage,space,version,ancestors" -Headers $headers -UseBasicParsing
    $json = [System.Text.Encoding]::UTF8.GetString($resp.RawContentStream.ToArray())
    return $json | ConvertFrom-Json
}