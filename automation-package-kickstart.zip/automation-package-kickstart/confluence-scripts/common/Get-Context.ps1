
. "$PSScriptRoot\Set-Controller.ps1"
. "$PSScriptRoot\Get-SplunkDashboardUrls.ps1"

Function Get-Context {    
    Param(
        $executionIds,
        $projectInfo,
        $passed,
        $partial,
        $inProgress,
        $reuploadAttachments,
        $qcSession,
        $scope,
        $analysisStartTime = 0
    )


    $controllerList = @()
    $timeline = @()

    foreach ($mvnSetting in $projectInfo.mvnSettings) {
        $mvnSettingName = $mvnSetting.mvnSettingName
        $projectName = $mvnSetting.projectName

        Write-Host "[INFO] Fetching context for mvnSettingName: $mvnSettingName with project: $projectName"

        $token = (Select-Xml  -Path "$env:USERPROFILE\.m2\settings.xml" -XPath "//settings:profile[settings:id='$mvnSettingName']//settings:step.auth-token" -Namespace @{settings="http://maven.apache.org/settings/1.0.0"}).Node.InnerText
        $controllerUrl = (Select-Xml  -Path "$env:USERPROFILE\.m2\settings.xml" -XPath "//settings:profile[settings:id='$mvnSettingName']//settings:step.url" -Namespace @{settings="http://maven.apache.org/settings/1.0.0"}).Node.InnerText
        $friendlyControllerUrl = (Select-Xml  -Path "$env:USERPROFILE\.m2\settings.xml" -XPath "//settings:profile[settings:id='$mvnSettingName']//settings:step.friendly-url" -Namespace @{settings="http://maven.apache.org/settings/1.0.0"}).Node.InnerText
        $confluenceToken = (Select-Xml  -Path "$env:USERPROFILE\.m2\settings.xml" -XPath "//settings:profile[settings:id='$mvnSettingName']//settings:confluence.auth-token" -Namespace @{settings="http://maven.apache.org/settings/1.0.0"}).Node.InnerText
        $jiraToken = (Select-Xml  -Path "$env:USERPROFILE\.m2\settings.xml" -XPath "//settings:profile[settings:id='$mvnSettingName']//settings:jira.auth-token" -Namespace @{settings="http://maven.apache.org/settings/1.0.0"}).Node.InnerText
        
        
        $controller = @{
            controllerUrl = $controllerUrl
            friendlyControllerUrl = $friendlyControllerUrl
            executions = @()
            timeline = $timeline
            token = $token
            projectName = $projectName
        }

        Set-Controller $controller

        Write-Host "[STEP] Get currently running executions and executions by id"
        
        $filters = @(
            $executionIds | ForEach-Object { @{
                field="id"
                type="Equals"
                expectedValue=$_
            }}
        )
        if ($inProgress) {
            $filters += @(@{
                field="status"
                type="Equals"
                expectedValue="RUNNING"
            })
        }

        if ($filters.Count -gt 0) {

            $executionResults = Invoke-RestMethod -UseBasicParsing -Method Post -Uri "$($controllerUrl)/rest/table/executions" -Body (@{
                skip=0
                limit=100
                filters=@(,@{
                    collectionFilter=@{
                        type="Or"
                        children=$filters
                    }
                })
            } | ConvertTo-Json -Depth 10)  -Headers @{ 
                "Content-Type"="application/json"
            }
            $controller.executions = $executionResults.data
        } else {
            $controller.executions = @()
        }

        if ($controller.executions.Count -gt 0) {
            $timeline += @($controller.executions| ForEach-Object {
                @{
                    time=$_.startTime
                    description="<a href=""$($friendlyControllerUrl)/#/executions/$($_.id)/steps?tenant=$projectName"">Execution of $($_.description)</a> started"
                }
            }) + @($controller.executions | Where-Object { $null -ne $_.endTime} | ForEach-Object {
                @{
                    time=$_.endTime
                    description="<a href=""$($friendlyControllerUrl)/#/executions/$($_.id)/steps?tenant=$projectName"">Execution of $($_.description)</a> stopped"
                }
            })

            $controllerList += $controller
        }
        else {
            Write-Host "[INFO] No executions found for controller $mvnSettingName, skipping..."
        }
    }

    
    if ($null -ne $projectInfo.loadmodelPath) {
        Write-Host "[Context] Load NFR data"

        $nfrExcel = New-Object -comobject Excel.Application
        $workbook = $nfrExcel.Workbooks.Open($projectInfo.loadmodelPath)

        #$nameColumn = $workbook.ActiveSheet.Columns.Item(4);
        $nameColumn = $workbook.ActiveSheet.Columns.Item(1);

        $row = 3
        while($nameColumn.Rows.Item($row).Text -ne "")
        {
            $name = ($nameColumn.Rows.Item($row).Text | Out-String).Trim()
            foreach($key in $nfrs.Keys) {
                $cellValue = ($workbook.ActiveSheet.Cells.Item($row, $nfrs[$key].Col).Text | Out-String).Trim()

                if ($cellValue -ne "") {
                    $nfrs[$key].Values[$name] = ([double] $cellValue)
                }
            }
            $row++
        }
        $workbook.Close()
        $nfrExcel.Quit()
    }

    $executions = @($controllerList | ForEach-Object { $_.executions })
    $startTime = ($executions | Sort-Object -Property startTime | Select-Object -First 1).startTime

    # Get Beginning of Minute
    $startTime = [math]::Floor($startTime/60000)*60000;

    $start = ([datetime] '1970-01-01').AddSeconds($startTime / 1000.0).ToLocalTime()

    $endTime = if ($inProgress) { 
        $now = (New-TimeSpan -Start ([datetime] "01/01/1970").ToLocalTime() -End (Get-Date).ToLocalTime()).TotalSeconds * 1000
        if ($now -gt $startTime + 30*60*1000) { $now } else {$startTime + 30*60*1000 }
    } else {
        ($executions | Sort-Object -Property endTime | Select-Object -Last 1).endTime
    }
    
    # Get Beginning of Minute
    $endTime = [math]::Floor($endTime/60000)*60000;
    $end = ([datetime] '1970-01-01').AddSeconds($endTime / 1000.0).ToLocalTime()
    

    $analysisStartTime=if ($analysisStartTime -ne 0) {$analysisStartTime} else {$startTime + $projectInfo.rampUpMinutes * 60000};
    $analysisEndTime=$endTime - $projectInfo.rampDownMinutes * 60000

    $gitTag = "$($start.ToString('yyyMMdd'))_$($projectInfo.projectName)_$($projectInfo.releaseNumber)_T1"
    $pagePrefix = $start.ToString('yyyMMdd HH:mm')
    $pageTitle = $pagePrefix + " - " + $(if ($inProgress) { "XX:XX" } else {$end.ToString('HH:mm')}) + " $($projectInfo.scenarioName) - $(if ($passed) { "PASSED"} elseif ($partial) {"PARTIAL"} elseif($inProgress) {"IN PROGRESS"} else { "FAILED"})"


    $splunkDashboards = Get-SplunkDashboardUrls $projectInfo $(Get-TimeObject $analysisStartTime) $(Get-TimeObject $analysisEndTime) $(Get-TimeObject $startTime) $(Get-TimeObject $endTime) $inProgress

    $scopeArray = @()
    if ($null -ne $scope) {
        $scopeArray = $scope -split ","
    }

    $stateFile = $projectInfo.stateFile;
    if ($null -eq $stateFile) {
        $stateFile = "current-state.json"
    }
    
    return @{
        controllers = $controllerList
        projectInfo=$projectInfo
        pageTitle=$pageTitle
        pagePrefix=$pagePrefix
        attachmentSuffix=$start.ToString('yyyMMdd-HHmm')
        startTime=$startTime
        endTime=$endTime
        analysisStartTime=$analysisStartTime
        analysisEndTime=$analysisEndTime
        gitTag=$gitTag
        passed=$passed
        partial=$partial
        inProgress=$inProgress
        reuploadAttachments=$reuploadAttachments
        nfrs=$nfrs
        filesToUpload=@()
        splunkGraphsToDownload=@()
        splunkCSVsToDownload=@()
        conclusions=@()
        splunkDashboards=$splunkDashboards
        qcSession=$qcSession
        qcRunName="Performance Test $($start.ToString('dd.MM.yyy HH:mm'))"
        confluencePageUrl=""
        stepVersion=$stepVersion
        timeline=$timeline
        reporting=@{
            datetime=$start.ToString('dd.MM.yyy HH:mm')
            start_time=$start.ToString('HH:mm')
            date=$start.ToString('dd.MM.yyy')
            stop_time=if ($inProgress) { "(in progress)" } else { $end.ToString('HH:mm')}
            page_prefix=$pagePrefix
            scenario=$projectInfo.scenario
        }
        scope=$scopeArray
        confluenceHeaders=@{ 
            "Content-Type"="application/json; charset=utf-8"
            "Accept"="application/json"
            "Authorization"="Bearer $confluenceToken"
        }
        jiraHeaders=@{ 
            "Content-Type"="application/json; charset=utf-8"
            "Accept"="application/json"
            "Authorization"="Bearer $jiraToken"
        }
        statePath=$(Join-Path $projectInfo.reportCache $stateFile)
        stateFile=$stateFile
    }
}

Function Get-TimeObject($time) {
    return ([datetime] '1970-01-01').AddSeconds($time / 1000.0).ToLocalTime()
}
