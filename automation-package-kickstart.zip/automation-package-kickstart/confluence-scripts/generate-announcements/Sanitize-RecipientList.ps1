


Param(
    [Parameter(Mandatory=$false)] $reportConfigFile = ".\projectInfo.ps1",
    [Parameter(Mandatory=$false)] $date = $null,
    [Parameter(Mandatory=$false)] $startTime = $null,
    [Parameter(Mandatory=$false)] $endTime = $null
)



$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'


. "$reportConfigFile"


# Outlook starten oder bestehende Instanz verwenden
$Outlook = New-Object -ComObject Outlook.Application
$Namespace = $Outlook.GetNamespace("MAPI")

Function Get-Display($user) {
    return "$($user.Name) <$($user.PrimarySmtpAddress)>"
}


Function Get-RecipientList($label) {
    $output = @"
        $label=@(
"@

    Write-Host "Write $label list"
    $users = @{};

    $distributionLists =  @{};
    $externals = New-Object System.Collections.ArrayList;
    
    foreach ($name in $projectInfo.distributionList.$label) {
        $recipient = $Namespace.CreateRecipient($name);
        if ($recipient.Resolve()) {
            $distributionList = $recipient.AddressEntry.GetExchangeDistributionList();
            $user = $recipient.AddressEntry.GetExchangeUser();

            if ($distributionList) {
                $display = Get-Display($distributionList)
                $null = $distributionLists.$display = $distributionList;
                #Write-Host "Loading distribution list $display"
            } elseif ($user) {
                $display = Get-Display($user);
                $null = $users.$display = $user;
                #Write-Host "Loading user $display"
            } else {
                if ($name -match ".*@postfinance.ch.*") {
                    Write-Host "  $name has postfinance address but cannot be found in address book. removing" 
                } else {
                    Write-Host "  Loading external $name"
                    $null = $externals.Add($name);
                }
            }
        } else {
            Write-Host "  Could not be resolved: $name"
        }
    }

    Write-Host "Recipients loaded"

    foreach($distributionList in $distributionLists.GetEnumerator() | Sort-Object Key) {
        
        $output += @"

          "$($distributionList.Key)" # Distribution List
"@

        foreach($member in $distributionList.Value.Members) {
            
            $display = Get-Display($member.GetExchangeUser())
            
            if ($users.ContainsKey($display)) {
                Write-Host "    User $display is already contained in $($distributionList.Key), removing from set"
                $users.Remove($display);
            }
        }

    }


    Write-Host "  Distribution Lists processed"
    
    foreach($user in $users.GetEnumerator() | Where-Object { $_.Value.FirstName -eq "Mailbox" } | Sort-Object Key) {

        $output += @"

          "$($user.Key)" # Mailbox
"@
    }

    Write-Host "  Mailboxes processed"
    
    foreach($user in $users.GetEnumerator() | Where-Object { $_.Value.FirstName -ne "Mailbox" } | Sort-Object Key) {

        $output += @"

          "$($user.Key)" # User
"@
    }
    Write-Host "  PF Adressbook Users processed"
    
    foreach($user in $externals | Where-Object { -not ($_ -match "groups.post.ch@ch.teams.ms>")} | Sort-Object) {

        $output += @"

          "$user" # External
"@
    }
    Write-Host "  Externals processed"

    foreach($user in $externals | Where-Object { $_ -match "groups.post.ch@ch.teams.ms>"} | Sort-Object) {

        $output += @"

          "$user" # Teams Channel
"@
    }
    Write-Host "  Teams Channels processed"


    $output += @"

        )
"@

    return $output
}
#Get-RecipientList("To")
$distributionList = "$(Get-RecipientList("To"))`n$(Get-RecipientList("CC"))`n$(Get-RecipientList("Engineers"))"

Write-Host "Distribution List copied to clipboard"
Set-Clipboard $distributionList