
Param(
    [Parameter(Mandatory=$false)] $reportConfigFile = ".\projectInfo.ps1"
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

. "$reportConfigFile"



# Outlook starten oder bestehende Instanz verwenden
$Outlook = New-Object -ComObject Outlook.Application
$Namespace = $Outlook.GetNamespace("MAPI")

# Beispiel: Standardkalender
# $CalendarFolder = $Namespace.GetDefaultFolder(9)  # 9 = olFolderCalendar

# Beispiel: Kalender eines anderen Postfachs (freigegeben oder zusätzlich eingebunden)
$RecipientName = "Last&PerformanceTest, PF85"
$Recipient = $Namespace.CreateRecipient($RecipientName)
if ($Recipient.Resolve()) {
    $CalendarFolder = $Namespace.GetSharedDefaultFolder($Recipient, 9) # 9 = Kalender
} else {
    throw "Empfänger '$RecipientName' konnte nicht aufgelöst werden."
}



# Restrict items to the date range
$Items = $CalendarFolder.Items
$null = $Items.Sort("[Start]")

# Outlook filter format: mm/dd/yyyy hh:mm AM/PM
$Filter = "[Start] >= '$((Get-Date).ToString("g"))' AND [Start] <= '$((Get-Date).AddDays(1).ToString("g"))' AND [Categories] = '$($projectInfo.calendarCategories)'"
$RestrictedItems = $Items.Restrict($Filter)

# Output appointments
if ($RestrictedItems.Count -eq 0) {
    Write-Host "No future appointments found for $($projectInfo.calendarCategories)"
} else {
    $Mail = $Outlook.CreateItem(0);
    $Mail.Subject = "INFO: #Performancetest - $($projectInfo.scenarioName) $($projectInfo.releaseNumber) $($projectInfo.testEnvironment) - SCHEDULE"
    $null = $Mail.Display(0);
    $Document = $Mail.GetInspector.WordEditor.Application.Documents(1);
    $Selection = $Mail.GetInspector.WordEditor.Application.Selection;
    $Selection.TypeText(@"
Dear all, 

Please see attached the proposed scheduled Tests for $($projectInfo.scenarioName) in release $($projectInfo.releaseNumber).

On these dates, load is to be expected on $($projectInfo.applicationsInScope -join ", ").

Please refrain from any deployments during that time and restrict your deployments to the indicated deployment windows in 
"@)
   

    $null = $Document.HyperLinks.Add($Selection.Range, "https://confluence.pnet.ch/spaces/CMPF/pages/736133515/AAL+IT+Change+Management+PostFinance+AG+Service+Now#AALITChangeManagementPostFinanceAG%2FServiceNow-4.ChangeaufTest-Umgebung", $null, $null, "AAL IT Change Management PostFinance AG / Service Now -> 4. Change auf Test-Umgebung")

    $Selection.Font.Bold = $true
    $Selection.TypeText(@"


Also, please note that an overview of all Performance tests can be viewed by subscribing to the Calendar of "Last&PerformanceTest, PF85" in Outlook.
"@)
    
    $Selection.Font.Bold = $false
    $Selection.TypeText(@"


The performance test strategy can be found at 
"@)
    $null = $Document.HyperLinks.Add($Selection.Range, "https://confluence.pnet.ch/spaces/NT/pages/$($projectInfo.testStrategyConfluencePageId)",$null,$null,$projectInfo.testStrategyTitle)


    $Selection.TypeText(@"
 and the test results can be found at 
"@)
    $null =  $Document.HyperLinks.Add($Selection.Range, "https://confluence.pnet.ch/spaces/NT/pages/$($projectInfo.parentConfluencePageId)",$null,$null,"Results - $($projectInfo.releaseNumber)")
    $Selection.TypeText(".`n")


    $Mail.To = $projectInfo.distributionList.To -join ";"
    $Mail.CC = $projectInfo.distributionList.CC -join ";"
    
    $null = $Mail.Recipients.ResolveAll();


    $subjectPrefix = "INFO: #Performancetest - $($projectInfo.scenarioName)"

    foreach($appointment in $RestrictedItems | Where-Object { $_.Subject.StartsWith($subjectPrefix)} ) {
        $null = $Mail.Attachments.Add($appointment);
    }
}

