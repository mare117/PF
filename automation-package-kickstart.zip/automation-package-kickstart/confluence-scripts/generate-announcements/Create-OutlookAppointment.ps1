
Param(
    [Parameter(Mandatory=$false)] $reportConfigFile = ".\projectInfo.ps1",
    [Parameter(Mandatory=$false)] $date = $null,
    [Parameter(Mandatory=$false)] $startTime = $null,
    [Parameter(Mandatory=$false)] $endTime = $null,
    [Parameter(Mandatory=$false)] $reason = $null,
    [switch]  $skipEmailPreparation
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

. "$PSScriptRoot\..\common\Get-SplunkDashboardUrls.ps1"


. "$reportConfigFile"

try {

    if ($null -eq $date) { $date = $(Get-Date).AddDays(1).Date } else { $date = Get-Date $date }
    if ($null -eq $startTime) { $startTime = $projectInfo.typicalStartTime }
    if ($null -eq $endTime) { $endTime = $projectInfo.typicalEndTime }
    if ($null -eq $reason) { $reason = $projectInfo.reason }


    $startHoursMinutes = $startTime -split ":"
    $startDateTime = $date.AddHours($startHoursMinutes[0]).AddMinutes($startHoursMinutes[1]);
    $endHoursMinutes = $endTime -split ":"
    $endDateTime = $date.AddHours($endHoursMinutes[0]).AddMinutes($endHoursMinutes[1]);

    $splunkDashboards = Get-SplunkDashboardUrls $projectInfo $startDateTime $endDateTime $startDateTime $endDateTime $false

    # Outlook starten oder bestehende Instanz verwenden
    $Outlook = New-Object -ComObject Outlook.Application
    $Namespace = $Outlook.GetNamespace("MAPI")

    # Beispiel: Standardkalender
    # $CalendarFolder = $Namespace.GetDefaultFolder(9)  # 9 = olFolderCalendar

    # Beispiel: Kalender eines anderen Postfachs (freigegeben oder zusätzlich eingebunden)
    $RecipientName = "Last&PerformanceTest, PF85"
    $Recipient = $Namespace.CreateRecipient($RecipientName)

    if ($Recipient.Resolve()) {
        $CalendarFolder = $Namespace.GetSharedDefaultFolder($Recipient, 9) # 9 = Kalender
    } else {
        throw "Empfänger '$RecipientName' konnte nicht aufgelöst werden."
    }

    # Neuen Termin im gewählten Kalender erstellen

    $Appointment = $CalendarFolder.Items.Add(1) # 1 = olAppointmentItem
    $Appointment.Subject = "INFO: #Performancetest - $($projectInfo.scenarioName) $($projectInfo.releaseNumber) $($projectInfo.testEnvironment) - $($date.ToString("ddMMyyyy")) $startTime - $endTime"
    $Appointment.Categories = "$($projectInfo.calendarCategories)"

    #$Appointment.BodyFormat = 'olFormatHTML'
    $Appointment.BodyFormat = 2
    $Appointment.Body = ""
    $null = $Appointment.Display()

    $Appointment.Start = $startDateTime
    $Appointment.End = $endDateTime


    $WordEditor = $Appointment.GetInspector.WordEditor
    $Document = $WordEditor.Application.Documents(1)
    $Document.Select()
    $Selection = $WordEditor.Application.Selection
    $Table = $Selection.Range.Tables.Add($Selection.Range, 10, 2)

    $Table.Borders.Enable = 1

    $Table.Cell(1,1).Range.Text = "PI / Regression - Load Szenario Name"
    $Table.Cell(1,2).Range.Text = $projectInfo.scenarioName
    $Table.Cell(2,1).Range.Text = "Start / End"
    $Table.Cell(2,2).Range.Text = "$($date.ToString("dd.MM.yyyy")) $startTime - $($date.ToString("dd.MM.yyyy")) $endTime"
    $Table.Cell(3,1).Range.Text = "Getestete Applikationen"
    $Table.Cell(3,2).Range.Text = $projectInfo.applicationsInScope -join ", "
    $Table.Cell(4,1).Range.Text = "Erwarteter Einfluss auf Stabilität und Performance"
    $Table.Cell(4,2).Range.Text = ""
    $Table.Cell(5,1).Range.Text = "Grund"
    $Table.Cell(5,2).Range.Text = $reason
    $Table.Cell(6,1).Range.Text = "Live-Monitoring"
    $Table.Cell(6,2).Range.Select()


    foreach ($splunkDashboard in $splunkDashboards) {
        $null = $Document.HyperLinks.Add($Selection.Range, $splunkDashboard.Url, $null, $null, $splunkDashboard.Name)
        $Selection.TypeText("`n")
    }

    $Table.Cell(7,1).Range.Text = "Confluence Test Strategy"
    $null = $Document.HyperLinks.Add($Table.Cell(7,2).Range, "https://confluence.pnet.ch/spaces/NT/pages/$($projectInfo.testStrategyConfluencePageId)",$null,$null,$projectInfo.testStrategyTitle)

    $Table.Cell(8,1).Range.Text = "Confluence Test Report"
    $null = $Document.HyperLinks.Add($Table.Cell(8,2).Range, "https://confluence.pnet.ch/spaces/NT/pages/$($projectInfo.parentConfluencePageId)",$null,$null,"Results - $($projectInfo.releaseNumber)")
    $Table.Cell(9,1).Range.Text = "Distribution Liste Testankuendigung"
    $Table.Cell(9,2).Range.Text = "An:`n$($projectInfo.distributionList.To -join "`n")`n`nCC:`n$($projectInfo.distributionList.CC -join "`n")"
    $Table.Cell(10,1).Range.Text = "Performance Test Engineer"
    $Table.Cell(10,2).Range.Text = $($projectInfo.distributionList.Engineers -join "`n")



    $Table.Columns.Item(1).Shading.BackgroundPatternColor = [Microsoft.Office.Interop.Word.WdColor]::wdColorGray15
    $Table.Columns.Item(1).Width = 300
    $Table.Columns.Item(2).Width = 400

    if ($skipEmailPreparation) {
        $Appointment.Close(0);
    } else {
        $Table.Range.Select()
        $Selection.Copy()
        $Mail = $Outlook.CreateItem(0);
        $Mail.Subject = $Appointment.Subject
        $null = $Mail.Display(0);
        $Mail.GetInspector.WordEditor.Application.Selection.Paste()
        $Mail.To = $projectInfo.distributionList.To -join ";"
        $Mail.CC = $projectInfo.distributionList.CC -join ";"
        $Appointment.Close(0)
        $null = $Mail.Attachments.Add($Appointment);
    }


} catch {
    Write-Error "$($Error[0].Exception.Message)`n$($Error[0].ScriptStackTrace)"
}
