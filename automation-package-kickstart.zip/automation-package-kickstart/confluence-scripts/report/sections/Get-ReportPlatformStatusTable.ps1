Add-Type -AssemblyName System.Web
Function Get-ReportPlatformStatusTable {    
    Param(
        $context
    )
    
    Write-Host "[Platform Status] Write Platform Status Table"  

    $cacheFileXhtml = "$($context.projectInfo.reportCache)/status_table_$($context.attachmentSuffix).xhtml";
    $cacheFileXml = "$($context.projectInfo.reportCache)/Export_Plattformstatus_$($context.attachmentSuffix).xls";

    if (!(Test-Path $cacheFileXml)) {
        Write-Host "[Platform Status] Search STEP for Plattform Status Excel"

        foreach ($controller in $context.controllers) {
        
            Set-Controller $controller

            foreach($execution in $controller.executions) {  # Verwende den controller, um auf die executions zuzugreifen
                Write-Host "[Platform Status] Fetch raw data for execution $($controller.friendlyControllerUrl)/#/executions/$($execution.id)/steps?tenant=$($controller.projectName)"
            
                $allNodes = Invoke-RestMethod -UseBasicParsing -Method Get -Uri "$($controller.controllerUrl)/rest/executions/$($execution.id)/reportnodes?limit=1000" -Header @{ "Content-Type"="application/json" }

                foreach ($node in $allNodes) {
                    foreach ($attachment in $node.attachments) {
                        if ($attachment.name -match "Export_Plattformstatus_*"){
                            Write-Host "[Platform Status] Attachment found. Write to Cache."
                            $attachmentResponse = Invoke-WebRequest -UseBasicParsing -Method Get -Uri "$($controller.controllerUrl)/rest/resources/$($attachment.id)/content"                        
                            $attachmentContent = $attachmentResponse.Content
                            $null = New-Item $cacheFileXml
                            $null = Set-Content -Force -Path $cacheFileXml -Value $attachmentContent -Encoding Byte
                             break;
                        }
                    }
                }
            }
        }
    }
    $file = Get-Childitem -Path $Pwd -Filter $cacheFileXml -File -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($file.Length -eq 0) {
        return @"
Platformstatus wurde nicht exportiert
"@
    } else{
        if (!(Test-Path $cacheFileXhtml)){

            Write-Host "[Platform Status] Convert Plaatform Status Excel to xhtml"

            $excel = New-Object -comobject Excel.Application
            $workbook = $excel.Workbooks.Open("$($Pwd)\$($cacheFileXml)")

            $headers = "";

            $title = Get-EncodedText($workbook.ActiveSheet.Cells.Item(1, 1))

            for($col = 1; $col -le 13; $col++) {
                $headers += "<th>$(Get-EncodedText($workbook.ActiveSheet.Cells.Item(2, $col)))</th>"
            }

            $row = 3
            $body = ""

            $nameColumn = $workbook.ActiveSheet.Columns.Item(1)
            while($nameColumn.Rows.Item($row).Text -ne "")
            {
                $rowBody = ""
                for($col = 1; $col -le 13; $col++) {
                    $rowBody += "<td>$(Get-EncodedText($workbook.ActiveSheet.Cells.Item($row, $col)))</td>"
                }
                $row++
                $body += "<tr>$rowBody</tr>"
            }
            $workbook.Close()
            $excel.Quit()
            $path = "$($Pwd)\$($context.projectInfo.reportCache)\$file"
            $context.filesToUpload += @(@{
                name = $file
                path = $path
            })
            $table = @"
<p>$title, Stand $($context.reporting.start_time)</p>
<p><a href="https://confluence.pnet.ch/plugins/servlet/confluence/editinword/[[[pageId]]]/attachments/$file">In Office bearbeiten</a></p>
<table>
    <thead>
        <tr>
            $headers
        </tr>
    </thead>
    <tbody>
        $body
    </tbody>
</table>
"@
            $null = New-Item $cacheFileXhtml
            Set-Content $cacheFileXhtml -Value $table
            return $table
        }
        else{
            return Get-Content $cacheFileXhtml
        }
    }
}

Function Get-EncodedText
{
    Param(
        $cell
    )
    return [System.Web.HttpUtility]::HtmlEncode(($cell.Text | Out-String).Trim())
}