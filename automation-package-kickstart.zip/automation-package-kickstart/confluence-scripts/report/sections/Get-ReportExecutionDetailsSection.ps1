Function Get-ReportExecutionDetailsSection {
    Param(
        $context,
        $controller
    )

    $executionDetailsBody = ""
    $headerRow = "<tr><th>Details</th>"
    $stepVersionRow = "<tr><td>Step Version</td>"
    $planRow = "<tr><td>Plan</td>"
    $executionLinkRow = "<tr><td>Execution Link</td>"
    $executionIdRow = "<tr><td>Execution ID</td>"
    $userRow = "<tr><td>User</td>"
    $repositoryRow = "<tr><td>Repository</td>"
    $planIdRow = "<tr><td>Plan ID</td>"
    $customParametersRow = "<tr><td>Custom Parameters</td>"

    foreach ($execution in $controller.executions) {
        $headerRow += "<th>Execution $($execution.id)</th>"

        $stepVersionRow += "<td>$($context.stepVersion)</td>"
        $planRow += "<td><a href='$($controller.friendlyControllerUrl)/#/root/plans/editor/$($execution.planId)?tenant=$($context.projectInfo.projectName)'>$($execution.description)</a></td>"
        $executionLinkRow += "<td><a href='$($controller.friendlyControllerUrl)/#/root/executions/$($execution.id)?tenant=$($context.projectInfo.projectName)'>$($execution.description)</a></td>"
        $executionIdRow += "<td>$($execution.id)</td>"
        $userRow += "<td>$($execution.executionParameters.userID)</td>"
        $repositoryRow += "<td>$($execution.executionParameters.repositoryObject.repositoryID)</td>"
        $planIdRow += "<td>$($execution.planId)</td>"

        $customParametersTable = "<table><thead><tr><th>Parameter Name</th><th>Value</th></tr></thead><tbody>"
        foreach ($parameter in $execution.executionParameters.customParameters.PSObject.Properties) {
            $customParametersTable += "<tr><td>$($parameter.Name)</td><td>$($parameter.Value)</td></tr>"
        }
        $customParametersTable += "</tbody></table>"
        $customParametersRow += "<td>$customParametersTable</td>"
    }

    $headerRow += "</tr>"
    $stepVersionRow += "</tr>"
    $planRow += "</tr>"
    $executionLinkRow += "</tr>"
    $executionIdRow += "</tr>"
    $userRow += "</tr>"
    $repositoryRow += "</tr>"
    $planIdRow += "</tr>"
    $customParametersRow += "</tr>"

    $executionDetailsBody = @"
        <table>
            <thead>
                $headerRow
            </thead>
            <tbody>
                $stepVersionRow
                $planRow
                $executionLinkRow
                $executionIdRow
                $userRow
                $repositoryRow
                $planIdRow
                $customParametersRow
            </tbody>
        </table>
"@

    return @"
<p>
    <ac:structured-macro ac:name='details' ac:schema-version='1'>
        <ac:rich-text-body>
            $executionDetailsBody
        </ac:rich-text-body>
    </ac:structured-macro>
</p>
"@
}
