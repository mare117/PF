Function Get-ReportReleaseComparison {    
    Param(
        $context,
        $detailAnalysis
    )

    if ($context.inProgress) {
        return "Release comparisons not available while test is in progress"
    }
    
    $body = ""

    $fullHistory = @(,@{
        releaseNumber="Current ($($context.projectInfo.releaseNumber))"
        state=@{
            reporting=$context.reporting
        }
    } + $context.state.history)


    foreach ($reportingKey in $detailAnalysis.reportingKeys) {

        $label = ($fullHistory | Foreach-Object { $_.state.reporting.$("$($reportingKey)_label") } ) | Select-Object -First 1

        $nameColumn = "<th rowspan=""$($detailAnalysis.fields.Count)"">$label</th>"


        foreach ($field in $detailAnalysis.fields) {
            $body += @"

                <tr>
                    $nameColumn<th>$($context.projectInfo.nfrReportLabels[$field])</th>$(($fullHistory | ForEach-Object { "<td style=""text-align: right;"">$(
                        if ($null -ne $($_.state.reporting."$($reportingKey)_$($field)_measured") ) {
                            $_.state.reporting."$($reportingKey)_$($field)_measured"
                        } else {
                            "-"
                    })</td>"}) -join "")
                </tr>
"@
            $nameColumn = ""
        }
    }
    
    return @"
    <table>
        <thead>
            <tr>
                <th>Transaction</th><th>Measurement</th><th>$($fullHistory.releaseNumber -join "</th><th>")</th>
            </tr>
        </thead>
        <tbody>
            $body
        </tbody>
    </table>
"@
}