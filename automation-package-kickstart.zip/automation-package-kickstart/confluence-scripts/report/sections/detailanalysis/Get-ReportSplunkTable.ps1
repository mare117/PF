Function Get-ReportSplunkTable {    
    Param(
        $context,
        $detailAnalysis
    )

    $dashboardName=if ($null -eq $detailAnalysis.dashboardName) { $context.projectInfo.splunkDashboards.Name | Select-Object -First 1 } else { $detailAnalysis.dashboardName }
    $dashboard = $context.splunkDashboards | Where-Object { $_.Name -eq $dashboardName } | Select-Object -First 1
    if ($context.inProgress) {
        return @"
        <p>
            Splunk Link: <a href="$($dashboard.Url.Replace("&", "&amp;"))" class='external-link' rel='nofollow'>$($dashboard.Name)</a>
        </p>
"@
    }
    $tables = ""
    $width=if ($detailAnalysis.width) { $width } else { 1500 }
    $defaultIntFormat=if ($detailAnalysis.defaultIntFormat) { 
        $detailAnalysis.defaultIntFormat 
    }  else {
        @{
            format="{0}"
            alignRight=$true
        }
    }
    $defaultFloatFormat=if ($detailAnalysis.defaultFloatFormat) { 
        $detailAnalysis.defaultFloatFormat 
    }  else {
        @{
            format="{0:n2}"
            alignRight=$true
        }
    }
    $defaultTextFormat=if ($detailAnalysis.defaultTextFormat) { 
        $detailAnalysis.defaultTextFormat 
    }  else {
        @{
            format="{0}"
            alignRight=$false
        }
    }

    foreach($title in $detailAnalysis.splunkTables)
    {
        
        Write-Host "[Splunk] Write Splunk Table $title, url: $($dashboard.Url)"
        $filePath = ($context.splunkCSVsToDownload | Where-Object { $_.title -eq $title}).filePath;

        

        [array] $csv = @(Import-Csv $filePath);
        if ($detailAnalysis.limit) {
            $csv = $csv | Select-Object -First $detailAnalysis.limit;
        }

        if ($csv.Count -eq 0) {
            $tables += "<p><b>No entries for table $title</b></p>"
        } else {

            if ($detailAnalysis.nfrReporting) {
                
                foreach ($nfrReportingEntry in $detailAnalysis.nfrReporting.GetEnumerator()) {
                    $nfrType = $nfrReportingEntry.Key;
                    $nfrReporting = $nfrReportingEntry.Value;
                    $key = $nfrReporting.key;

                    $line = $csv;

                    $tableColumn = $nfrReporting.tableColumn;
                    

                    [array] $csvValueColumn = $csv | ForEach-Object {$_.$tableColumn};

                    for ($i = 0; $i -lt $csvValueColumn.Count; $i++) {


                        $csvValue = $csvValueColumn[$i]
    
                        $number = $null
                        $value = if ([int]::TryParse($csvValue, [ref]$number)) {
                            $number
                        } elseif ([decimal]::TryParse($csvValue, [ref]$number)) {
                            $number
                        } else {
                            [System.Net.WebUtility]::HtmlEncode($csvValue);
                        }

                        $format=if($detailAnalysis.format -and $detailAnalysis.format.$tableColumn) { $detailAnalysis.format.$tableColumn }  else {
                            if ($value -is [decimal]) {
                                $defaultFloatFormat
                            } elseif ($value -is [int]) {
                                $defaultIntFormat
                            } else {
                                $defaultTextFormat
                            }
                        }

                        $labelledKey = $key
                        
                        if ($null -ne $detailAnalysis.nfrReportingLabelColumn) {
                            $label = ([array] $line.$($detailAnalysis.nfrReportingLabelColumn))[$i];
                            $sanitzedLabel=$label -replace "[^\w]", ""
                            $labelledKey = "$($sanitzedLabel)_$key";
                            $context.reporting."$($sanitzedLabel)_label" = $label;
                        }
                        if ($null -ne $detailAnalysis.nfr) {
                            $context.reporting."$($labelledKey)_expected" = $detailAnalysis.nfr.$nfrType;
                        }
                        $context.reporting."$($labelledKey)_measured" = $format.format -f $value;
    
                        $style = if ($format.alignRight) { " style=""text-align: right;"""} else { "" }
    
                        if ($nfrType -eq "tpm") {
                            if ($null -ne $detailAnalysis.nfr -and $value -lt ($detailAnalysis.nfr.$nfrType * 0.9)) {
                                $style += " class=""highlight-red"" data-highlight-colour=""red""";
                            }
                        } else {
                            if ($null -ne $detailAnalysis.nfr -and $value -gt ($detailAnalysis.nfr.$nfrType * 1.1)) {
                                $style += " class=""highlight-red"" data-highlight-colour=""red""";
                            }    
                        }
    
                        $context.reporting."$($labelledKey)_style" = $style;
                    }
                }
            }
            if ($detailAnalysis.collectOnly) {
                return "";
            }
            
            $headers = (Get-Content $filePath)[0] -split ","

            $rows = ""
            foreach ($line in $csv) {
                $rows += "<tr>$($headers | ForEach-Object { 
                    
                    $number = $null
                    $value = if ([int]::TryParse($line.$_, [ref]$number)) {
                        $number
                    } elseif ([decimal]::TryParse($line.$_, [ref]$number)) {
                        $number
                    } else {
                        [System.Net.WebUtility]::HtmlEncode($line.$_);
                    }
                    $format=if($detailAnalysis.format -and $detailAnalysis.format.$_) { $detailAnalysis.format.$_ }  else {

                        if ($value -is [decimal]) {
                           $defaultFloatFormat
                        } elseif ($value -is [int]) {
                            $defaultIntFormat
                        } else {
                           $defaultTextFormat
                        }
                    }
                    "<td$(if ($format.alignRight) { ' style="text-align: right;"'})>$($format.format -f $value)</td>"
                })</tr>"
            }

            $tables += @"
                <p>
                    <table width="$width">
                        <thead><tr>$($headers | ForEach-Object { "<th>$([System.Net.WebUtility]::HtmlEncode($_))</th>"})</tr></thead>
                        <tbody>
                            $rows
                        </tbody>
                    </table>
                </p>
"@
        }


    }
    return @"
<p>
    Splunk Link: <a href="$($dashboard.Url.Replace("&", "&amp;"))" class='external-link' rel='nofollow'>$($dashboard.Name)</a>
</p>
$tables
"@
}