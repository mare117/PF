. "$PSScriptRoot\..\..\..\common\Get-ControllerForProject.ps1"

Function Get-ReportMeasurementsGraph {    
    Param(
        $context,
        $detailAnalysis
    )

    $controller = Get-ControllerForProject $context $detailAnalysis.projectName

    $transactionName = $detailAnalysis.transactionName
    Write-Host "[Graph] Fetch raw data for $transactionName using controller $($controller.controllerUrl)"

    $start = $context.startTime - ($context.startTime % 60000)
    $end = $context.endTime - ($context.endTime % 60000) + 60000

    $numberOfBuckets = ($end - $start) / 60000

    $measurements = Invoke-RestMethod -UseBasicParsing -Method Post -Uri "$($controller.controllerUrl)/rest/time-series/measurements" -Header @{ "Content-Type"="application/json" } -Body (@{
        start=$start
        end=$end
        numberOfBuckets=$numberOfBuckets
        oqlFilter="(attributes.metricType = response-time) and ($(($controller.executions.id | ForEach-Object { "attributes.eId = $_"}) -join " or ")) and (attributes.name ~ ""$($transactionName.Replace('*', '.*'))"")"
        percentiles=@(90, 99)
        groupDimensions=@("rnStatus")
        collectAttributeKeys=@()
        collectAttributesValuesLimit=10
    } | ConvertTo-Json)

    Write-Host "[Graph] Write Chart for $transactionName"

    $times = (0..$numberOfBuckets) | ForEach-Object { [long] $start + $_ * 60000 }
    
    $measurementsByStatusAndTime=@{}
    
    for ($i=0; $i -lt $measurements.matrixKeys.Count; $i++) {
        $status = $measurements.matrixKeys[$i].rnStatus;
        $measurementsByStatusAndTime[$status] = @{}
        
        foreach ($measurement in $measurements.matrix[$i]) {
            if ($measurement.begin -gt 0) {   
                $measurementsByStatusAndTime[$status][[long] $measurement.begin] = $measurement
            }
        }
    }

    if (-not $measurementsByStatusAndTime.ContainsKey('PASSED')) {
        return @"
<p>
    No Data for controller: $($controller.controllerUrl)
</p>
"@
    }

    $dateFormat = "HH:mm"
    if (([datetime] '1970-01-01').AddSeconds($start / 1000.0).ToLocalTime().ToString("d") -ne ([datetime] '1970-01-01').AddSeconds($end / 1000.0).ToLocalTime().ToString("d")) {
        $dateFormat = "ddMM HH:mm"
    }
    $width = $detailAnalysis.width
    
    $countByStatus = ""
    foreach ($key in $measurements.matrixKeys) {
        $status = $key.rnStatus;
        $measurement = $measurementsByStatusAndTime[$status]
        $countByStatus += @"
        <tr>
            <th>$($key.rnStatus)</th><td>$(($times | ForEach-Object { if ($measurement.ContainsKey($_)) {$measurement[$_].count} else {0} }) -join "</td><td>")</td>
        </tr>
"@
    }

    $timesRow = @"
    <tr>
    <th>Time</th><td>$(($times | ForEach-Object { ([datetime] '1970-01-01').AddSeconds($_ / 1000.0).ToLocalTime().ToString($dateFormat) }) -join "</td><td>")</td>
    </tr>
"@

    $passed = $measurementsByStatusAndTime['PASSED']

    $errorRates = @{}
    if ($measurementsByStatusAndTime.ContainsKey('FAILED')) {
        $failed = $measurementsByStatusAndTime['FAILED']

        foreach ($time in $times) {
            $f =  if ($failed.ContainsKey($time)) {  $failed[$time].count } else { 0 }
            $p = if ($passed.ContainsKey($time)) { $passed[$time].count } else { 0 }
            $t = $f + $p
            if ($t -ne 0) { 
                $errorRates[$time] = @{
                    begin=$time
                    value=$f * 100 / ($f + $t) 
                }
            }
        }
    }

    $errorRateRow = @"
    <tr>
    <th>Error Rate %</th><td>$(($times | ForEach-Object { if ($errorRates.ContainsKey($_)) {$errorRates[$_].value} else { 0 } }) -join "</td><td>")</td>
    </tr>
"@
    
    $friendlyName = if ($null -ne $detailAnalysis.friendlyName) { $detailAnalysis.friendlyName } else { $detailAnalysis.title }

    foreach($key in $detailAnalysis.nfr.Keys) {
        $violations = @()
        if ($key -eq "avg") {
            $violations = $times | Where-Object { $passed.ContainsKey($_) } | ForEach-Object { $passed[$_] } | Where-Object { ($passed[$_].sum / $passed[$_].count) -gt $detailAnalysis.nfr["avg"]} 
        } elseif ($key -eq "errorRate") {
            $violations = $times | Where-Object { $errorRates.ContainsKey($_) } | ForEach-Object { $errorRates[$_] } | Where-Object {$_.value -gt $detailAnalysis.nfr["errorRate"]}
        } else {
            $violations = $times | Where-Object { $passed.ContainsKey($_) } | ForEach-Object { $passed[$_] } | Where-Object { $_.pclValues."$key.0" -gt $detailAnalysis.nfr[$key] }
        }
        
        $first = $violations | Select-Object -First 1
        $last = $violations | Select-Object  -Last 1
        <#if ($null -ne $first) {
            if ($first.begin -ne $last.begin) {
                $context.timeline += @(@{
                    time=$first.begin
                    description="First violation of $($context.projectInfo.longNfrReportLabels[$key] -f $detailAnalysis.nfr[$key]) for $($friendlyName)"
                })
                $context.timeline += @(@{
                    time=$last.begin
                    description="Last violation of $($context.projectInfo.longNfrReportLabels[$key] -f $detailAnalysis.nfr[$key]) for $($friendlyName)"
                })
            } else {
                $context.timeline += @(@{
                    time=$first.begin
                    description="Violation of $($context.projectInfo.longNfrReportLabels[$key] -f $detailAnalysis.nfr[$key]) for $($friendlyName)"
                })
            }
            $context.conclusions += @("Violation of $($context.projectInfo.longNfrReportLabels[$key] -f $detailAnalysis.nfr[$key]) for $($friendlyName)")
        }#>
    }


    $topMeasurementsTable = ""
    if ($detailAnalysis.listSlowest) {
        $skip = 0
        $count = 1000

        $passedMeasurements = @()
        $failedMeasurements = @()
        while ($count -eq 1000) {

            $oqlFilter = "type=custom and ($(($controller.executions.id | ForEach-Object { "eId = $_"}) -join " or ")) and (name ~ ""$($transactionName.Replace('*', '.*'))"")"
            $url = "$($controller.controllerUrl)/rest/time-series/raw-measurements?limit=1000&skip=${skip}&filter=$([System.Web.HttpUtility]::UrlEncode($oqlFilter))"
            $measurements = Invoke-RestMethod -UseBasicParsing -Method Get -Uri $url -Header @{ "Content-Type"="application/json" }
            $count = $measurements.Count
            if ($count -gt 0) {
                $passedMeasurements = (@($passedMeasurements) + @($measurements | Where-Object { $_.rnStatus -eq "PASSED" })) | Sort-Object -Descending -Property { $_.value } | Select-Object -First 10
                $failedMeasurements = (@($failedMeasurements) + @($measurements | Where-Object { $_.rnStatus -eq "FAILED" })) | Sort-Object -Descending -Property { $_.value } | Select-Object -First 10
            }

            $skip += 1000

            $lastMeasurement = $measurements | Select-Object -Last 1
            if ($null -ne $lastMeasurement) {
                Write-Host "[Graph] Gather top 20 response times for $transactionName, time $(([datetime] '1970-01-01').AddMilliseconds($lastMeasurement.begin).ToLocalTime().ToString('HH:mm:ss'))"
            }
        }
        $topMeasurementsTable = @"
            <b>Top 10 longest Durations Passed Measurements</b>

            <table>
                <thead>
                    <tr><th>Time</th><th>Duration ms</th><th>Session Info</th></tr>
                </thead>
                <tbody>
                    $(($passedMeasurements | Foreach-Object { "<tr><td>$(([datetime] '1970-01-01').AddMilliseconds($_.begin).ToLocalTime().ToString('HH:mm:ss'))</td><td>$($_.value)</td><td>$($_.sessionId)</td></tr>" }) -join "")
                </tbody>
            </table>

            
            <b>Top 10 longest Durations Failed Measurements</b>

            <table>
                <thead>
                    <tr><th>Time</th><th>Duration ms</th><th>Session Info</th></tr>
                </thead>
                <tbody>
                    $(($failedMeasurements | Foreach-Object { "<tr><td>$(([datetime] '1970-01-01').AddMilliseconds($_.begin).ToLocalTime().ToString('HH:mm:ss'))</td><td>$($_.value)</td><td>$($_.sessionId)</td></tr>" }) -join "")
                </tbody>
            </table>
"@
    }

    return @"
<table>
    <tr>
        <td>
            <p>
                <ac:structured-macro ac:name="chart" ac:schema-version="1">
                    <ac:parameter ac:name="subTitle">$friendlyName Durations</ac:parameter>
                    <ac:parameter ac:name="width">$width</ac:parameter>
                    <ac:parameter ac:name="height">400</ac:parameter>
                    <ac:parameter ac:name="dateFormat">$dateFormat</ac:parameter>
                    <ac:parameter ac:name="timePeriod">Minute</ac:parameter>
                    <ac:parameter ac:name="rangeAxisLowerBound">0</ac:parameter>
                    <ac:parameter ac:name="type">timeSeries</ac:parameter>
                    <ac:parameter ac:name="dateTickMarkPosition">start</ac:parameter>
                    <ac:parameter ac:name="yLabel">Duration [ms]</ac:parameter>
                    <ac:rich-text-body>
                        <table>
                            <tbody>
                                $timesRow
                                <tr>
                                    <th>Average</th><td>$(($times | ForEach-Object { if ($passed.ContainsKey($_)) {[int] ($passed[$_].sum / $passed[$_].count)} else { 0 } }) -join "</td><td>")</td>
                                </tr>
                                <tr>
                                    <th>P(90%)</th><td>$(($times | ForEach-Object { if ($passed.ContainsKey($_)) {$passed[$_].pclValues."90.0"} else { 0 } }) -join "</td><td>")</td>
                                </tr>
                                <tr>
                                    <th>P(99%)</th><td>$(($times | ForEach-Object { if ($passed.ContainsKey($_)){$passed[$_].pclValues."99.0"} else { 0 }}) -join "</td><td>")</td>
                                </tr>
                            </tbody>
                        </table>
                    </ac:rich-text-body>
                </ac:structured-macro>
            </p>
            <p>
                <ac:structured-macro ac:name="chart" ac:schema-version="1">
                    <ac:parameter ac:name="subTitle">$friendlyName Transactions per Minute</ac:parameter>
                    <ac:parameter ac:name="width">$width</ac:parameter>
                    <ac:parameter ac:name="height">200</ac:parameter>
                    <ac:parameter ac:name="dateFormat">$dateFormat</ac:parameter>
                    <ac:parameter ac:name="timePeriod">Minute</ac:parameter>
                    <ac:parameter ac:name="rangeAxisLowerBound">0</ac:parameter>
                    <ac:parameter ac:name="type">timeSeries</ac:parameter>
                    <ac:parameter ac:name="dateTickMarkPosition">start</ac:parameter>
                    <ac:parameter ac:name="yLabel">Count</ac:parameter>
                    <ac:rich-text-body>
                        <table>
                            <tbody>
                                $timesRow
                                $countByStatus
                            </tbody>
                        </table>
                    </ac:rich-text-body>
                </ac:structured-macro>
            </p>

            <p>
                <ac:structured-macro ac:name="chart" ac:schema-version="1">
                    <ac:parameter ac:name="subTitle">$friendlyName Error rate</ac:parameter>
                    <ac:parameter ac:name="width">$width</ac:parameter>
                    <ac:parameter ac:name="height">200</ac:parameter>
                    <ac:parameter ac:name="dateFormat">$dateFormat</ac:parameter>
                    <ac:parameter ac:name="timePeriod">Minute</ac:parameter>
                    <ac:parameter ac:name="rangeAxisLowerBound">0</ac:parameter>
                    <ac:parameter ac:name="type">timeSeries</ac:parameter>
                    <ac:parameter ac:name="dateTickMarkPosition">start</ac:parameter>
                    <ac:parameter ac:name="yLabel">Error Rate %</ac:parameter>
                    <ac:rich-text-body>
                        <table>
                            <tbody>
                                $timesRow
                                $errorRateRow
                            </tbody>
                        </table>
                    </ac:rich-text-body>
                </ac:structured-macro>
            </p>
        </td>
        <td>
            $topMeasurementsTable
        </td>
    </tr>
</table>
"@
}
