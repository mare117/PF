Function Get-ReportSplunkGraph {    
    Param(
        $context,
        $detailAnalysis
    )

    $graphs = ""
    $dashboardName=if ($null -eq $detailAnalysis.dashboardName) { $context.projectInfo.splunkDashboards.Name | Select-Object -First 1 } else { $detailAnalysis.dashboardName }
    $dashboard = $context.splunkDashboards | Where-Object { $_.Name -eq $dashboardName } | Select-Object -First 1
    if ($context.inProgress) {
        return @"
        <p>
            Splunk Link: <a href="$($dashboard.Url.Replace("&", "&amp;"))" class='external-link' rel='nofollow'>$($dashboard.Name)</a>
        </p>
"@
    }

    foreach($title in $detailAnalysis.splunkGraphs) {

        
        Write-Host "[Graph] Write Splunk Graph $title, url: $($dashboard.Url)"
        $fileName = ($context.splunkGraphsToDownload | Where-Object { $_.title -eq $title}).fileName;
        $graphs += @"
<p>
    <ac:image ac:width="$($detailAnalysis.width)">
        <ri:attachment ri:filename="$fileName" />
    </ac:image>
</p>
"@
    }

    return @"
<p>
    Splunk Link: <a href="$($dashboard.Url.Replace("&", "&amp;"))" class='external-link' rel='nofollow'>$($dashboard.Name)</a>
</p>
$graphs
"@
}