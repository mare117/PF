
. "$PSScriptRoot\..\..\..\common\Get-ControllerForProject.ps1"

Function Get-ReportMeasurementsTable {    
    Param(
        $context,
        $detailAnalysis
    )
    
    $nfrs= $detailAnalysis.nfrs
    $nfrKeys = $nfrs.Keys

    
    $controller = Get-ControllerForProject $context $detailAnalysis.projectName

    Write-Host "[Measurements Table] Fetch raw data for $($detailAnalysis.title)"
    $measurements = Invoke-RestMethod -UseBasicParsing -Method Post -Uri "$($controller.controllerUrl)/rest/time-series/measurements" -Header @{ "Content-Type"="application/json" } -Body (@{
        start=$context.analysisStartTime
        end=$context.analysisEndTime
        numberOfBuckets=1
        oqlFilter="(attributes.metricType = response-time) and ($(($controller.executions.id | ForEach-Object { "attributes.eId = $_"}) -join " or ")) and ($(($detailAnalysis.nameFilters | ForEach-Object { "attributes.name ~ '$($_.Replace('*', '.*'))'"}) -join " or "))"
        percentiles=@(90, 99)
        groupDimensions=@("name", "rnStatus")
        collectAttributeKeys=@()
        collectAttributesValuesLimit=10
    } | ConvertTo-Json)

    Write-Host "[Measurements Table] Reorganize by measurement name for $($detailAnalysis.title)"
    $measurementsByName=@{}
    for($i = 0; $i -lt $measurements.matrixKeys.Count; $i++) {
        $name = $measurements.matrixKeys[$i].name;
        $status = $measurements.matrixKeys[$i].rnStatus;
        if (-not $name) {
            continue;
        }
        if (-not $measurementsByName.ContainsKey($name)) {
            $measurementsByName[$name] = @{};
        }
        $measurementsByName[$name][$status] = $measurements.matrix[$i];
    }

    Write-Host "[Measurements Table] Write table for $($detailAnalysis.title)"
    $body = ""
    foreach ($name in ($measurementsByName.Keys | Sort-Object)) {
        $measurementsByStatus = $measurementsByName[$name];

        $passed = @{
            min=0
            max=0
            throughputPerHour=0
            count=0
            pclValues=@{
                "90.0"=0
                "99.0"=0
            }
        }
        if ($measurementsByStatus.ContainsKey("PASSED")) {
            $passed = $measurementsByStatus.PASSED[0]
        }
        $failed = @{
            min=0
            max=0
            throughputPerHour=0
            count=0
        }
        if ($measurementsByStatus.ContainsKey("FAILED")) {
            $failed = $measurementsByStatus.FAILED[0]
        }
        
        $avg = 0
        if ($passed.count -gt 0) {
            $avg = $passed.sum / $passed.count
        }

        if ($failed.count + $passed.count -eq 0) {
            continue;
        }


        $errorRate = ($failed.count/($failed.count + $passed.count))
        $measuredValues = @{
            90=$passed.pclValues."90.0"
            99=$passed.pclValues."99.0"
            avg=$avg
        } 

        $nameColumn =  @{ text=$name; highlight=($errorRate -gt 0.05); alignRight=$false }



        $columns =  @(
            $nameColumn
            @{ text=("{0:p3}" -f $errorRate); highlight=($errorRate -gt 0.05); alignRight=$true }
            @{ text=("{0:n2}" -f (($passed.throughputPerHour + $failed.throughputPerHour) / 60.0)); highlight=$false; alignRight=$true }
            @{ text=("{0:n2}" -f ($passed.throughputPerHour / 60.0)); highlight=$false; alignRight=$true }
            @{ text=("{0}" -f $passed.min); highlight=$false; alignRight=$true }
            @{ text=("{0}" -f $passed.max); highlight=$false; alignRight=$true }
        )

        $reportingLabels=$detailAnalysis.nfrReportingLabels.$($name);
        if ($null -eq $reportingLabels) {
            $reportingLabels = @{
                key=$name -replace "[^\w]", ""
                label=$name       
            }
        }

        
        if ($detailAnalysis.collectReporting) {
            $context.reporting."$($reportingLabels.key)_errorrate_measured" = "{0:p3}" -f $errorRate;
            $context.reporting."$($reportingLabels.key)_tpm_measured" = "{0:n2}" -f (($passed.throughputPerHour + $failed.throughputPerHour) / 60.0);
            $context.reporting."$($reportingLabels.key)_count_measured" = $passed.count + $failed.count;
            $context.reporting."$($reportingLabels.key)_avg_measured" = "{0:n0}" -f $measuredValues.avg;
            $context.reporting."$($reportingLabels.key)_90_measured" = "{0:n0}" -f $measuredValues.90;
            $context.reporting."$($reportingLabels.key)_99_measured" = "{0:n0}" -f $measuredValues.99;
            $context.reporting."$($reportingLabels.key)_label" = $reportingLabels.label;
        }


        foreach($key in $nfrKeys) {
            $measuredColumn = @{ text=("{0:n0}" -f $measuredValues[$key]); highlight=$false; alignRight=$true}
            $columns += $measuredColumn
            if ($nfrs[$key].Values.Count -gt 0) {
                
                $nfrColumn = @{ text=""; highlight=$false; alignRight=$true}
                $columns += $nfrColumn
                foreach($namePattern in $nfrs[$key].Keys) {
                    if ($name -match "^$($namePattern.Replace("*", ".*"))$") {
                        $nfrColumn.text=("{0:n0}" -f $nfrs[$key][$namePattern])
                        if ($measuredValues[$key] -gt $nfrs[$key][$namePattern]) {
                            $measuredColumn.highlight = $true
                            $nfrColumn.highlight = $true
                            $nameColumn.highlight = $true
                            #$context.conclusions += @("Violation of $($context.projectInfo.longNfrReportLabels[$key] -f $nfrs[$key][$namePattern]) for $($namePattern)")
                        }
                        break;
                    }
                }
            }
        }

        if (-not $detailAnalysis.collectOnly) {
            $body += @"
            <tr>
            $(($columns | ForEach-Object { "<td$(if ($_.alignRight) {' style="text-align: right;"'})$(if ($_.highlight) {' class="highlight-red" data-highlight-colour="red"'})>$($_.text)</td>"}) -join "")
            </tr>
"@
        }
    }
    
    if ($detailAnalysis.collectOnly) {
        return "";
    }
    
    $columns = @(
        "Measurement name"
        "Error rate"
        "Measured TPM (Absolute)"
        "Measured TPM (PASSED)"
        "Measured Min [ms]"
        "Measured Max [ms]")
    foreach($key in $nfrKeys){
        $columns += "Measured $($context.projectInfo.nfrReportLabels[$key])"
        if ($nfrs[$key].Values.Count -gt 0) {
            $columns += "NFR $($context.projectInfo.nfrReportLabels[$key])"
        }
    }
    
    return @"
    <p>
        <span style="font-weight: bold">Statistik w&auml;hrend ber&uuml;cksichtigter Volllast-Zeitspanne $(([datetime] '1970-01-01').AddSeconds($context.analysisStartTime / 1000.0).ToLocalTime().ToString('HH:mm')) -  $(([datetime] '1970-01-01').AddSeconds($context.analysisEndTime / 1000.0).ToLocalTime().ToString('HH:mm'))</span>
    </p>
    <table>
        <thead>
            <tr>
                <th>$($columns -join "</th><th>")</th>
            </tr>
        </thead>
        <tbody>
            $body
        </tbody>
    </table>
"@
}