Function Get-ReportGraphanaScreenshot {    
    Param(
        $context,
        $detailAnalysis
    )

    $fileName = "$($detailAnalysis.title.Replace(' ', '_'))_$($context.attachmentSuffix).jpeg"
    $filePath = Join-Path -Path (Get-Location) -ChildPath "$($context.projectInfo.reportCache)\$fileName"
    Write-Host "[Graph] Prepare Graphana Screenshot $fileName"
    
    $graphanaUrl = $detailAnalysis.graphanaUrl.Replace('[[from]]', $context.startTime);
    if ($context.inProgress) {
        $graphanaUrl = $graphanaUrl.Replace('[[to]]', "now")
        return @"
        <p>
            Graphana Link: <a href='$($graphanaUrl.Replace("&", "&amp;"))' class='external-link' rel='nofollow'>$($detailAnalysis.title)</a>
        </p>
"@
    } else {
        $graphanaUrl = $graphanaUrl.Replace('[[to]]', $context.endTime)
    }


    if (-not (Test-Path -PathType Leaf $filePath)) {

        $now = Get-Date -Format "yyyyMMddHHmmss"

        Write-Host "[Graph]"
        Write-Host "[Graph] Execute Full page screenshot of $graphanaUrl"
        Start-Process $graphanaUrl

        $file = $null
        $retries = 30
        while ($null -eq $file -and $retries-- -gt 0) {
            $files = Get-ChildItem -Path $context.projectInfo.downloadFolder -Filter "Bildschirmfoto_*.jpeg"
            $file = $files | Where-Object { ($_.CreationTime.DateTime | Get-Date -Format "yyyyMMddHHmmss") -ge $now}
            Write-Host "[Graph] Polling for Bildschirmfoto_*.jpeg..."
            Start-Sleep -Seconds 1
        }

        $null = New-Item -Force -ItemType Directory $context.projectInfo.reportCache
        $null = Move-Item -Path $file.FullName -Destination $filePath -Force;

        $context.filesToUpload += @(@{
             name = $fileName
             path = $filePath
        })

        # $chromeArguments = @(
        #     "--headless"
        #     "--disable-gpu"
        #     "--virtual-time-budget=20000"
        #     "--hide-scrollbars"
        #     "--run-all-compositor-stages-before-draw"
        #     "--window-size=$screenshotSize"
        #     "--force-device-scale-factor=1"
        #     "--user-data-dir=""C:\dev\Chrome_Profile"""
        #     "--screenshot=""$filePath"""
        #     "$graphanaUrl"
        # )
        # Write-Host "[Graph] Executing Chrome command: $chromePath $chromeArguments"
        # Start-Process -FilePath $chromePath -ArgumentList $chromeArguments -NoNewWindow -Wait
        # #exit
        # Start-Sleep -Seconds 5

        # if (Test-Path $filePath) {
        #     Write-Host "[Graph] Screenshot saved to $filePath"
        #     $context.filesToUpload += @(@{
        #         name = $fileName
        #         path = $filePath
        #     })
        # }
        # else {
        #     Write-Host "[Graph] Screenshot could not be created."
        # }

    } elseif ($context.reuploadAttachments) {
        $context.filesToUpload += @(@{
            name = $fileName
            path = $filePath
        })
    }



    return @"
<p>
    Graphana Link: <a href='$($graphanaUrl.Replace("&", "&amp;"))' class='external-link' rel='nofollow'>$($detailAnalysis.title)</a>
</p>
<p>
    <ac:image ac:width='$($detailAnalysis.width)'>
        <ri:attachment ri:filename='$fileName' />
    </ac:image>
</p>
"@
}
