Function Get-ReportSplunkList {    
    Param(
        $context,
        $detailAnalysis
    )

    return @"
<h2>$($detailAnalysis.title)</h2>
<p>
    $($detailAnalysis.description)
</p>
<p>
    Splunk Links:
    <ul>
        $(@(
            foreach ($dashboard in $context.projectInfo.splunkDashboards) {
                "<li><a href='$($dashboard.Url.Replace("&", "&amp;"))' class='external-link' rel='nofollow'>$($dashboard.Name)</a></li>"
            }
        ) -join "`n")
    </ul>
</p>
"@
}