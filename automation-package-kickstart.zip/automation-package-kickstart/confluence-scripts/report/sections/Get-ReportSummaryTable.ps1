Function Get-ReportSummaryTable {    
    Param(
        $context
    )
    
    Write-Host "[Summary] Write Summary Table"  

    $dateTimeFormat = 'dd.MM.yyy HH:mm:ss'
    $startTime = ([datetime] '1970-01-01').AddSeconds($context.startTime / 1000.0).ToLocalTime()
    $endTime = ([datetime] '1970-01-01').AddSeconds($context.endTime / 1000.0).ToLocalTime()
    
    $analysisStartTime = ([datetime] '1970-01-01').AddSeconds($context.analysisStartTime / 1000.0).ToLocalTime()
    $analysisEndTime = ([datetime] '1970-01-01').AddSeconds($context.analysisEndTime / 1000.0).ToLocalTime()

    $qcTests = ($context.projectInfo.qcTestSets | ForEach-Object {@"
    <p>
        <a href="tds://qcpf.pf.qualitycenter.pnet.ch/qcbin/TestLabModule-000000003649890581?EntityType=ITestSet&amp;EntityID=$($_.id)">Test Set ID: $($_.id)</a>
        $([System.Net.WebUtility]::HtmlEncode($_.name))
    </p>
"@ }) -join ""
    $hltcE2E = ($context.projectInfo.hltcE2E | ForEach-Object {@"
    <p>
        <a href="https://polarion.pnet.ch/polarion/#/wiki/gs_redirect?id=$($_.id)">$($_.id) - $([System.Net.WebUtility]::HtmlEncode($_.name))  &lt; $($_.store)</a>
    </p>
"@ }) -join ""

    $context.scenarios = @($context.controllers | ForEach-Object { $controller = $_; $_.executions | Sort-Object -Unique -Property description | ForEach-Object { @"

    <p>
        <a href="$($controller.friendlyControllerUrl)/#/root/plans/editor/$($_.planId)?tenant=$($controller.projectName)">$([System.Net.WebUtility]::HtmlEncode($_.description))</a> $([System.Net.WebUtility]::HtmlEncode($_.executionParameters.customParameters.comment))
    </p>
"@ }}) -join ""


    return @"
<table>
    <tbody>
        <tr>
            <td class="highlight-grey" data-highlight-colour="grey">Application in Scope</td>
            <td>$($context.projectInfo.applicationsInScope -join ", ")</td>
        </tr>
        <tr>
            <td class="highlight-grey" data-highlight-colour="grey">Test Environment (E, T1, T2)</td>
            <td>$($context.projectInfo.testEnvironment)</td>
        </tr>
        <tr>
            <td class="highlight-grey" data-highlight-colour="grey">Test Case QC Link || Test Instance ID || RunID</td>
            <td>$qcTests</td>
        </tr>
        <tr>
            <td class="highlight-grey" data-highlight-colour="grey">
                High Level Test Case<br/>
                (Polarion NFR, Confluence NFR)
            </td>
            <td>$hltcE2E</td>
        </tr>
        <tr>
            <td class="highlight-grey" data-highlight-colour="grey">Jira Task</td>
            <td>
                <ac:structured-macro ac:name="jira" ac:schema-version="1">
                    <ac:parameter ac:name="server">Jira</ac:parameter>
                    <ac:parameter ac:name="columnIds">
                        issuekey,summary,issuetype,created,updated,duedate,assignee,reporter,priority,status,resolution
                    </ac:parameter>
                    <ac:parameter ac:name="columns">
                        key,summary,type,created,updated,due,assignee,reporter,priority,status,resolution
                    </ac:parameter>
                    <ac:parameter ac:name="serverId">e933993c-744f-34be-9434-bc1e3b89821c
                    </ac:parameter>
                    <ac:parameter ac:name="key">$($context.projectInfo.jiraTask)</ac:parameter>
                </ac:structured-macro>
            </td>
        </tr>
        <tr>
            <td class="highlight-grey" data-highlight-colour="grey">Code Tag GIT</td>
            <td><a href="https://gitlab.pnet.ch/nfrt/step/plans/$($context.projectInfo.gitName)/-/tags/$($context.gitTag)">$($context.gitTag)</a></td>
        </tr>
        <tr>
            <td class="highlight-grey" data-highlight-colour="grey">Scenario / Test Name (NeoLoad, Step, JMeter)</td>
            <td>$($context.scenarios)</td>
        </tr>
        <tr>
            <td class="highlight-grey" data-highlight-colour="grey">Datum / Start - Stop</td>
            <td>$($startTime.ToString($dateTimeFormat)) - $($endTime.ToString($dateTimeFormat))</td>
        </tr>
        <tr>
            <td class="highlight-grey" data-highlight-colour="grey">Analyse / Start - Stop</td>
            <td>$($analysisStartTime.ToString($dateTimeFormat)) - $($analysisEndTime.ToString($dateTimeFormat))</td>
        </tr>
    </tbody>
</table>
"@
}