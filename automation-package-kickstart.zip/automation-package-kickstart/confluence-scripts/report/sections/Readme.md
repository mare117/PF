This folder contains functions which generate subsections of the report body and define parts of the report which should always be present in the report as compiled by Get-Report.ps1.
