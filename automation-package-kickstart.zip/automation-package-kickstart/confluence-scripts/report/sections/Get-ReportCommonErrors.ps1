. "$PSScriptRoot\..\..\common\Set-Controller.ps1"

# Encode every non-ASCII character as a numeric HTML entity so the resulting
# string is safe to embed in a JSON body that will be parsed as UTF-8.
Function ConvertTo-AsciiSafeString {
    Param([string] $text)
    if ([string]::IsNullOrEmpty($text)) { return $text }
    $sb = New-Object System.Text.StringBuilder
    foreach ($ch in $text.ToCharArray()) {
        $code = [int][char]$ch
        if ($code -gt 127) {
            [void]$sb.Append("&#$code;")
        } else {
            [void]$sb.Append($ch)
        }
    }
    return $sb.ToString()
}

Function Get-ReportCommonErrors {    
    Param(
        $context
    )

    $tables = ""
    $header ="<th>Instances</th><th>First occurred</th><th>Last occurred</th><th>Error Message</th><th>Console Logs</th><th>Session Infos</th><th>Screenshot</th>"

    foreach ($controller in $context.controllers) {
        
        Set-Controller $controller

        foreach($execution in $controller.executions) {  # Verwende den controller, um auf die executions zuzugreifen
            Write-Host "[Common Errors] Fetch raw data for execution $($controller.friendlyControllerUrl)/#/executions/$($execution.id)/steps?tenant=$($controller.projectName)"
            
            $errorNodes = Invoke-RestMethod -UseBasicParsing -Method Get -Uri "$($controller.controllerUrl)/rest/executions/$($execution.id)/reportnodes-with-errors?limit=1000" -Header @{ "Content-Type"="application/json" }
            
            if ($errorNodes.Count -eq 0) {
                $tables += "<p>Keine Fehler bei Ausf&uuml;hrung <a href=""$($controller.friendlyControllerUrl)/#/executions/$($execution.id)/steps?tenant=$($controller.projectName)"">$($execution.description)</a></p>"
                continue;
            }

            $errors = @{}
            Write-Host "[Common Errors] Reorganizing Errors by Plan Node and Error Message"

            foreach ($node in $errorNodes) {
                $key = $node.artefactID + $node.error.msg
                if (-not $errors.ContainsKey($key)) {
                    $errors[$key] = @{
                        representative = $node
                        count = 1
                        firstOccurrence=$node.executionTime
                        lastOccurrence=$node.executionTime
                        sessionInfos=@($node.measures.data.sessionId)
                    }
                } else {
                    $errors[$key].count++
                    if ($errors[$key].representative.attachments.Count -lt $node.attachments.Count) {
                        $errors[$key].representative = $node
                    }
                    $errors[$key].sessionInfos += @($node.measures.data.sessionId)
                    $errors[$key].firstOccurrence = if ($errors[$key].firstOccurrence -gt $node.executionTime) {$node.executionTime} else {$errors[$key].firstOccurrence} 
                    $errors[$key].lastOccurrence = if ($errors[$key].lastOccurrence -lt $node.executionTime) {$node.executionTime} else {$errors[$key].lastOccurrence} 
                }
            }

            $body = ""
            $cacheDir = "$($context.projectInfo.reportCache)\errors_$($execution.id)"
            $null = New-Item -Force $cacheDir -ItemType Directory

            foreach ($kv in ($errors.GetEnumerator() | Sort-Object { $_.Value.count } -Descending | Select-Object -First 5)) {
                $node = $kv.Value.representative
                $screenshotId = ($node.attachments | Where-Object {$_.name -eq "screenshot.jpg"} | Select-Object -First 1).id
                $screenshot = ""

                if ($null -ne $screenshotId) {
                    $fileName = "error_$($screenshotId).jpg"
                    $path = "$($cacheDir)\$fileName"

                    if (-not (Test-Path $path -PathType Leaf)) {
                        $screenshotResponse = Invoke-WebRequest -UseBasicParsing -Method Get -Uri "$($controller.controllerUrl)/rest/resources/$($screenshotId)/content"
                        $screenshotContent = $screenshotResponse.Content
                        $null = New-Item -Force -Path $path
                        $null = Set-Content -Force -Path $path -Value $screenshotContent -Encoding Byte

                        $context.filesToUpload += @(@{
                            name = $fileName
                            path = $path
                        })
                    } elseif ($context.reuploadAttachments) {
                        $context.filesToUpload += @(@{
                            name = $fileName
                            path = $path
                        })
                    }

                    $screenshot = @"
                    <ac:image ac:width='400'>
                        <ri:attachment ri:filename='$fileName' />
                    </ac:image>
"@
                }

                $logId = ($node.attachments | Where-Object {$_.name -eq "selenium_browser.log"} | Select-Object -First 1).id
                $log = ""

                if ($null -ne $logId) {
                    $logResponse = Invoke-WebRequest -UseBasicParsing -Method Get -Uri "$($controller.controllerUrl)/rest/resources/$($logId)/content"

                    # Always work from the raw bytes; .Content decoding is unreliable for .log files
                    if ($logResponse.RawContentStream) {
                        $ms = New-Object System.IO.MemoryStream
                        $logResponse.RawContentStream.Position = 0
                        $logResponse.RawContentStream.CopyTo($ms)
                        $logBytes = $ms.ToArray()
                    } elseif ($logResponse.Content -is [byte[]]) {
                        $logBytes = $logResponse.Content
                    } else {
                        # Last resort: recover original bytes via ISO-8859-1 round-trip
                        $logBytes = [System.Text.Encoding]::GetEncoding('ISO-8859-1').GetBytes([string]$logResponse.Content)
                    }

                    # Decode as UTF-8 with replacement so any odd byte becomes U+FFFD instead of breaking JSON
                    $utf8Decoder = New-Object System.Text.UTF8Encoding($false, $false)
                    $logContent = $utf8Decoder.GetString($logBytes)

                    # Belt-and-suspenders: entity-encode any remaining non-ASCII character so the JSON payload stays pure ASCII
                    $logContent = ConvertTo-AsciiSafeString $logContent

                    $log = @"
                    <ac:structured-macro ac:name='expand' ac:schema-version='1'>
                        <ac:rich-text-body>
                            $([System.Net.WebUtility]::HtmlEncode($logContent).Replace("`n", "<br/>").Replace(";SEVERE;", " <span style=""color: purple; font-weight: bold"">SEVERE</span> ").Replace("] ERROR ", "] <span style=""color: red; font-weight: bold"">ERROR</span> ").Replace(";WARNING;", " <span style=""color: orange; font-weight: bold"">WARNING</span> "))
                        </ac:rich-text-body>
                    </ac:structured-macro>
"@
                }
                $sessionInfos = $(($kv.Value.sessionInfos | Where-Object { "$_" -ne ""} | Select-Object -First 10 | ForEach-Object { "<li>$_</li>"}) -join "")
                if ($sessionInfos -ne "") {
                    $sessionInfos = @"
                    <ac:structured-macro ac:name='expand' ac:schema-version='1'>
                        <ac:rich-text-body>
                            <ul>
                                $sessionInfos
                            </ul>
                        </ac:rich-text-body>
                    </ac:structured-macro>
"@
                }

                $body += @"
                    <tr>
                        <td>$($kv.Value.count)</td>
                        <td>$($(([datetime] '1970-01-01').AddMilliseconds($kv.Value.firstOccurrence).ToLocalTime().ToString('HH:mm:ss')))</td>
                        <td>$($(([datetime] '1970-01-01').AddMilliseconds($kv.Value.lastOccurrence).ToLocalTime().ToString('HH:mm:ss')))</td>
                        <td>$(ConvertTo-AsciiSafeString ([System.Net.WebUtility]::HtmlEncode($node.error.msg)))</td>
                        <td>$log</td>
                        <td>$sessionInfos</td>
                        <td>$screenshot</td>
                    </tr>
"@
            }

            $tables += @"
                <p>
                    Top 5 Fehler bei Ausf&uuml;hrung <a href='$($controller.friendlyControllerUrl)/#/executions/$($execution.id)/steps?tenant=$($controller.projectName)'>$($execution.description)</a>
                </p>
                <table width='1800px'>
                    <thead>
                        <tr>$header</tr>
                    </thead>
                    <tbody>$body</tbody>
                </table>
"@
        }
    }

    return $tables
}