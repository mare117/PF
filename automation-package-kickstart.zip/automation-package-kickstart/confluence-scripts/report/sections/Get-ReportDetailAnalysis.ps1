
. "$PSScriptRoot\detailanalysis\Get-ReportMeasurementsGraph.ps1"
. "$PSScriptRoot\detailanalysis\Get-ReportGraphanaScreenshot.ps1"
. "$PSScriptRoot\detailanalysis\Get-ReportSplunkGraph.ps1"
. "$PSScriptRoot\detailanalysis\Get-ReportSplunkTable.ps1"
. "$PSScriptRoot\detailanalysis\Get-ReportSplunkList.ps1"
. "$PSScriptRoot\detailanalysis\Get-ReportMeasurementsTable.ps1"
. "$PSScriptRoot\detailanalysis\Get-ReportReleaseComparison.ps1"

Function Get-ReportDetailAnalysis {    
    Param(
        $context,
        $analysisConfigs
    )
    
    $body = ""


    foreach($detailAnalysis in $analysisConfigs) {
        if ($null -ne $detailAnalysis.title) {
            $body += @"
<h2>$($detailAnalysis.title)</h2>
"@
        }
        if ($null -ne $detailAnalysis.description) {
            $body += @"
<p>$($detailAnalysis.description)</p>
"@
        }
        switch($detailAnalysis.type) {
            "splunk-table" {
                $body += Get-ReportSplunkTable $context $detailAnalysis
            }
            "step-graph" {
                $body += Get-ReportMeasurementsGraph $context $detailAnalysis
            }
            "splunk-graph" {
                $body += Get-ReportSplunkGraph $context $detailAnalysis
            }
            "splunk-list" {
                $body += Get-ReportSplunkList $context $detailAnalysis
            }
            "graphana-screenshot" {
                $body += Get-ReportGraphanaScreenshot $context $detailAnalysis
            }
            "step-measurements-table" {
                $body += Get-ReportMeasurementsTable $context $detailAnalysis
            }
            "release-comparison" {
                $body += Get-ReportReleaseComparison $context $detailAnalysis
            }
        }
    }

    return $body
}