Function Get-ReportManagementSummaryTable {    
    Param(
        $context
    )
    
    Write-Host "[Summary] Write Management Summary Table"

    $defects = @{};

    $newDefectList = "";

    $defectList = "";

    foreach ($defect in $context.state.current.defects) {
        if ($null -eq $defect.newInExecution) {
            $defect.newInExecution = $context.attachmentSuffix;
        }
        
        if ($null -eq $defect.validatedInExecution -and $defect.validated) {
            $defect.validatedInExecution = $context.attachmentSuffix;
        }

        if ($defect.validatedInExecution -eq $context.attachmentSuffix) {
            $validatedDefectList += Get-DefectReference $defect.key
        } elseif ($defect.newInExecution -eq $context.attachmentSuffix) {
            $newDefectList += Get-DefectReference $defect.key
            $defectList += "<a href=""https://issues.pnet.ch/browse/$($defect.key)"">$($defect.key)</a><br/>"
        } elseif ($defect.newInExecution -le $context.attachmentSuffix -and (-not $defect.validated -or $defect.validatedInExecution -ge $context.attachmentSuffix)) {
            $openDefectList += Get-DefectReference $defect.key
            $defectList += "<a href=""https://issues.pnet.ch/browse/$($defect.key)"">$($defect.key)</a><br/>"
        }
    }


    $splunkLinks = ""
    foreach ($splunkDashboard in $context.splunkDashboards) {
        $splunkUrl = $splunkDashboard.Url.Replace("&", "&amp;")
        $splunkLinks += "<p><a href=""$splunkUrl"" class='external-link' rel='nofollow'>$($splunkDashboard.Name)</a></p>"
    }


    $additionalManagementSummaryRow = ""; 
    
    if ($null -ne $context.projectInfo.additionalManagementSummaryRow) {
        $additionalManagementSummaryRow = Get-SubstitutedTemplate $context.projectInfo.additionalManagementSummaryRow $context.reporting;
    }

    $context.reporting.defect_list = $defectList
    $context.reporting.status_label = @"
        <ac:structured-macro ac:name="status" ac:schema-version="1">
            <ac:parameter ac:name="colour">$(if ($context.passed) {"Green"} elseif ($context.partial) {"Yellow"} elseif ($context.inProgress) {"Blue"} else {"Red"})</ac:parameter>
            <ac:parameter ac:name="title">$(if ($context.passed) {"PASSED"} elseif ($context.partial) {"PARTIAL"} elseif ($context.inProgress) {"IN PROGRESS"} else {"FAILED"})</ac:parameter>
            <ac:parameter ac:name="" />
        </ac:structured-macro>
"@


    return @"
<table class="wrapped fixed-width">
    <tbody>
        <tr>
            <th>
                <div class="content-wrapper">
                    <p>
                        $($context.reporting.status_label)
                    </p>
                </div>
            </th>
            <th>
                <div class="content-wrapper">
                    <p><a href="https://confluence.pnet.ch/pages/viewpage.action?pageId=[[[pageId]]]">$($context.pageTitle)</a></p>
                </div>
            </th>
            <th>New Defects:</th>
            <th>Open Defects:</th>
            <th>Validated Defects:</th>
        </tr>
        <tr>
            <td>
                <p>Test Scenario &amp;</p>
                <p>Deviations</p>
            </td>
            <td>$($context.scenarios)</td>
            <td>
                <div class="content-wrapper">
                    <p>$newDefectList</p>
                </div>
            </td>
            <td>
                <div class="content-wrapper">
                    <p>$openDefectList</p>
                </div>
            </td>
            <td>
                <div class="content-wrapper">
                    <p>$validatedDefectList</p>
                </div>
            </td>
        </tr>
        <tr>
            <td>
                <p>Splunk Dashboards</p>
            </td>
            <td>
                $splunkLinks
            </td>
            <td>
                <div class="content-wrapper">
                    <p><br /></p>
                </div>
            </td>
            <td>
                <div class="content-wrapper">
                    <p><br /></p>
                </div>
            </td>
            <td>
                <div class="content-wrapper">
                    <p><br /></p>
                </div>
            </td>
        </tr>
        $additionalManagementSummaryRow
        <tr>
            <td>Conclusion</td>
            <td colspan="4">
                [[[conclusion]]]
                <ul>
                    $(($context.conclusions | Sort-Object | Select-Object -Unique | ForEach-Object { "<li>$_</li>"}) -join "")
                </ul>
            </td>
        </tr>
    </tbody>
</table>
"@
}

Function Get-DefectReference {
    param($key)

    @"
<ac:structured-macro ac:name="jira" ac:schema-version="1">
    <ac:parameter ac:name="server">Jira</ac:parameter>
    <ac:parameter ac:name="columnIds">
        issuekey,summary,issuetype,created,updated,duedate,assignee,reporter,priority,status,resolution
    </ac:parameter>
    <ac:parameter ac:name="columns">
        key,type,created,updated,due,assignee,reporter,priority,status,resolution
    </ac:parameter>
    <ac:parameter ac:name="serverId">e933993c-744f-34be-9434-bc1e3b89821c
    </ac:parameter>
    <ac:parameter ac:name="key">$key</ac:parameter>
</ac:structured-macro><br/>
"@
}


Function Get-SubstitutedTemplate {
    param($template, $data)
    return [Regex]::Replace($template, "@\{(.*?)\}", {
        param($match) 

        $key = $match.Groups[1].Value;
        $value =  if ($data.ContainsKey($key)) { $data[$key] } else { $key }
        return $value
    });
}