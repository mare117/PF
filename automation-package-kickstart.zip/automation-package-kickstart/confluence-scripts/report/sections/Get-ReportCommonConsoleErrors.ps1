. "$PSScriptRoot\..\..\common\Set-Controller.ps1"

# Encode every non-ASCII character as a numeric HTML entity so the resulting
# string is safe to embed in a JSON body that will be parsed as UTF-8.
Function ConvertTo-AsciiSafeString {
    Param([string] $text)
    if ([string]::IsNullOrEmpty($text)) { return $text }
    $sb = New-Object System.Text.StringBuilder
    foreach ($ch in $text.ToCharArray()) {
        $code = [int][char]$ch
        if ($code -gt 127) {
            [void]$sb.Append("&#$code;")
        } else {
            [void]$sb.Append($ch)
        }
    }
    return $sb.ToString()
}

Function Get-ReportCommonConsoleErrors {    
    Param(
        $context
    )


    if ($context.projectInfo.skipCommonConsoleErrors) {
        return ""
    }

    $tables = ""
    $header = "<th>Instances</th><th>Severity</th><th>First occurred</th><th>Last occurred</th><th>Console Error</th><th>Error Messages</th><th>Session Infos</th><th>Screenshot</th>"

    foreach ($controller in $context.controllers) {

        Set-Controller $controller
        
        foreach ($execution in $controller.executions) {  # Verwende den controller, um auf die executions zuzugreifen
            Write-Host "[Common Console Errors] Fetch raw data for execution $($controller.friendlyControllerUrl)/#/executions/$($execution.id)/steps?tenant=$($controller.projectName)"
            
            $errorNodes = Invoke-RestMethod -UseBasicParsing -Method Get -Uri "$($controller.controllerUrl)/rest/executions/$($execution.id)/reportnodes-with-errors?limit=1000" -Header @{ "Content-Type"="application/json" }
            
            if ($errorNodes.Count -eq 0) {
                $tables += "<p>Keine Fehler bei Ausf&uuml;hrung <a href=""$($controller.friendlyControllerUrl)/#/executions/$($execution.id)/steps?tenant=$($controller.projectName)"">$($execution.description)</a></p>"
                continue
            }
            
            $consoleErrors = @{}
            Write-Host "[Common Console Errors] Reorganizing by Console Error"
            
            foreach ($node in $errorNodes) {
                foreach ($attachment in $node.attachments) {
                    if ($attachment.name -eq "selenium_browser.log") {
                        if (-not $attachment.id) {
                            continue;
                        }
                        $logResponse = Invoke-WebRequest -UseBasicParsing -Method Get -Uri "$($controller.controllerUrl)/rest/resources/$($attachment.id)/content"

                        # Always work from raw bytes; .Content decoding is unreliable for .log files
                        if ($logResponse.RawContentStream) {
                            $ms = New-Object System.IO.MemoryStream
                            $logResponse.RawContentStream.Position = 0
                            $logResponse.RawContentStream.CopyTo($ms)
                            $logBytes = $ms.ToArray()
                        } elseif ($logResponse.Content -is [byte[]]) {
                            $logBytes = $logResponse.Content
                        } else {
                            $logBytes = [System.Text.Encoding]::GetEncoding('ISO-8859-1').GetBytes([string]$logResponse.Content)
                        }

                        # Decode as UTF-8 with replacement so any odd byte becomes U+FFFD instead of breaking JSON
                        $utf8Decoder = New-Object System.Text.UTF8Encoding($false, $false)
                        $logString = $utf8Decoder.GetString($logBytes)
                        $logContent = $logString -split "`r?`n"

                        foreach ($logEntry in $logContent) {
                            if ($logEntry -match "^\d{2}\/\d{2}\/\d{4} \d{2}:\d{2}:\d{2};(SEVERE|WARNING|ERROR|INFO);(.+)$") {
                                $severity = $matches[1]
                                $message = $matches[2]

                                if (-not $consoleErrors.ContainsKey($message)) {
                                    $consoleErrors[$message] = @{
                                        count = 1
                                        severity = $severity
                                        errors = @()
                                        screenshot = ""
                                        firstOccurrence=$node.executionTime
                                        lastOccurrence=$node.executionTime
                                        sessionInfos=@($node.measures.data.sessionId)
                                    }
                                } else {
                                    $consoleErrors[$message].count++
                                    $consoleErrors[$message].sessionInfos += @($node.measures.data.sessionId)
                                    $consoleErrors[$message].firstOccurrence = if ($consoleErrors[$message].firstOccurrence -gt $node.executionTime) {$node.executionTime} else {$consoleErrors[$message].firstOccurrence} 
                                    $consoleErrors[$message].lastOccurrence = if ($consoleErrors[$message].lastOccurrence -lt $node.executionTime) {$node.executionTime} else {$consoleErrors[$message].lastOccurrence} 
                                }

                                $consoleErrors[$message].errors += $node

                                $screenshotId = ($node.attachments | Where-Object { $_.name -eq "screenshot.jpg" } | Select-Object -First 1).id
                                if ($null -ne $screenshotId) {
                                    $fileName = "error_$($screenshotId).jpg"
                                    $path = "$($context.projectInfo.reportCache)\errors_$($execution.id)\$fileName"

                                    if (-not (Test-Path $path -PathType Leaf)) {
                                        $screenshotResponse = Invoke-WebRequest -UseBasicParsing -Method Get -Uri "$($controller.controllerUrl)/rest/resources/$screenshotId/content"
                                        $screenshotContent = $screenshotResponse.Content
                                        $null = New-Item -Force -Path $path
                                        $null = Set-Content -Force -Path $path -Value $screenshotContent -Encoding Byte
                                        
                                        $context.filesToUpload += @(@{
                                            name = $fileName
                                            path = $path
                                        })
                                    } elseif ($context.reuploadAttachments) {
                                        $context.filesToUpload += @(@{
                                            name = $fileName
                                            path = $path
                                        })
                                    }

                                    $consoleErrors[$message].screenshot = @"
                                        <ac:image ac:width='400'>
                                            <ri:attachment ri:filename='$fileName' />
                                        </ac:image>
"@
                                }
                            }
                        }
                    }
                }
            }

            $body = ""
            foreach ($kv in ($consoleErrors.GetEnumerator() | Sort-Object { $_.Value.count } -Descending | Select-Object -First 5)) {
                $consoleError = $kv.Key
                $errorEntries = $kv.Value.errors
                $severity = $kv.Value.severity

                $errorMessages = ""
                foreach ($errorEntry in $errorEntries | Select-Object -First 5) {
                    $expandTitle = $errorEntry.error.msg -split ":" | Select-Object -First 1
                    $errorMessages += @"
                        <ac:structured-macro ac:name='expand' ac:schema-version='1'>
                            <ac:parameter ac:name='title'>$(ConvertTo-AsciiSafeString ([System.Net.WebUtility]::HtmlEncode($expandTitle)))</ac:parameter>
                            <ac:rich-text-body>
                                $(ConvertTo-AsciiSafeString ([System.Net.WebUtility]::HtmlEncode($errorEntry.error.msg)))
                            </ac:rich-text-body>
                        </ac:structured-macro>
"@
                }


                $sessionInfos = $(($kv.Value.sessionInfos | Where-Object { "$_" -ne ""} | Select-Object -First 10 | ForEach-Object { "<li>$_</li>"}) -join "")
                if ($sessionInfos -ne "") {
                    $sessionInfos = @"
                    <ac:structured-macro ac:name='expand' ac:schema-version='1'>
                        <ac:rich-text-body>
                            <ul>
                                $sessionInfos
                            </ul>
                        </ac:rich-text-body>
                    </ac:structured-macro>
"@
                }

                $body += @"
                    <tr>
                        <td>$($kv.Value.count)</td>
                        <td>$severity</td>
                        <td>$($(([datetime] '1970-01-01').AddMilliseconds($kv.Value.firstOccurrence).ToLocalTime().ToString('HH:mm:ss')))</td>
                        <td>$($(([datetime] '1970-01-01').AddMilliseconds($kv.Value.lastOccurrence).ToLocalTime().ToString('HH:mm:ss')))</td>
                        <td>$(ConvertTo-AsciiSafeString ([System.Net.WebUtility]::HtmlEncode($consoleError)))</td>
                        <td>$errorMessages</td>
                        <td>$sessionInfos</td>
                        <td>$($kv.Value.screenshot)</td>
                    </tr>
"@
            }

            $tables += @"
                <p>
                    Top 5 Console Errors bei Ausf&uuml;hrung <a href='$($controller.friendlyControllerUrl)/#/executions/$($execution.id)/steps?tenant=$($context.projectInfo.projectName)'>$($execution.description)</a>
                </p>
                <table style='width: 100%; max-width: 1800px;'>
                    <thead>
                        <tr>$header</tr>
                    </thead>
                    <tbody>$body</tbody>
                </table>
"@
        }
    }

    return $tables
}