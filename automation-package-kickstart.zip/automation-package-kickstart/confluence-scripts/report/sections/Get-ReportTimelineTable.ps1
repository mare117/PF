Function Get-ReportTimelineTable {    
    Param(
        $context
    )
    
    Write-Host "[Summary] Write Report Timeline Table"  

    $body = ""

    $timeline = $context.timeline | Sort-Object -Property { $_.time }

    $engineers = ($context.projectInfo.engineerConfluenceIds | ForEach-Object {@"
    <em>
        <ac:link>
            <ri:user ri:username="$_" />
        </ac:link>
    </em>
"@}) -join "/"

    foreach ($entry in $timeline) {
        
        $body += @"
<tr>
    <td><em>$(([datetime] '1970-01-01').AddSeconds($entry.time / 1000.0).ToLocalTime().ToString('HH:mm'))</em></td>
    <td>
        $engineers
    </td>
    <td><em>$($entry.description)</em></td>
    <td><em>$($entry.remark)</em></td>
</tr>
"@
    }

    return @"
<table class="fixed-width wrapped">
    <thead>
        <tr>
            <th>Zeit (HH:MM)</th>
            <th>Performanceengineer</th>
            <th>Aktion / Ereignis</th>
            <th>Kommentar</th>
        </tr>
    </thead>
    <tbody>
        $body
    </tbody>
</table>
"@
}