Param(
    [Parameter(Mandatory=$false)] $executionIds = "",
    [Parameter(Mandatory=$false)] $reportConfigFile = ".\projectInfo.ps1",
    [Parameter(Mandatory=$false)] $journalFile = "report_cache\journal_$((Get-Date).Date.ToString("yyyMMdd")).json",
    [Parameter(Mandatory=$false)] $analysisScope = $null,
    [switch] $passed,
    [switch] $partial,
    [switch] $inProgress,
    [switch] $reuploadAttachments,
    [switch] $referenceRun,
    $qcSession = $null
)



$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

. "$reportConfigFile"


if ("$executionIds" -eq "" -and -not (Test-Path -Path $journalFile) -and -not $inProgress) 
{
    Write-Host @"

    Create Confluence Report based on Execution Id
     
    Usage:
        - In Powershell, execute:

            .\Write-Report.ps1 [-executionIds @(,"executionId1"[, "executionId2"...])]  [-reportConfigFile ./projectInfoPEAK.ps1] [-passed] [-partial] [-inProgress] [-referenceRun] [-reuploadAttachments]

          where

            [-executionIds]        Comma-Separated Execution Id of the execution used to generate the clickpaths, 
                                   optional if "-inProgress" is set
            [-reportConfigFile]    Override projectInfo.ps1 file as the default report configuration
            [-passed/-partial]     Override default FAILED status
            [-inProgress]          Interactive mode, makes report of currently running executions and allows to live-report a custom timeline
            [-referenceRun]        Mark the run as reference run, also sets the archive flag in step and records the 
                                   reference values for a given test in the current-state.json file of the parent report page
            [-reuploadAttachments] Force re-upload of attachements, to be used when the attachment generation failed in a previous attempt
            
"@
    exit
}


try {


    . "$PSScriptRoot\compilation\Write-ReportConfluencePage.ps1"
    . "$PSScriptRoot\compilation\Get-Report.ps1"
    . "$PSScriptRoot\compilation\Get-OverallTestState.ps1"
    . "$PSScriptRoot\compilation\Set-OverallTestState.ps1"
    . "$PSScriptRoot\..\common\Get-Context.ps1"
    . "$PSScriptRoot\..\common\Set-HousekeepingProtection.ps1"
    . "$PSScriptRoot\..\common\Set-UserJournalEntries.ps1"
    . "$PSScriptRoot\..\qc\Set-QCRunStatus.ps1"



    $journal = [PSCustomObject] @{
        executionIds = if ($executionIds -eq "") { @() } else {@($executionIds -split ",")}
        timeline = @()
        analysisStartTime = ""
    }

    $null = New-Item -Force -ItemType Directory $projectInfo.reportCache

    if (Test-Path -Path $journalFile) {
        $journal = (Get-Content $journalFile -Encoding UTF8 | ConvertFrom-Json)
    }

    if ($inProgress) {
        $prompt = ""

        while ($prompt -ne "stop") {
            if ($prompt.StartsWith("peak start ")) {
                $journal.analysisStartTime = (Get-Date -Format "dd.MM.yyyy") + " " + ($prompt -replace "peak start ", "").Trim();
            }
            Set-UserJournalEntries $journal $prompt

            $startTime = if ($null -ne $journal.analysisStartTime -and $journal.analysisStartTime -ne "") {(New-TimeSpan -Start ([datetime] "01/01/1970 01:00Z") -End (Get-Date $journal.analysisStartTime)).TotalSeconds * 1000} else {0}
            $context = Get-Context $journal.executionIds $projectInfo $passed $partial $inProgress $reuploadAttachments $qcSession $analysisScope $startTime

            Get-OverallTestState $context

            Start-QCRuns $context

            $context.timeline += $journal.timeline
            $journal.executionIds = @($context.controllers | ForEach-Object { $_.executions.id })
            ($journal | ConvertTo-Json) | Out-File $journalFile -Encoding UTF8

            $report = Get-Report $context
            
            Write-ReportConfluencePage $report $context
            Set-OverallTestState $context

            $prompt = Read-Host "Enter an event to add a journal entry to the timeline, nothing and press enter to update the live report, ""peak start HH:MM"" for a start peak time, or ""stop"" to stop live journaling`nYour input"
            
        }

        Write-Host "Stopping live report"
    } else {

        $startTime = if ($null -ne $journal.analysisStartTime -and $journal.analysisStartTime -ne "") {(New-TimeSpan -Start ([datetime] "01/01/1970 01:00Z") -End (Get-Date $journal.analysisStartTime)).TotalSeconds * 1000} else {0}
        $context = Get-Context $journal.executionIds $projectInfo $passed $partial $inProgress $reuploadAttachments $qcSession $analysisScope $startTime
        Get-OverallTestState $context

        if (-not $context) {
            Write-Host "Error: Get-Context returned null."
            exit
        }

        $context.timeline += $journal.timeline
        if ($referenceRun) {
            $context.pageTitle += " - REFERENCE"
            Set-HousekeepingProtection $context
        }
        $report = Get-Report $context
        Write-ReportConfluencePage $report $context
        
        Set-QCRunStatus $context
        
        Set-OverallTestState $context $referenceRun
    }

} catch {
    Write-Error "$($Error[0].Exception.Message)`n$($Error[0].ScriptStackTrace)"
}