Param(
    [Parameter(Mandatory=$true)] $jiraId = "",
    [Parameter(Mandatory=$false)] $reportConfigFile = ".\projectInfo.ps1"
)

. "$reportConfigFile"


. "$PSScriptRoot\compilation\Get-OverallTestState.ps1"
. "$PSScriptRoot\compilation\Set-OverallTestState.ps1"
. "$PSScriptRoot\..\common\Get-Context.ps1"

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$context = Get-Context @() $projectInfo $false $false $false $false $null $null
Get-OverallTestState $context

$defect = ($context.state.current.defects | Where-Object { $_.key -eq $jiraId })
$defect.validated = $false
$defect.validatedInExecution = $null

Set-OverallTestState $context