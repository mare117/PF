Function Set-ReportSplunkDownloads {    
    Param(
        $context
    )

    if ($context.inProgress) { return }

    $detailAnalyses = @()
    if ($context.projectInfo.reportStructure) {
        $detailAnalyses = @(
            ($context.projectInfo.reportStructure | Where-Object { ($null -eq $_.scope) -or ($context.scope.Contains($_.scope))}).sections.analysisConfig | ForEach-Object { $context.projectInfo.$($_)}
        )
    } else {
        $detailAnalyses = @(
            $context.projectInfo.detailAnalysis,
            $context.projectInfo.transactionsAnalysis,
            $context.projectInfo.serverMonitoring
        )
    }

    foreach($detailAnalysis in ($detailAnalyses | Where-Object { $_.type -eq "splunk-graph" })) {
        $dashboardName=if ($null -eq $detailAnalysis.dashboardName) { $context.projectInfo.splunkDashboards.Name | Select-Object -First 1 } else { $detailAnalysis.dashboardName }
        $dashboard = $context.splunkDashboards | Where-Object { $_.Name -eq $dashboardName } | Select-Object -First 1
        
        foreach($title in $detailAnalysis.splunkGraphs) {
            $fileName = "$($title.Replace(' ', '_'))_$($context.attachmentSuffix).png";
            $filePath = "$($context.projectInfo.reportCache)\$fileName";
            $downloadFileName = "$($title)_*_Splunk.png"
    
            Write-Host "[Splunk] Gather Splunk download info for Graph $title, url: $($dashboard.Url)"
            $context.splunkGraphsToDownload += @(@{
                title=$title
                fileName=$fileName
                filePath=$filePath
                downloadFileName=$downloadFileName
                tabName=$detailAnalysis.tabName
                dashboardName=$dashboardName
            })
        }
    }
    

    if ($context.reuploadAttachments) {
        foreach ($splunkGraph in ($context.splunkGraphsToDownload | Where-Object { (Test-Path -Path $_.filePath -PathType Leaf)})) {
            $context.filesToUpload += @(@{
                name=$splunkGraph.fileName
                path=$splunkGraph.filePath
            });
        }
    }

    foreach($detailAnalysis in ($detailAnalyses | Where-Object { $_.type -eq "splunk-table" })) {

        $dashboardName=if ($null -eq $detailAnalysis.dashboardName) { $context.projectInfo.splunkDashboards.Name | Select-Object -First 1 } else { $detailAnalysis.dashboardName }
        $dashboard = $context.splunkDashboards | Where-Object { $_.Name -eq $dashboardName } | Select-Object -First 1
        
        
        foreach($title in $detailAnalysis.splunkTables) {
            
            $fileName = "$($title.Replace(' ', '_'))_$($context.attachmentSuffix).csv";
            $filePath = "$($context.projectInfo.reportCache)\$fileName";
            $downloadFileName = "$($title)_*_Splunk.csv"
    
            Write-Host "[Splunk] Gather Splunk download info for Table $title, url: $($dashboard.Url)"
            $context.splunkCSVsToDownload += @(@{
                title=$title
                fileName=$fileName
                filePath=$filePath
                downloadFileName=$downloadFileName
                dashboardName=$dashboardName
                tabName=$detailAnalysis.tabName
            })
        }
    }


    $dashboardTabDownloads = @{}
    foreach($splunkCSV in ($context.splunkCSVsToDownload | Where-Object { (-not (Test-Path -Path $_.filePath -PathType Leaf)) })) {
        $dashboard = $splunkCSV.dashboardName;
        $tab = if ($null -ne $splunkCSV.tabName) { $splunkCSV.tabName } else { "" };
        if (-not $dashboardTabDownloads.ContainsKey($dashboard)) {
            $dashboardTabDownloads[$dashboard] = @{}
        }

        if (-not $dashboardTabDownloads[$dashboard].ContainsKey($tab)) {
            $dashboardTabDownloads[$dashboard][$tab] = @{
                csvs=@()
                pngs=@()
            }
        }

        $dashboardTabDownloads[$dashboard][$tab].csvs += @($splunkCSV)
    }
    foreach($splunkPNG in ($context.splunkGraphsToDownload | Where-Object { (-not (Test-Path -Path $_.filePath -PathType Leaf)) })) {
        $dashboard = $splunkPNG.dashboardName;
        $tab = if ($null -ne $splunkPNG.tabName) { $splunkPNG.tabName } else { "" };
        if (-not $dashboardTabDownloads.ContainsKey($dashboard)) {
            $dashboardTabDownloads[$dashboard] = @{}
        }

        if (-not $dashboardTabDownloads[$dashboard].ContainsKey($tab)) {
            $dashboardTabDownloads[$dashboard][$tab] = @{
                csvs=@()
                pngs=@()
            }
        }
        $dashboardTabDownloads[$splunkPNG.dashboardName][$tab].pngs += @($splunkPNG)
    }

    foreach($dashboardName in $dashboardTabDownloads.Keys) {
      

        $clipboard = @"

            sleep = async function(ms) {
                return new Promise(resolve => setTimeout(resolve, ms));
            }

            getElement = async function(xPath) {
                let element = null;
                let attempt = 400;
                
                while (!element && attempt-- > 0) {
                    element = document.evaluate(xPath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue
                    await sleep(50);
                }
                return element;
            }

            clickElement = async function(xPath) {
                let element = await getElement(xPath);
                if (element != null) element.click();
                return element;
            }

            checkElementDoesNotExist = async function(xPath) {
                let element = document.evaluate(xPath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                let attempt = 800;
                
                while (element && attempt-- > 0) {
                    element = document.evaluate(xPath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue
                    await sleep(50);
                }
            }

            clickPanelExportButton = async function (title) {
                await getElement(``//div[@data-id=(//*[text()='`${title}']/ancestor::*[@data-test='absolute-item']/@data-id) and @data-test='action-menus']//button[@data-test='export-button']``);
                await checkElementDoesNotExist(``//*[text()='`${title}']/ancestor::*[@data-test='viz-item']//*[@aria-label='Status ok']``);
                return await clickElement(``//div[@data-id=(//*[text()='`${title}']/ancestor::*[@data-test='absolute-item']/@data-id) and @data-test='action-menus']//button[@data-test='export-button']``);
            };

            switchTab = (tab) => clickElement(``//*[text()='`${tab}']/ancestor::button[@data-test='tab']``);

            exportCsv = async function(title) {
                if (title == '') return;
                if (await clickPanelExportButton(title)) {
                    await clickElement("//*[@data-test='modal']//button[@data-test='select']");
                    await clickElement("//button[@data-test='option' and @data-test-value='csv']");
                    await checkElementDoesNotExist("//button[@data-test='option' and @data-test-value='csv']");
                    await clickElement("//*[@data-test='modal']//button[@data-test='export-btn']");
                    await checkElementDoesNotExist("//*[@data-test='modal']");
                } else {
                    console.error(``Panel `${title} not found``);
                }
            }

            exportPng = async function(title) {
                if (title == '') return;
                if (await clickPanelExportButton(title)) {
                    await clickElement("//*[@data-test='modal']//button[@data-test='export-btn']");
                    await checkElementDoesNotExist("//*[@data-test='modal']");
                } else {
                    console.error(``Panel `${title} not found``);
                } 
            }
"@


        $tabDownloads = $dashboardTabDownloads[$dashboardName];

        
        $now = Get-Date

        Write-Host "[Splunk] Splunk downloads"

        
        $dashboard = ($context.splunkDashboards | Where-Object { $_.Name -eq $dashboardName }) | Select-Object -First 1
        $splunkUrl = $dashboard.Url

        Write-Host "[Splunk] Execute Javascript copied into clipboard to collect exports for $splunkUrl"
        $null = Start-Process $splunkUrl
        
        $null = New-Item -Force -ItemType Directory $context.projectInfo.reportCache

        
        foreach($tabName in $tabDownloads.Keys) {
            $splunkDownloads = $tabDownloads[$tabName];

            if ($tabName -ne "") {
                $clipboard += @"

            await switchTab('$tabName');
"@
            }
            
            foreach($splunkGraph in $splunkDownloads.pngs) {
                $clipboard += @"

            await exportPng('$($splunkGraph.title)');
"@
            }
            foreach($splunkCSV in $splunkDownloads.csvs) {
                $clipboard += @"

            await exportCsv('$($splunkCSV.title)');
"@
            }

        }

        Set-Clipboard $clipboard;

        foreach($tabName in $tabDownloads.Keys) {
            $splunkDownloads = $tabDownloads[$tabName];

            if (($splunkDownloads.csvs.Count + $splunkDownloads.pngs.Count) -gt 0 ) {

                
                foreach($splunkGraph in $splunkDownloads.pngs) {
                    $file = $null
                    $retries = 60
                    while ($null -eq $file -and $retries-- -gt 0) {
                        $files = Get-ChildItem -Path $context.projectInfo.downloadFolder -Filter $splunkGraph.downloadFileName 
                        $file = $files  | Where-Object { $_.CreationTime.Ticks -gt $now.Ticks } | Select-Object -First 1
                        Write-Host "[Splunk] Polling for $($splunkGraph.downloadFileName)..."
                        if ($null -eq $file)  { $null = Start-Sleep -Seconds 2 }
                    }
                    
                    if ($null -eq $file) { continue };
                    
                    $null = Move-Item -Path $file.FullName -Destination $splunkGraph.filePath -Force;
                    
                    $context.filesToUpload += @(@{
                        name=$splunkGraph.fileName
                        path=$splunkGraph.filePath
                    });
                }

                foreach($splunkCSV in $splunkDownloads.csvs) {
                    $file = $null
                    $retries = 60
                    while ($null -eq $file -and $retries-- -gt 0) {
                        $files = Get-ChildItem -Path $context.projectInfo.downloadFolder -Filter $splunkCSV.downloadFileName 
                        $file = $files  | Where-Object { $_.CreationTime.Ticks -gt $now.Ticks } | Select-Object -First 1
                        Write-Host "[Splunk] Polling for $($splunkCSV.downloadFileName)..."
                        if ($null -eq $file)  { $null = Start-Sleep -Seconds 2 }
                    }
                    if ($null -eq $file) { continue };
                    $null = Move-Item -Path $file.FullName -Destination $splunkCSV.filePath -Force;
                }
            }
        }
    }   
}