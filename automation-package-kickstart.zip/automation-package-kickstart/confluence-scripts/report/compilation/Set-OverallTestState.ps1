
. "$PSScriptRoot\..\..\common\Update-ConfluencePage.ps1"
Function Set-OverallTestState {    
    Param(
        $context,
        $referenceRun = $false
    )
    
    $context.state.current.reporting = $context.reporting
    if ($referenceRun) {
        $context.state.history = @(,
            @{
                releaseNumber=$context.projectInfo.releaseNumber
                state = $context.state.current
            }
        ) + @($context.state.history | Where-Object { $_.releaseNumber -ne $context.projectInfo.releaseNumber } | Sort-Object -Property releaseNumber -Descending)
    }

    Set-Content -Path $context.statePath -Value ($context.state | ConvertTo-Json -Depth 10)
    Update-ConfluencePage -context $context -id $context.projectInfo.parentConfluencePageId -filesToUpload @(,@{
        name=$context.stateFile
        path=$context.statePath
    })
} 