
. "$PSScriptRoot\..\..\common\Update-ConfluencePage.ps1"
. "$PSScriptRoot\..\..\common\Get-UtfEncodedConfluencePage.ps1"



Function Write-ReportConfluencePage {    
    Param(
        $body,
        $context
    )
    $headers = $context.confluenceHeaders

    Write-Host "[Confluence] Get parent page..."
    $parent = Get-UtfEncodedConfluencePage $context.projectInfo.parentConfluencePageId $headers
    Write-Host "[Confluence] Check Siblings for existing page..."

    $result = Invoke-RestMethod -Method Get -Uri "https://confluence.pnet.ch/rest/api/content/$($context.projectInfo.parentConfluencePageId)/child?expand=page" -Headers $headers -UseBasicParsing
    $current = $result.page.results | Where-Object { $_.title.startsWith($context.pagePrefix) }


    if ($null -eq $current) {
        Write-Host "[Confluence] Create page..."    
        $request = @{
            status="current"
            version=@{
                number=1
                message="Created via API"
            }
            title=$context.pageTitle
            ancestors=@(, @{ id=$context.projectInfo.parentConfluencePageId })
            space=$parent.space
            type="page"
            body=@{
                storage=@{
                    value=""
                    representation="storage"
                }
            }
        }
        $current = Invoke-RestMethod -Method Post -Uri "https://confluence.pnet.ch/rest/api/content" -Headers $headers -UseBasicParsing -Body ($request | ConvertTo-Json)
    } 
    Write-Host "[Confluence] Get current page... https://confluence.pnet.ch/pages/viewpage.action?pageId=$($current.id)"
    $current = Get-UtfEncodedConfluencePage $current.id $headers
    $pageId = $current.id

    $conclusion = ""
    $match = [regex]::Matches(($current.body.storage.value -replace "\n",""), "Management Summary.*?Conclusion\s*<\/td>.*?<td.*?>(?<conclusion>.*?)<\/td>");
    if ($match.Count -gt 0 ) {
        $conclusion = $match[0].Groups['conclusion'].Value
    }

    $body = $body.Replace('[[[pageId]]]', $pageId)
    $body = $body.Replace('[[[conclusion]]]', $conclusion)


    $context.reporting.conclusion = $conclusion;

    $current.title=$context.pageTitle
    $context.confluencePageId = $pageId
    $context.confluencePageUrl = "https://confluence.pnet.ch/pages/viewpage.action?pageId=$pageId"
    $context.reporting.report_url = $context.confluencePageUrl;
    $context.reporting.page_title = $context.pageTitle;

    Update-ConfluencePage $context $body $current.id $context.filesToUpload $current


    $updateAdditionalPages = if ($null -ne $context.projectInfo.updateAdditionalPages) {$context.projectInfo.updateAdditionalPages} else {
        @(

            ,@{
                confluencePageId=$context.projectInfo.parentConfluencePageId
                rexTemplate="(?<pre1>.*(Table of Test Runs:))" +  # capture until start of table of test runs
                            "((?<pre2>.*)" + # pre3 gorup is to capture the extracts of the runs which we do not want to modify (i.e. if we want to re-write the summary for an older run)
                                "(?<existingextract>(<p>.*?@{page_prefix}.*?<\/p>))" + # capture existing extract
                            "){0,1}" + 
                            "(?<post>.*)" # capture everything else
                
                replacementTemplate="`${pre1}`${pre2}" +
                                "<p>" +
                                    "<ac:structured-macro ac:name=""excerpt-include"" ac:schema-version=""1"">" +
                                        "<ac:parameter ac:name="""">" +
                                            "<ac:link>" +
                                                "<ri:page ri:space-key=""NT"" ri:content-title=""@{page_title}"" />" +
                                            "</ac:link>" +
                                        "</ac:parameter>" +
                                    "</ac:structured-macro>" +
                                "</p>" +
                                "`${post}" 
                                }
        )
    }
    foreach($updateAdditionalPage in $updateAdditionalPages) {
        $current = if ($updateAdditionalPage.confluencePageId -eq $parent.id) {
            $parent;
        } else {
            Write-Host "[Confluence] Get page... https://confluence.pnet.ch/pages/viewpage.action?pageId=$($updateAdditionalPage.confluencePageId)"
            Get-UtfEncodedConfluencePage $updateAdditionalPage.confluencePageId $headers
        }
        $body = $current.body.storage.value -replace "\n", ""
        $newBody = Get-UpdatedSummaryPage $context.reporting $updateAdditionalPage.rexTemplate $updateAdditionalPage.replacementTemplate $body

        if ($newBody -ne $body) {
            Update-ConfluencePage $context $newBody $current.id -current $current
        }
    }
    
}


Function Get-UpdatedSummaryPage($data, $rexTemplate, $replacementTemplate, $body) {    
    
    $rex = [Regex]::Replace($rexTemplate, "@\{(.*?)\}", {
        param($match) 

        $key = $match.Groups[1].Value;
        $value =  if ($data.ContainsKey($key)) { $data[$key] } else { "" }
        [Regex]::Escape($value)
    });


    $replacement = [Regex]::Replace($replacementTemplate, "@\{(.*?)\}", {
        param($match) 

        $key = $match.Groups[1].Value;
        $value =  if ($data.ContainsKey($key)) { $data[$key] } else { "" }
        return $value
        #[System.Net.WebUtility]::HtmlEncode($value)
    });

    return $body  -replace $rex, $replacement
}

