This folder contains high-level functions which are used to compile the report.

Get-Report is meant to only call methods in ../sections or summaryprocessing, which is used to add further context after generating the report body, and defines the overall, standardized structure of the report sections. 

All methods called by Get-Report should by convention use the context variable $context as a parameter.