. "$PSScriptRoot\..\sections\Get-ReportPlatformStatusTable.ps1"
. "$PSScriptRoot\..\sections\Get-ReportSummaryTable.ps1"
. "$PSScriptRoot\..\sections\Get-ReportManagementSummaryTable.ps1"
. "$PSScriptRoot\..\sections\Get-ReportTimelineTable.ps1"
. "$PSScriptRoot\..\sections\Get-ReportDetailAnalysis.ps1"
. "$PSScriptRoot\..\sections\Get-ReportExecutionDetailsSection.ps1"
. "$PSScriptRoot\..\sections\Get-ReportCommonErrors.ps1"
. "$PSScriptRoot\..\sections\Get-ReportCommonConsoleErrors.ps1"
. "$PSScriptRoot\preprocessing\Set-ReportSplunkDownloads.ps1"
. "$PSScriptRoot\..\..\common\Set-Controller.ps1"

Function Get-Report {    
    Param(
        $context
    )

    # Download all required splunk graphs at once.
    Set-ReportSplunkDownloads $context

    $body = ""

    # Check if the new configurable structure exists, otherwise use the legacy structure
    if ($context.projectInfo.reportStructure) {
        Write-Host "[INFO] Using new configurable report structure"
        # Generate report sections based on the configurable structure
        foreach ($reportSection in $context.projectInfo.reportStructure) {
            if ($null -ne $reportSection.scope -and (-not $context.scope.Contains($reportSection.scope))) {
                continue;
            }
            if ($reportSection.type -eq "collapsible") {
                $body += @"
<hr />
<h1>$($reportSection.title)</h1>
<ac:structured-macro ac:name="expand" ac:schema-version="1">
    <ac:rich-text-body>
"@
                
                foreach ($section in $reportSection.sections) {
                    $body += Get-ReportSectionContent $context $section
                }

                $body += @"
    </ac:rich-text-body>
</ac:structured-macro>
"@
            }
            elseif ($reportSection.type -eq "simple") {
                $body += @"
<hr />
<h1>$($reportSection.title)</h1>
"@
                foreach ($section in $reportSection.sections) {
                    $body += Get-ReportSectionContent $context $section
                }
            }
        }
    }
    else {
        Write-Host "[INFO] Using legacy report structure"
        # Legacy structure - updated to match main branch
        $body += Get-LegacyReportStructure $context
    }

    # Zusammenbau des gesamten Berichts
    return @"
<ac:layout>
    <ac:layout-section ac:type="two_right_sidebar">
        <ac:layout-cell>
            $(Get-ReportSummaryTable $context)
        </ac:layout-cell>
        <ac:layout-cell>
            <p class="auto-cursor-target">
                <ac:structured-macro ac:name="toc" ac:schema-version="1">
                    <ac:parameter ac:name="maxLevel">2</ac:parameter>
                </ac:structured-macro>
            </p>
        </ac:layout-cell>
    </ac:layout-section>
    <ac:layout-section ac:type="single">
    <ac:layout-cell>
            <hr />
            <h1>Management Summary</h1>
            <ac:structured-macro ac:name="excerpt" ac:schema-version="1">
                <ac:parameter ac:name="atlassian-macro-output-type">INLINE</ac:parameter>
                <ac:rich-text-body>
                    $(Get-ReportManagementSummaryTable $context)
                </ac:rich-text-body>
            </ac:structured-macro>
        </ac:layout-cell>
    </ac:layout-section>
    <ac:layout-section ac:type="single">
        <ac:layout-cell>
            <hr />
            <h1>Test Verlauf</h1>
            $(Get-ReportTimelineTable $context)
        </ac:layout-cell>
    </ac:layout-section>
    <ac:layout-section ac:type="single">
        <ac:layout-cell>
            $body
        </ac:layout-cell>
    </ac:layout-section>
</ac:layout>
"@
}

Function Get-ReportSectionContent {
    Param(
        $context,
        $section
    )
    
    $sectionContent = ""
    
    switch ($section.type) {
        "controller-loop" {
            foreach ($controller in $context.controllers) {
                Set-Controller $controller

                $sectionContent += @"
        <h2>Controller: $($controller.friendlyControllerUrl)</h2>
"@
                
                # Handle single function with analysis config
                if ($section.function -and $section.analysisConfig) {
                    $analysisConfig = $context.projectInfo.$($section.analysisConfig)
                    $sectionContent += & $section.function $context $analysisConfig
                }
                # Handle multiple functions
                elseif ($section.functions) {
                    foreach ($functionName in $section.functions) {
                        $sectionContent += & $functionName $context $controller
                    }
                }
                # Handle single function without analysis config
                elseif ($section.function) {
                    $sectionContent += & $section.function $context $controller
                }
            }
        }
        "single" {
            # Handle single function with analysis config (no controller loop)
            if ($section.function -and $section.analysisConfig) {
                $analysisConfig = $context.projectInfo.$($section.analysisConfig)
                $sectionContent += & $section.function $context $analysisConfig
            }
            # Handle multiple functions
            elseif ($section.functions) {
                foreach ($functionName in $section.functions) {
                    $sectionContent += & $functionName $context
                }
            }
            # Handle single function without analysis config
            elseif ($section.function) {
                $sectionContent += & $section.function $context
            }
        }
    }
    
    return $sectionContent
}

Function Get-LegacyReportStructure {
    Param(
        $context
    )
    
    $body = ""

    # Antwortzeit- und Durchsatz Analyse Abschnitt
    $body += @"
<hr />
<h1>Antwortzeit- und Durchsatz Analyse</h1>
<ac:structured-macro ac:name="expand" ac:schema-version="1">
    <ac:rich-text-body>
        $(Get-ReportDetailAnalysis $context $context.projectInfo.transactionsAnalysis)
    </ac:rich-text-body>
</ac:structured-macro>
"@

    # OS / Server Monitoring Abschnitt (ohne foreach)
    $body += @"
<hr />
<h1>OS / Server Monitoring</h1>
<ac:structured-macro ac:name="expand" ac:schema-version="1">
    <ac:rich-text-body>
        $(Get-ReportDetailAnalysis $context $context.projectInfo.serverMonitoring)
    </ac:rich-text-body>
</ac:structured-macro>
"@

    # Execution Details Abschnitt
    $body += @"
<hr />
<h1>Execution Details</h1>
<ac:structured-macro ac:name="expand" ac:schema-version="1">
    <ac:rich-text-body>
"@

    foreach ($controller in $context.controllers) {
        Set-Controller $controller

        $body += @"
        <h2>Controller: $($controller.friendlyControllerUrl)</h2>
        $(Get-ReportExecutionDetailsSection $context $controller)
"@
    }

    $body += @"
    </ac:rich-text-body>
</ac:structured-macro>
"@

    # Detail Analysen Abschnitt
    $body += @"
<hr />
<h1>Detail Analysen</h1>
<ac:structured-macro ac:name="expand" ac:schema-version="1">
    <ac:rich-text-body>
        $(Get-ReportDetailAnalysis $context $context.projectInfo.detailAnalysis)
    </ac:rich-text-body>
</ac:structured-macro>
"@

    # Häufig auftretende Fehler Abschnitt
    $body += @"
<hr />
<h1>H&auml;ufig auftretende Fehler</h1>
<ac:structured-macro ac:name="expand" ac:schema-version="1">
    <ac:rich-text-body>
        $(Get-ReportCommonErrors $context)
        $(Get-ReportCommonConsoleErrors $context)
    </ac:rich-text-body>
</ac:structured-macro>
"@

    # Platform Status Abschnitt (ohne foreach)
    $body += @"
<hr />
<h1>Platform Status</h1>
<ac:structured-macro ac:name="expand" ac:schema-version="1">
    <ac:rich-text-body>
        $(Get-ReportPlatformStatusTable $context)
    </ac:rich-text-body>
</ac:structured-macro>
"@

    return $body
}