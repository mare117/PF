Function Get-OverallTestState {    
    Param(
        $context
    )
    
    $pageId = $context.projectInfo.parentConfluencePageId
    Write-Host "[Confluence] Get current page attachments..."
    $currentAttachments = Invoke-RestMethod -Method Get -Uri "https://confluence.pnet.ch/rest/api/content/$pageId/child/attachment?limit=1000" -Headers $context.confluenceHeaders -UseBasicParsing
    
    $attachment = ($currentAttachments.results | Where-Object { $_.title -eq $context.stateFile })
    if ($null -ne $attachment) {
        Write-Host "[Confluence] Get current test state $($attachment.title)..."
        Invoke-WebRequest "https://confluence.pnet.ch$($attachment._links.download)" -Headers $context.confluenceHeaders -outFile $context.statePath
    } 
    if (Test-Path $context.statePath) {
        $context.state = (Get-Content $context.statePath | ConvertFrom-Json)
    } else {
        $context.state = @{
            current=@{
                defects=@()
                reporting=@{}
            }
            history=@()
        }
    }
    
}