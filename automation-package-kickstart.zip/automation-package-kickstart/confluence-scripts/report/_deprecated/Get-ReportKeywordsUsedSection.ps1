Function Get-ReportKeywordsUsedSection {    
    Param(
        $execution
    )
    Write-Host "[Keywords Used] Fetch raw data"
    
    $measurements = Invoke-RestMethod -UseBasicParsing -Method Post -Uri "$controllerUrl/rest/time-series/measurements" -Header @{ "Content-Type"="application/json" } -Body (@{
        start=$execution.startTime
        end=$execution.endTime
        numberOfBuckets=1
        oqlFilter="(attributes.metricType = response-time) and (attributes.eId = $($execution.id))"
        percentiles=@()
        groupDimensions=@("origin")
        collectAttributeKeys=@()
        collectAttributesValuesLimit=10
    } | ConvertTo-Json)

    Write-Host "[Keywords Used] Reorganize by Keyword name"
    $measurementsByName = @{}
    for($i = 0; $i -lt $measurements.matrixKeys.Count; $i++) {
        $name = $measurements.matrixKeys[$i].origin;
        if (-not $name) {
            continue;
        }
        if (-not $measurementsByName.ContainsKey($name)) {
            $measurementsByName[$name] = @{};
        }
        $measurementsByName[$name] = $measurements.matrix[$i][0];
    }

    $md = "||Keyword||Number of Calls||`n"


    Write-Host "[Keywords Used] Write table"
    foreach ($name in ($measurementsByName.Keys | Sort-Object)) {
        $measurement = $measurementsByName[$name];
        $md += "|$name|$($measurement.count)|`n"

    }
    return $md
    <# TODO: Extract package 
    return @"
||Package||Keywords||
|selenium-poc.jar|Open_chrome
Navigate_to_page
Click_by_xpath|
|step-selenium-fipo-0.0.1-SNAPSHOT-jar-with-dependencies.jar|Enter_iframe_by_xpath
Exit_iframe
Select_option_by_xpath|
|step-selenium-beam.jar|Send_keys_by_xpath
Check_element_is_displayed_by_xpath
Click_by_xpath_javascript|
|step-selenium-wtv.jar|Set_ScrollTop|
"@ #>
}