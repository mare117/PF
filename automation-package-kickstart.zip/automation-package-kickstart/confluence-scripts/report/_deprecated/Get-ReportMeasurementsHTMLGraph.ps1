Function Get-ReportMeasurementsHTMLGraph {    
    Param(
        $execution,
        $transactionName
    )

    Write-Host "[HTML Graph] Fetch raw data for $transactionName"
    $measurements = Invoke-RestMethod -UseBasicParsing -Method Post -Uri "$controllerUrl/rest/time-series/measurements" -Header @{ "Content-Type"="application/json" } -Body (@{
        start=$execution.startTime
        end=$execution.endTime
        numberOfBuckets=($execution.endTime - $execution.startTime) / 60000
        oqlFilter="(attributes.metricType = response-time) and (attributes.eId = $($execution.id)) and (attributes.name = '$transactionName')"
        percentiles=@(90, 99)
        groupDimensions=@("rnStatus")
        collectAttributeKeys=@()
        collectAttributesValuesLimit=10
    } | ConvertTo-Json)

    Write-Host "[HTML Graph] Write Chart for $transactionName"
    New-HTML -TitleText $transactionName -Online -FilePath "charts\$transactionName.html" {
        New-HTMLChart -Title $transactionName -TitleAlignment center {
            $time = @($measurements.matrix[0] | Where-Object {$_.begin -gt 0}  | ForEach-Object { ([datetime] '1970-01-01').AddSeconds($_.begin / 1000.0).ToLocalTime() })
            New-ChartAxisX -Type datetime -Names $time
            New-ChartGrid
            New-ChartLine -Name 'AVG' -Value @($measurements.matrix[0] | ForEach-Object { if ($_.count -gt 0) {[int] ($_.sum / $_.count)} else {0} })
            New-ChartLine -Name 'P(90%)' -Value @( $measurements.matrix[0].pclValues.90 | ForEach-Object { if ($_ -gt 0) {$_} else {$null} })
            New-ChartLine -Name 'P(99%)' -Value @( $measurements.matrix[0].pclValues.99 | ForEach-Object { if ($_ -gt 0) {$_} else {$null} })
            New-ChartLine -Name 'Count Passed' -Value @($measurements.matrix[1] | ForEach-Object { if ($_.count -gt 0) {$_.count} else {0} })
            #New-ChartLine -Name 'Count Failed' -Value @($measurements.matrix[1] | ForEach-Object { $_.count })
            # Series on the left and the right, but we force different minimum, maximum (you could also leave it for automatic recalculation)
            New-ChartAxisY -Show -ForceNiceScale -TitleText 'Times [ms]' -Opposite  -MinValue 0
            # By using series name the same as the line, we force it to use that series
            #New-ChartAxisY -Show -TitleText 'Count' -MinValue 0 -MaxValue  -SeriesName 'Count Passed'
        }
    
    }
    
    $md = Get-Content "charts\$transactionName.html"
    return "{html}" + $md.Replace("</head><body>","").Replace("</title><link ", "</title></head><body><link ") + "{html}"
}