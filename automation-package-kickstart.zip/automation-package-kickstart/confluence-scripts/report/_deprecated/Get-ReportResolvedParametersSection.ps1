Function Get-ReportResolvedParametersSection {    
    Param(
        $execution
    )

    
    Write-Host "[Resolved Parameters] Write Resolved Parameters Table"  

    $md = "||Key||Value||`n"
    foreach ($parameter in $execution.parameters) {
        if ($parameter.key.StartsWith("REPORT_")) {
            continue
        }
        $md += "|$($parameter.key)|$($parameter.value)|`n"
    }
    return $md
<# TODO: does last modification date and version id make sense? again, what if it was modified after test execution before producing the report?

return @"
||Key||Last Modification Date||VersionId||
|PF_APP_URL|Mon Feb 28 17:22:42 CET 2022|647d9d2f8eb2505038d0d12c|
|PF_APP_URL|Mon Dec 20 16:11:50 CET 2021|647d9d2f8eb2505038d0d12f|
|PFCH_PACING|Mon Dec 20 16:11:01 CET 2021|647d9d2f8eb2505038d0d136|
|PFCH_PACING|Mon Dec 20 16:11:07 CET 2021|647d9d2f8eb2505038d0d137|
"@ #>
}