Automated generation of Test reports
====================================

To generate a report, change to a directory containing a `projectInfo.ps1` and execute with

```
..\automation-package-kickstart\confluence-scripts\report\Write-Report.ps1 -executionIds @(,"6a68489b91553b41a5e73743") 
```

with specific execution ids after the run, or with `-inProgress` during a run:
```
..\automation-package-kickstart\confluence-scripts\report\Write-Report.ps1 -inProgress
```

In that case, the script searches for currently running executions in the indicated project, and assembles all of them to create a unified report. It then drops into a prompt where journal entries can be added manually while the test is running. each new journal entry triggers an update of the report, showing with the " - IN PROGRESS" suffix.

`-inProgress` can be combined with `-executionIds` in order to add executions which have been completed before launching `-inProgress`. Also when a new test is started, the new execution can be loaded by simply pressing enter when the scripts accepts user input in the `-inProgress` prompt.

The write-report can be repeatedly executed with different options. The report to be updated is identified by the first execution start time in the execution id list, as long as this remains the same, the report is modified, without overriding conclusions which were manually added/changed before re-running the script. 

If the first draft was created by `-inProgress`, then the list of exeuctions has been saved in a temporary file, and does not need to be indicated by `-executionIds` when finalizing the report.

Following options are available:

```
    [-reportConfigFile]    Override projectInfo.ps1 file as the default report configuration
    [-passed/-partial]     Override default FAILED status
    [-referenceRun]        Mark the run as reference run, also sets the archive flag in step and records the 
                           reference values for a given test in the current-state.json file of the parent report page
    [-reuploadAttachments] Force re-upload of attachements, to be used when the attachment generation failed in a previous attempt
    
```

For most detailed structures of the projectInfo.ps1 take a look at the [ALBERT example](https://gitlab.pnet.ch/nfrt/step/plans/albert/-/blob/master/projectInfo.ps1?ref_type=heads) which features cross-release response time measurements, or the [KOP/VASC](https://gitlab.pnet.ch/nfrt/step/plans/metis/-/blob/main/projectInfo.ps1?ref_type=heads) example which provides an example of how to collect and report values to additional Confluence pages (such as the [combined test summary page](https://gitlab.pnet.ch/nfrt/step/plans/metis/-/blob/main/projectInfoCombined.ps1?ref_type=heads)).

Add Defect for tracking
-----------------------

Defects can be added automatically to the report by the following command:
```
..\automation-package-kickstart\confluence-scripts\report\New-Defect.ps1 NGB-9999
```
re-running the report generation will then show the defect in the "New Defect column" of the summary. In subsequent reports the defect will show in the "open defect column" until
```
..\automation-package-kickstart\confluence-scripts\report\Set-DefectValidated.ps1 NGB-9999
```
moves it to the "Validated defects" column. A validated defect will then no longer appear in the reports subsequent to the one which indicated it as validated.

Make Test announcements
-----------------------

The `projectInfo.ps1` files store, in addition to report specific information, also the mailing list to be used for test announcments.
```
.\automation-package-kickstart\confluence-scripts\generate-announcements\Create-OutlookAppointment.ps1 -reportConfigFile .\projectInfoPEAK.ps1
```
Will create a test announcement for the next day, with meta values such as calendar category, default start/stop times, applications affected, scenario etc. Parameters `-date`, `-startTime`, `-endTime` and `-reason` offer to override default `projectInfo.ps1` values. 

The command will require granting permissions in Outlook (a corresponding dialogue will show). After granting the permissions (10 minutes recommended), a calendar entry is generated in the Last&Performance calendar with standard formatting, and a send dialogue of the annoucment e-mail is prepared. The user will have the final choice of whether to send the e-mail or not.

In order to create a schedule at the beginning of the release, the flag `-skipEmailPreparation` offers to skip the preparation of the e-mail entirely, and only teh calendar entry will be made. Once all entries have been made, the following script

```
.\automation-package-kickstart\confluence-scripts\generate-announcements\Create-ScheduleEmail.ps1
```

allows the creation of a schedule e-mail which contains all future calendar entries for the given test in one schedule e-mail by filtering all future appointments with the test name in the title.

```
.\automation-package-kickstart\confluence-scripts\generate-announcements\Sanitize-RecipientList.ps1
```
Takes the recipient list of the `projectInfo.ps1` and checks them all against the directory of Outlook. Should a user no longer exist, it will discard the e-mail. E-Mail addresses outside Postfinance are marked as such in a comment and are unaffected.

The new list is copied to the clipboard, ready to be copied back into the `projectInfo.ps1` mailing list section.