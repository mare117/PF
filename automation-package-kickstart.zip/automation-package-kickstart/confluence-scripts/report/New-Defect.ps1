Param(
    [Parameter(Mandatory=$true)] $jiraId = "",
    [Parameter(Mandatory=$false)] $reportConfigFile = ".\projectInfo.ps1"
)

. "$reportConfigFile"

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'


. "$PSScriptRoot\compilation\Get-OverallTestState.ps1"
. "$PSScriptRoot\compilation\Set-OverallTestState.ps1"
. "$PSScriptRoot\..\common\Get-Context.ps1"

$context = Get-Context @() $projectInfo $false $false $false $false $null $null
Get-OverallTestState $context

$context.state.current.defects = @($context.state.current.defects) + @(,@{
    key=$jiraId
    newInExecution=$null
    validatedInExecution=$null
    validated=$false
})

Set-OverallTestState $context