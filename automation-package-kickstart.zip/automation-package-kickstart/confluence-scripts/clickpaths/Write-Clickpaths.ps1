Param(
    $executionIds = @(),
    [switch] $reuploadAttachments
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

. ".\projectInfo.ps1"

if ("$executionIds" -eq "") 
{
    Write-Host @"

    Prepares a Clickpath confluence page based on a debug mode execution
     
    Usage:
        - In Powershell, execute:

            .\Write-Clickpaths.ps1 -executionIds ExecutionIds

          where

            ExecutionIds    List of Execution Ids of the executions used to generate the clickpaths
"@
    exit
}


. "$PSScriptRoot\..\common\Get-Context.ps1"
. "$PSScriptRoot\..\common\Set-Controller.ps1"
. "$PSScriptRoot\..\common\Set-HousekeepingProtection.ps1"
. "$PSScriptRoot\..\common\Update-ConfluencePage.ps1"
. "$PSScriptRoot\..\common\Get-ControllerForProject.ps1"
. "$PSScriptRoot\Get-ClickPaths.ps1"


$context = Get-Context $executionIds $projectInfo $false $false $false $reuploadAttachments $null $null
Set-HousekeepingProtection $context


foreach ($controller in $context.controllers) {
    Set-Controller $controller
    foreach($execution in $controller.executions) {
       
        $clickPathPage = $context.projectInfo.clickPathPages | Where-Object { $_.planName -eq $execution.description } | Select-Object -First 1

        Write-Host "Identify Composites"
        
        $controller = Get-ControllerForProject $context $clickPathPage.projectName
        $functions = Invoke-RestMethod -UseBasicParsing -Method Get "$($controller.controllerUrl)/rest/functions"
        $compositeFunctionIds = @($functions | Where-Object { $_.type -eq "step.plugins.functions.types.CompositeFunction"}).id

        
        $body = Get-ClickPaths $context $controller $execution $clickPathPage $compositeFunctionIds
        Update-ConfluencePage $context $body $clickPathPage.confluencePageId $context.filesToUpload
    }
}

