Function Get-ClickPathForSubtree {    
    Param(
        $context,
        $controller,
        $node,
        $reportNodes,
        $nodeById,
        $childrenById,
        $commonPlans,
        $screenshotCounter,
        $compositeFunctionIds
    )
    
    $colors = $("green", "blue", "orange", "red")
    
    $rpcNodes = @(
        "step.artefacts.reports.IfBlockReportNode",
        "step.artefacts.reports.ForBlockReportNode",
        "step.artefacts.reports.WhileBlockReportNode"
    )
    
    $stack = New-Object System.Collections.Stack
    
    $rpcReport = @()
    $rpcItems = @()
    
    
    $stack.Push(@{
        rpcReport=$rpcReport
        node=$node
    })

    $null = New-Item -Force $($context.projectInfo.clickPathsCache) -ItemType Directory
    
    $body =  "";
    
    while ($stack.Count -gt 0) {
        $stackItem = $stack.Pop()
        $reportNode = $stackItem.node
        $rpcReport = $stackItem.rpcReport
        $rpc = $rpcReport -join " "

        $compositeFunctionCall = $false
    
        if ($reportNode._class -eq "step.artefacts.reports.CallFunctionReportNode") {
            $transactionName = ($reportNode.measures | Where-Object {$_.data.type -in @("custom", "keyword")}).name
            if ([string]::IsNullOrWhiteSpace($transactionName)) {
                $transactionName = $reportNode.resolvedArtefact.attributes.name
            }
            $screenshotId = Get-FirstScreenshotIdInTree $reportNode $childrenById
            $description = $reportNode.resolvedArtefact.description;
            $description = if ($null -eq $description) { " " } else {$description.Replace("`n", "\\ ")}
            $nodeTitle = $reportNode.resolvedArtefact.attributes.name

            $compositeFunctionCall = $compositeFunctionIds.Contains($reportNode.functionId)
    
            if ($compositeFunctionCall) {
                $transactionName = Get-TransactionNameInTree $reportNode $childrenById
            }
            
            if ($transactionName)
            {
                $screenshot = " "
                if ($screenshotId) {
                    $filename = $transactionName;
                    if ($transactionName.Contains("$")) {
                        $filename = "actionScreenshot";
                        $transactionName = $transactionName
                    }
                    $filename = $filename.Replace("/", "_");
                    if ($screenshotCounter.ContainsKey($filename)) {
                        $screenshotCounter[$filename]++;
                    } else {
                        $screenshotCounter[$filename]=0;
                    }
                    $filename = "$($filename)_$($screenshotCounter[$filename]).jpg"
                    $screenshot = @"
        <ac:image ac:width="400">
            <ri:attachment ri:filename="$fileName" />
        </ac:image>
"@
                    $path = "$($context.projectInfo.clickPathsCache)\$filename"
                    if (-not (Test-Path $path) -or $context.reuploadAttachments) {
                        $screenshotResponse = Invoke-WebRequest -UseBasicParsing -Method Get -Uri "$($controller.controllerUrl)/rest/resources/$($screenshotId)/content"
                        $screenshotContent = $screenshotResponse.Content;
                        $null = New-Item -Force -Path $path;
                        $null = Set-Content -Force -Path $path -Value $screenshotContent -Encoding Byte;
                        $context.filesToUpload += @(@{
                            name=$filename
                            path=$path
                        })
                    }
                }
                $body += @"
    <tr>
        <td>$rpc</td><td>$nodeTitle</td><td>$transactionName</td><td>$description</td><td>$screenshot</td>
    </tr>
"@
            }
    
        }
        if (("" -ne "$($reportNode.resolvedArtefact.description)") -and $rpcNodes.Contains($reportNode._class) -and $childrenById.ContainsKey($reportNode.Id)) {
            $color = $colors[$rpcReport.Count]
            $rpcReport = @($rpcReport) + "<span style=""color: $color; font-weight: bold"">|</span>"
            $rpc = $rpcReport -join " "
            
            $nodeTitle = $reportNode.resolvedArtefact.attributes.name
            $description = $reportNode.resolvedArtefact.description;
    
            if ("$description" -ne "") { $description = "<span style=""color: $color; font-weight: bold"">$([System.Web.HttpUtility]::HtmlEncode($description))</span>"}
            $body += @"
    <tr>
        <td>$rpc</td><td><span style="color: $color">$nodeTitle</span></td><td></td><td>$description</td><td></td>
    </tr>
"@
            $rpcItems += $reportNode
        }
        if ($commonPlans.ContainsKey($reportNode.resolvedArtefact.id) -and $reportNode.resolvedArtefact.id -ne $node.resolvedArtefact.id) {
            
            $nodeTitle = "<span style=""font-weight: bold"">Execute Common subplan $($reportNode.resolvedArtefact.attributes.name)</span>"
            $description = $reportNode.resolvedArtefact.description;
            if ("$description" -ne "") { $description ="<span style=""font-weight: bold"">$([System.Web.HttpUtility]::HtmlEncode($description.Replace('@common', '')))</span>"}
            $transactionName = ($reportNode.measures | Where-Object {$_.data.type -in @("custom", "keyword")}).name
            if ([string]::IsNullOrWhiteSpace($transactionName)) {
                $transactionName = $reportNode.resolvedArtefact.attributes.name
            }
            $body += @"
    <tr>
        <td>$rpc</td><td>$nodeTitle</td><td>$transactionName</td><td>$description</td><td></td>
    </tr>
"@
        } elseif (-not $compositeFunctionCall) {
            $childrenById[$reportNode.id] | Sort-Object { $_.executionTime } -Descending | ForEach-Object {
                $stack.Push(@{
                    rpcReport=$rpcReport
                    node=$_
                })
            }
        }
    }


    return @"
<table width="1400px">
    <thead>
        <tr>
            <th>RPC</th><th>Step</th><th>Transaction Name</th><th>Description</th><th>Screenshot</th>
        </tr>
    </thead>
    <tbody>
        $body
    </tbody>
</table>
"@
}


Function Get-FirstScreenshotIdInTree {    
    Param(
        $node,
        $childrenById
    )
    
    $id = ($node.attachments | Where-Object {$_.name -eq "actionScreenshot.jpg"} | Select-Object -First 1).id

    if ($null -ne $id) {
        return $id
    }

    foreach($child in $childrenById[$node.id]) {
        $id = Get-FirstScreenshotIdInTree $child $childrenById
        
        if ($null -ne $id) {
            return $id
        }
    }
    return $null;
}

Function Get-TransactionNameInTree {    
    Param(
        $node,
        $childrenById
    )
    $name = ($node.measures | Where-Object {$_.data.type -in @("custom", "keyword")}).name
    if ([string]::IsNullOrWhiteSpace($name)) {
        $name = $node.resolvedArtefact.attributes.name
    }

    if ($null -ne $name) {
        return $name
    }

    if ($node.resolvedArtefact.instrumentNode.value) {
        return $node.name
    }

    foreach($child in $childrenById[$node.id]) {
        $name = Get-TransactionNameInTree $child $childrenById
        
        if ($null -ne $name) {
            return $name
        }
    }
    return $null;
}