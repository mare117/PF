Param(
    $executionIds = @(),
    $frameRate = 10,
    [switch] $realTime
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

. ".\projectInfo.ps1"

if ("$executionIds" -eq "") 
{
    Write-Host @"

    Prepares a Clickpath confluence page based on a debug mode execution
     
    Usage:
        - In Powershell, execute:

            .\Write-Clickpaths.ps1 -executionIds ExecutionIds

          where

            ExecutionIds    List of Execution Ids of the executions used to generate the clickpaths
"@
    exit
}


. "$PSScriptRoot\..\common\Get-Context.ps1"
. "$PSScriptRoot\..\common\Set-Controller.ps1"
. "$PSScriptRoot\Get-ClickPaths.ps1"


$context = Get-Context $executionIds $projectInfo $false $false $false $reuploadAttachments $null $null


foreach ($controller in $context.controllers) {
    Set-Controller $controller
    foreach($execution in $controller.executions) {
       
        $reportNodes = Invoke-RestMethod -UseBasicParsing -Method Get -Uri "$($controller.controllerUrl)/rest/executions/$($execution.id)/reportnodes?limit=1000"

        $movieFilePath = "$($execution.description)_Movie"
        
        $i = 0

        Remove-Item $movieFilePath -Recurse -Force
        New-Item -Path "$movieFilePath\cropped" -ItemType Directory
        foreach ($reportNode in $reportNodes) {
            $screenshotId = ($reportNode.attachments | Where-Object {$_.name -eq "actionScreenshot.jpg"} | Select-Object -First 1).id
            $timeFrame =  ($reportNode.executionTime - $execution.startTime) * $frameRate / 1000;
            if ($null -ne $screenshotId) {
                $screenshotResponse = Invoke-WebRequest -UseBasicParsing -Method Get -Uri "$($controller.controllerUrl)/rest/resources/$($screenshotId)/content"
                $screenshotContent = $screenshotResponse.Content;
                Write-Host "Processing time $($reportNode.executionTime - $execution.startTime)"
                if (-not $realTime) { $i = [int] $timeFrame;} 
                while ($i -le $timeFrame) {
                    $path = "$movieFilePath\actionScreenshot_{0:d4}.jpg" -f $i
                    $null = New-Item -Force -Path $path;
                    $null = Set-Content -Force -Path $path -Value $screenshotContent -Encoding Byte;
                    $croppedPath = "$movieFilePath\cropped\actionScreenshot_{0:d4}.jpg" -f $i
                    $i++;
                    if (-not $realTime)  { ffmpeg -i $path -filter:v "crop=520:770:1365:320" $croppedPath}
                }
            }
        }


        if ($realTime) { ffmpeg -y -framerate $frameRate -i "$movieFilePath\actionScreenshot_%04d.jpg" -filter:v "crop=in_w:in_h-1"  -crf 22 "$($execution.description).mp4" }
    }
}

