. "$PSScriptRoot\Get-ClickPathForSubtree.ps1"

Function Get-ClickPaths {
    Param(
        $context,
        $controller,
        $execution,
        $clickPathPage,
        $compositeFunctionIds
    )
        
    Write-Host "Load report nodes"

    $reportNodes = Invoke-RestMethod -UseBasicParsing -Method Get -Uri "$($controller.controllerUrl)/rest/executions/$($execution.id)/reportnodes?limit=1000"
    
    Write-Host "Build Parent-Child Mappings and identify Common Clickpaths"

    $nodeById = @{}
    $childrenById = @{}
    $threadIterations = @()
    $testCases = @()
    $screenshotCounter = @{}

    $commonPlans = @{}
    foreach ($reportNode in $reportNodes) {
        $nodeById[$reportNode.id] = $reportNode
        $parentId = if ($null -eq $reportNode.parentId) {"root"} else {$reportNode.parentId}
        if (-not $childrenById.ContainsKey($parentId)) {
            $childrenById[$parentId] = @();
        }
        $childrenById[$parentId] += $reportNode;
        if ($reportNode.resolvedArtefact.description -match "^@common\b.*") {
            $commonPlans[$reportNode.resolvedArtefact.id]=$reportNode   
        }
    }

    Write-Host "Identify first iterations of thread groups"
    foreach ($reportNode in $reportNodes) {
        if ($reportNode.resolvedArtefact._class -eq "ThreadGroup") {
            if ($childrenById.ContainsKey($reportNode.id)) {
                $threadId = $childrenById[$reportNode.id][0].id

                if ($childrenById.ContainsKey($threadId)) {
                    $iteration = $childrenById[$threadId][0]
                    $threadIterations += $iteration
                }
            } 
        }
    }

    Write-Host "Identify Test cases"
    foreach ($reportNode in $reportNodes) {
        if ($reportNode.resolvedArtefact._class -eq "TestCase") {
            $testCases += $reportNode
        }
    }


    $body = ""

    if ($commonPlans.Count -gt 0) {
        $body += "<h1>Common Clickpaths</h1>"



        foreach ($commonPlan in ($commonPlans.Values | Sort-Object -Property executionTime)) {
            
            Write-Host "Write Clickpaths for Common plan $($commonPlan.name)"
        
            $body += @"
<h2>Common Clickpath $($commonPlan.name)</h2>
<p>
    $($commonPlan.description)
</p>
<p>     
    $(Get-ClickPathForSubTree $context $controller $commonPlan $reportNodes $nodeById $childrenById $commonPlans $screenshotCounter $compositeFunctionIds)
</p>
"@
        
        }
    }

    if ($threadIterations.Count -gt 0) {
        
        $body += "<h1>Threads</h1>"

        foreach ($threadIteration in ($threadIterations | Sort-Object -Property executionTime)) {

            $threadGroup = $nodeById[$nodeById[$threadIteration.parentID].parentID]

            
            Write-Host "Write Clickpaths for thread group $($threadGroup.name)"

            $body += @"
<h2>Thread $($threadGroup.name)</h2>
<p>
    $($threadGroup.description)
</p>
<p>     
    $(Get-ClickPathForSubTree $context $controller $threadIteration $reportNodes $nodeById $childrenById $commonPlans $screenshotCounter $compositeFunctionIds)
</p>
"@
        }
        
    }
    if ($testCases.Count -gt 0) {
        
        $body += "<h1>Test cases</h1>"

        foreach ($testCase in ($testCases | Sort-Object -Property executionTime)) {
            
            Write-Host "Write Clickpaths for test case $($testCase.name)"

            $body += @"
<h2>Thread $($testCase.name)</h2>
<p>
    $($testCase.description)
</p>
<p>     
    $(Get-ClickPathForSubTree $context $testCase $reportNodes $nodeById $childrenById $commonPlans $screenshotCounter $compositeFunctionIds)
</p>
"@
        }
        
    }
    $body = @"
<ac:layout>
    <ac:layout-section ac:type="single">
        <ac:layout-cell>
            <p class="auto-cursor-target">
                <ac:structured-macro ac:name="toc" ac:schema-version="1">
                    <ac:parameter ac:name="maxLevel">2</ac:parameter>
                </ac:structured-macro>
            </p>
            $body
        </ac:layout-cell>
    </ac:layout-section>
</ac:layout>
"@
    return $body
}