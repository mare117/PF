$projectInfo = @{
    mvnSettings = @(
        @{ mvnSettingName="step-selenium"; projectName="Anlegen_SSF" }
    )
    clickPathPages=@(
        ,@{
            name="Anlegen SSF - Portfolio Generation Clickpaths"
            confluencePageId=1722189221
            planName="AnlegenSSF Portfolio Generation"
        }
    )
    projectName="Anlegen_SSF"
    scenarioName="Anlegen SSF Regression - Spitzenlast"
    jiraTask="NFRT-19821"
    releaseNumber="RE26D"
    
    testStrategyConfluencePageId=1205059776
    testStrategyTitle="Anlegen SSF - Performance Teststrategie"

    #parentConfluencePageId=1722189841 # personal space
    parentConfluencePageId=1205059781
    qcTestSets=@(
        @{
            id=332790
            name="Anlagen SSF"
            testInstanceIds=@(
                5198964
            )
        }
    )
    splunkDashboards=@(
        @{
            Url="https://pfportal.pnet.ch/splunkclu/en-US/app/splunk_for_load/anlegen_ssf_monitoring?form.gt.earliest=[[startTime]]&form.gt.latest=[[endTime]]&form.update_interval=1m&form.pt.earliest=[[analysisStartTime]]&form.pt.latest=[[analysisEndTime]]&form.perc=[[perc]]&tab=layout_1"
            Name="Anlegen SSF Monitoring"
        }
    )
    #calendarCategories="Anlegen GUI"
    calendarCategories="Self Service"
    distributionList=@{
        To=@(
          "Delivery Team BANCS GSP, PF84 <dt-bgsp@postfinance.ch>" # Mailbox
          "Delivery Team ISACDP, PF84 <isacdp@postfinance.ch>" # Mailbox
          "DT ESBPF, PF85 <DT-I-ESBPF@postfinance.ch>" # Mailbox
          "DT PEDAS Core (STPEDA), PF84 <dtpedas@postfinance.ch>" # Mailbox
          "Release Management PF, PF81 <re.management@postfinance.ch>" # Mailbox
          "Jenny Pascal, PF84 <pascal.jenny@postfinance.ch>" # User
          "Rohner Mirjam, PF62 <mirjam.rohner@postfinance.ch>" # User
          "Stuber Marc, PF85 extern <marc.stuber@postfinance.ch>" # User
          "stav@postfinance.ch"
        )
        CC=@(
          "Last&PerformanceTest, PF85 <last-performance@postfinance.ch>" # Mailbox
          "Baumhoff Stephan, PF85 <stephan.baumhoff@postfinance.ch>" # User
          "Berger Muriel, PF85 <muriel.berger@postfinance.ch>" # User
          "Helfenstein Nevin, PF85 <nevin.helfenstein@postfinance.ch>" # User
          "Misev Cyril, PF85 extern <cyril.misev@postfinance.ch>" # User
        )
        Engineers=@(
          "Reber Martin, PF85 extern <martin.reber.7@postfinance.ch>" # User
          "Heiland Gregor, PF85 extern <gregor.heiland@postfinance.ch>" # User
        )
    }
    reason="Optimierung Benutzerjourney Self Service Fonds"
    typicalStartTime="09:00"
    typicalEndTime="12:00"
    rampUpMinutes=8
    rampDownMinutes=8
    gitName="AnlegenSSF"
    testEnvironment="T1"
    reportCache="report_cache"
    clickPathsCache="clickpaths_cache"
    downloadFolder="$env:USERPROFILE\Downloads"
    nfrReportLabels=@{
        avg="Average [ms]"
        90="90%-tile [ms]"
        99="99%-tile [ms]"
        errorRate="Error rate [%]"
        tpm="TPM"
        count="Count"
    }
    longNfrReportLabels=@{
        90="90%-tile response time ({0} ms)"
        99="99%-tile response time ({0} ms)"
        avg="average response time ({0} ms)"
        errorRate="error rate ({0:n2}%)"
        tpm="transactions per minute"
        count="Count"
    }
    hltcE2E=@(
            ,@{
                store="GS2411"
                id="GS2405-37065"
                name="LPT Create investment portfolios (Questionnaire)"
            }
    )
    applicationsInScope=@(
        "BANCS", "OKAUT", "EF", "ISAAC.AM", "ISAAC.DP", "PEDAS", "ISY", "BPAY"
    )
    engineerConfluenceIds=@(
        #"misevc"
        #"helfensteinn"
        "rebm"
        #"phamthiv"
    )
    transactionsAnalysis=@(
        @{
            title="Transaktionen"
            description=""
            type="step-measurements-table"
            nameFilters=@(,"*")
            nfrs=@{
                90=@{
                }
            }
        }
    )
    serverMonitoring=@(
        ,@{
            type="graphana-screenshot"                        
            graphanaUrl="https://pfportal.pnet.ch/grafana/d/fe570w8c8d4hsf/step-overview?orgId=1&from=[[from]]&to=[[to]]&timezone=browser&var-cluster=t1-k8s-nucleus-a&var-namespace=appl-testlup-step-selenium-t1&var-agentSet=$__all&var-rate_interval=1m&var-sut=fipo&var-controllerPodType=step-controller"
            title="CPU and Memory Utilization (STEP Selenium Infrastructure)"
            screenshotWindowSize="1920,1280"
            width=1200
            description="The following Grafana dashboard shows CPU and memory utilization on the STEP Selenium infrastructure during this test."
        }
    )
    detailAnalysis=@(
        @{
            type="step-graph"
            title="Frontend click on ""Draw up investment proposal"""
            transactionName="SSF_Depotbestand*_ClickDetails"
            description="This section shows the Performance and number of errors when clicking on the ""Draw up investment proposal"" button at the very end of the Questionnaire."
            width=1200
        },@{
            type="step-measurements-table"
            nameFilters=@(,"SSF_Depotbestand_04_ClickDetails")
            nfrReportingLabels=@{
                "SSF_Depotbestand_04_ClickDetails"=@{
                    key="draw_up_proposal"
                    label="Draw up investment Proposal"
                }
            }
            collectOnly=$true
            collectReporting=$true
        }
    )
}